HIRO AutoBuilder update (Fabric 1.21.11)

New settings:
- AutoBuy: attempts to inspect /shop and /ah when a required block is missing.
- SkipMissing: skips a block type if no supported priced listing is found.
- Reach and Delay remain configurable.

Obstacle routing:
- Uses a local breadth-first path search around solid blocks.
- Can step up/down one block, avoids unsupported floor tiles and fluids.
- Routing is local (18 blocks around the player); it is not a full pathfinder for caves, doors, parkour, or long-distance terrain.

Automatic purchasing:
- Scans visible menu listings/pages in /shop and /ah, compares prices it can parse from item lore, then attempts the cheapest listing and a recognizable confirmation button.
- Server menus differ. It cannot guarantee compatibility with every custom economy/shop plugin, search GUI, listing format, or confirmation menu.
- The user should test with a small amount of in-game currency first. No price cap is configured; it selects the lowest parsed price it can find.
- If the server does not expose item listings and numeric prices in the GUI, AutoBuy will not be able to purchase automatically.

Build note: source changes were packaged and ZIP integrity checked. Gradle compilation was not run in this environment because no Gradle executable/wrapper is present.
