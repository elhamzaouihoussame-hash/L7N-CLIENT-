package com.l7n.client;

import net.minecraft.client.multiplayer.PlayerInfo;

public final class Util {
    private Util() {}
    /** Player name from a tab-list entry (works whether GameProfile exposes name() or getName()). */
    public static String name(PlayerInfo pi) {
        Object gp = pi.getProfile();
        try { return (String) gp.getClass().getMethod("name").invoke(gp); }
        catch (Exception e) {
            try { return (String) gp.getClass().getMethod("getName").invoke(gp); }
            catch (Exception e2) { return "?"; }
        }
    }
}
