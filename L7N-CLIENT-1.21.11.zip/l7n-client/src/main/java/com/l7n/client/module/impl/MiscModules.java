package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;

public final class MiscModules {
    private MiscModules() {}

    public static class AutoWalk extends Module {
        public AutoWalk() { super("AutoWalk", "Walk forward automatically", Category.MISC); }
        @Override public void tick(Minecraft mc) { if (mc.screen == null) mc.options.keyUp.setDown(true); }
        @Override protected void onDisable() { Minecraft.getInstance().options.keyUp.setDown(false); }
    }

    public static class AutoSneak extends Module {
        public AutoSneak() { super("AutoSneak", "Always sneak", Category.MISC); }
        @Override public void tick(Minecraft mc) { if (mc.screen == null) mc.options.keyShift.setDown(true); }
        @Override protected void onDisable() { Minecraft.getInstance().options.keyShift.setDown(false); }
    }

    public static class AutoJump extends Module {
        public AutoJump() { super("AutoJump", "Jump automatically while moving", Category.MISC); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen == null && mc.player.onGround() && (mc.options.keyUp.isDown() || mc.options.keyDown.isDown() || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown())) {
                Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, 0.42, v.z);
            }
        }
    }

    public static class AntiAFK extends Module {
        private int t; private boolean flip;
        public AntiAFK() { super("AntiAFK", "Small movements so you don't get kicked", Category.MISC); }
        @Override public void tick(Minecraft mc) {
            if (++t < 400) return;
            t = 0; flip = !flip;
            mc.player.swing(InteractionHand.MAIN_HAND);
            mc.player.setYRot(mc.player.getYRot() + (flip ? 5 : -5));
            if (mc.player.onGround()) { Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, 0.42, v.z); }
        }
    }

    public static class AutoRespawn extends Module {
        public AutoRespawn() { super("AutoRespawn", "Respawn instantly", Category.MISC); }
        @Override public void tick(Minecraft mc) { if (mc.screen instanceof DeathScreen) mc.player.respawn(); }
    }
}
