package com.l7n.client;

import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.repository.PackRepository;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/** Installs and toggles the built-in "L7N Anime" resource pack (animated katana swords + anime skin). */
public final class AnimePack {
    private AnimePack() {}
    private static final String FILE = "L7N-Anime.zip", ID = "file/" + FILE;

    /** @param mode "on", "off" or null to toggle */
    public static void toggle(String mode) {
        Minecraft mc = Minecraft.getInstance();
        try {
            Path target = mc.getResourcePackDirectory().resolve(FILE);
            if (!Files.exists(target)) {
                try (InputStream in = AnimePack.class.getResourceAsStream("/anime/" + FILE)) {
                    if (in == null) { CommandManager.info("The anime pack is missing from the mod"); return; }
                    Files.copy(in, target);
                }
            }
            PackRepository repo = mc.getResourcePackRepository();
            repo.reload();
            boolean on = repo.getSelectedIds().contains(ID);
            boolean want = mode == null ? !on : mode.equals("on");
            if (want == on) { CommandManager.info("Anime pack is already " + (on ? "ON" : "OFF")); return; }
            if (want) repo.addPack(ID); else repo.removePack(ID);
            mc.options.updateResourcePacks(repo);
            CommandManager.info(want ? "Anime skin + katana swords ON (reloading textures...)" : "Anime pack OFF (reloading textures...)");
        } catch (Exception e) {
            CommandManager.info("Could not apply the pack. Enable L7N-Anime in Options > Resource Packs. (" + e.getMessage() + ")");
        }
    }
}
