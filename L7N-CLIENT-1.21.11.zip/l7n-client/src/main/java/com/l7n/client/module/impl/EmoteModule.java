package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionHand;

/** Dances made from turning, crouching, jumping, walking and arm swings, so other players can see them too. Pick the dance in the settings. */
public class EmoteModule extends Module {
    public static final String[] NAMES = {
        "Spin", "Fast Spin", "Slow Spin", "Reverse Spin", "T-Bag", "Slow Crouch", "Hop", "Wave", "Clap", "Nod",
        "Head Bang", "Head Shake", "Look Around", "Sway", "Moonwalk", "Circle Walk", "Zigzag", "Square Dance", "Spin & Jump", "Spin & Crouch",
        "Pogo", "Breakdance", "Robot", "Disco", "Helicopter", "Wobble", "Flex", "Salute", "Bow", "Floss",
        "Hype", "Twirl", "Shiver", "Peekaboo", "Conga", "Bunny Hop"
    };
    private int t;
    private float baseYaw, basePitch;

    public EmoteModule() {
        super("Emote", "Dances (pick one in the settings or with .emote)", Category.MISC);
        addSetting("dance", 1, 1);
    }

    private int dance() { return Math.clamp((long) get("dance"), 1, NAMES.length); }
    public void restart() {
        t = 0;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) { baseYaw = mc.player.getYRot(); basePitch = mc.player.getXRot(); }
    }

    @Override public void adjust(String s, int dir) {
        if (!s.equalsIgnoreCase("dance")) { super.adjust(s, dir); return; }
        int d = dance() + dir;
        if (d < 1) d = NAMES.length;
        if (d > NAMES.length) d = 1;
        settings.put("dance", (double) d);
        restart();
    }
    @Override public String valueText(String s) {
        return s.equalsIgnoreCase("dance") ? dance() + " " + NAMES[dance() - 1] : super.valueText(s);
    }

    @Override protected void onEnable() { restart(); }
    @Override protected void onDisable() { release(Minecraft.getInstance()); }

    private void release(Minecraft mc) {
        var o = mc.options;
        o.keyUp.setDown(false); o.keyDown.setDown(false); o.keyLeft.setDown(false); o.keyRight.setDown(false);
        o.keyJump.setDown(false); o.keyShift.setDown(false);
    }

    private void yaw(Minecraft mc, double add) { mc.player.setYRot(mc.player.getYRot() + (float) add); }
    private void setYaw(Minecraft mc, double v) { mc.player.setYRot((float) v); }
    private void pitch(Minecraft mc, double v) { mc.player.setXRot((float) Math.clamp(v, -90, 90)); }
    private void swing(Minecraft mc) { mc.player.swing(InteractionHand.MAIN_HAND); }

    @Override public void tick(Minecraft mc) {
        if (mc.screen != null) return;
        release(mc);
        var o = mc.options;
        int n = t++;
        switch (dance()) {
            case 1 -> yaw(mc, 12);
            case 2 -> yaw(mc, 30);
            case 3 -> yaw(mc, 4);
            case 4 -> yaw(mc, -12);
            case 5 -> o.keyShift.setDown((n / 3) % 2 == 0);
            case 6 -> o.keyShift.setDown((n / 10) % 2 == 0);
            case 7 -> o.keyJump.setDown(true);
            case 8 -> { if (n % 6 == 0) swing(mc); }
            case 9 -> { if (n % 2 == 0) swing(mc); }
            case 10 -> pitch(mc, basePitch + 25 * Math.sin(n * 0.3));
            case 11 -> pitch(mc, basePitch + 40 * Math.sin(n * 0.6));
            case 12 -> setYaw(mc, baseYaw + 30 * Math.sin(n * 0.5));
            case 13 -> setYaw(mc, baseYaw + 90 * Math.sin(n * 0.1));
            case 14 -> { if ((n / 10) % 2 == 0) o.keyLeft.setDown(true); else o.keyRight.setDown(true); }
            case 15 -> { o.keyDown.setDown(true); yaw(mc, 2); }
            case 16 -> { o.keyUp.setDown(true); yaw(mc, 6); }
            case 17 -> { o.keyUp.setDown(true); if ((n / 8) % 2 == 0) o.keyLeft.setDown(true); else o.keyRight.setDown(true); }
            case 18 -> { o.keyUp.setDown(true); if (n % 20 == 0) yaw(mc, 90); }
            case 19 -> { yaw(mc, 15); o.keyJump.setDown(true); }
            case 20 -> { yaw(mc, 15); o.keyShift.setDown((n / 4) % 2 == 0); }
            case 21 -> { if (n % 12 < 6) o.keyJump.setDown(true); else o.keyShift.setDown(true); }
            case 22 -> { o.keyShift.setDown(true); yaw(mc, 25); }
            case 23 -> { if (n % 8 == 0) yaw(mc, 45); }
            case 24 -> { if (n % 5 == 0) { yaw(mc, 90); swing(mc); } }
            case 25 -> { yaw(mc, 40); o.keyJump.setDown(true); }
            case 26 -> { pitch(mc, basePitch + 20 * Math.sin(n * 0.4)); setYaw(mc, baseYaw + 20 * Math.sin(n * 0.25)); }
            case 27 -> { o.keyShift.setDown(true); if (n % 8 == 0) swing(mc); }
            case 28 -> { pitch(mc, -60); if (n % 15 == 0) swing(mc); }
            case 29 -> { int ph = n % 40; pitch(mc, basePitch + 60 * (ph < 20 ? ph / 20.0 : (40 - ph) / 20.0)); }
            case 30 -> { if ((n / 4) % 2 == 0) o.keyLeft.setDown(true); else o.keyRight.setDown(true); if (n % 4 == 0) swing(mc); }
            case 31 -> { o.keyJump.setDown(true); if (n % 5 == 0) swing(mc); }
            case 32 -> { if (n % 38 < 18) yaw(mc, 20); }
            case 33 -> o.keyShift.setDown(n % 2 == 0);
            case 34 -> { boolean down = n % 30 < 15; pitch(mc, down ? 80 : -20); o.keyShift.setDown(down); }
            case 35 -> { o.keyUp.setDown(true); if ((n / 6) % 2 == 0) o.keyLeft.setDown(true); else o.keyRight.setDown(true); }
            default -> { o.keyUp.setDown(true); o.keyJump.setDown(true); }
        }
    }
}
