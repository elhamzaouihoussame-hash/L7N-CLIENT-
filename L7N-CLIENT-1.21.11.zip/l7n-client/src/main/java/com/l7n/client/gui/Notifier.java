package com.l7n.client.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public final class Notifier {
    private Notifier() {}
    private static String title = "", text = "";
    private static long start, until;

    public static void push(String t, String s) {
        title = t; text = s; start = System.currentTimeMillis(); until = start + 4500;
    }

    public static void render(GuiGraphics g, Minecraft mc) {
        long now = System.currentTimeMillis();
        if (now > until) return;
        float a = Math.min(1f, (until - now) / 500f) * Math.min(1f, (now - start) / 150f);
        int w = Math.max(mc.font.width(title), mc.font.width(text)) + 28, h = 30;
        int cx = mc.getWindow().getGuiScaledWidth() / 2, y = mc.getWindow().getGuiScaledHeight() / 3;
        g.fill(cx - w / 2, y, cx + w / 2, y + h, Anim.alpha(0x0B0618, 0.9f * a));
        g.fill(cx - w / 2, y, cx - w / 2 + 2, y + h, Anim.alpha(0xEF4444, a));
        g.drawCenteredString(mc.font, title, cx, y + 5, Anim.alpha(0xEF4444, a));
        g.drawCenteredString(mc.font, text, cx, y + 17, Anim.alpha(0xFFFFFF, a));
    }
}
