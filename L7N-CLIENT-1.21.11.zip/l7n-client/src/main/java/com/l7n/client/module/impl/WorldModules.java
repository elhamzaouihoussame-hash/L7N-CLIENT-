package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class WorldModules {
    private WorldModules() {}

    public static class AutoMine extends Module {
        public AutoMine() { super("AutoMine", "Holds left click to mine continuously", Category.MISC); }
        @Override public void tick(Minecraft mc) { if (mc.screen == null) mc.options.keyAttack.setDown(true); }
        @Override protected void onDisable() { Minecraft.getInstance().options.keyAttack.setDown(false); }
    }

    /** Places the block you hold under your feet. */
    public static class Scaffold extends Module {
        public Scaffold() { super("Scaffold", "Places held blocks under you", Category.MISC); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (!(mc.player.getMainHandItem().getItem() instanceof BlockItem)) return;
            BlockUtil.place(mc, mc.player.blockPosition().below());
        }
    }

    /** Builds under and around you automatically: bridging, filling holes, with hotbar auto-switch. */
    public static class LimitlessBuilder extends Module {
        private int cd;
        public LimitlessBuilder() {
            super("LimitlessBuilder", "Auto-places blocks under/around you (bridge, tower, fill)", Category.MISC);
            addSetting("radius", 1, 1); addSetting("delay", 0, 1); addToggle("autoswitch", true);
        }
        private boolean ensureBlock(Minecraft mc) {
            if (mc.player.getMainHandItem().getItem() instanceof BlockItem) return true;
            if (!on("autoswitch")) return false;
            int slot = BlockUtil.hotbar(mc, s -> s.getItem() instanceof BlockItem);
            if (slot < 0) return false;
            BlockUtil.select(mc, slot);
            return true;
        }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (cd > 0) { cd--; return; }
            if (!ensureBlock(mc)) return;
            BlockPos feet = mc.player.blockPosition().below();
            int r = (int) get("radius");
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                    if (BlockUtil.place(mc, feet.offset(dx, 0, dz))) { cd = (int) get("delay"); return; }
        }
    }

    /** All block entities of a chunk. */
    static List<BlockEntity> blockEntities(ChunkAccess c) {
        List<BlockEntity> l = new java.util.ArrayList<>();
        for (BlockPos p : c.getBlockEntitiesPos()) {
            BlockEntity be = c.getBlockEntity(p);
            if (be != null) l.add(be);
        }
        return l;
    }

    private static boolean storage(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity
                || be instanceof AbstractFurnaceBlockEntity || be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                || be instanceof BrewingStandBlockEntity || be instanceof EnderChestBlockEntity || be instanceof BedBlockEntity;
    }
    private static boolean stash(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity;
    }

    /** Shared by BaseFinder/ChestFinder: counts matching block entities in a chunk and returns the area they occupy. */
    private static void scanCluster(FinderModule m, ChunkAccess c, List<FinderModule.Found> out, boolean onlyStash, String label, int minimum) {
        int n = 0, minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (BlockEntity be : blockEntities(c)) {
            if (!(onlyStash ? stash(be) : storage(be))) continue;
            BlockPos p = be.getBlockPos();
            n++;
            minX = Math.min(minX, p.getX()); minY = Math.min(minY, p.getY()); minZ = Math.min(minZ, p.getZ());
            maxX = Math.max(maxX, p.getX()); maxY = Math.max(maxY, p.getY()); maxZ = Math.max(maxZ, p.getZ());
        }
        if (n == 0 || n < minimum) return;
        AABB area;
        if (m.on("chunkbox")) {
            int cx = c.getPos().getMinBlockX(), cz = c.getPos().getMinBlockZ();
            area = new AABB(cx, minY, cz, cx + 16, maxY + 1, cz + 16);
        } else {
            area = new AABB(minX, minY, minZ, maxX + 1, maxY + 1, maxZ + 1).inflate(1.0);
        }
        out.add(new FinderModule.Found(BlockPos.containing(area.getCenter()), label + " " + n, area));
    }

    public static class BaseFinder extends FinderModule {
        public BaseFinder() { super("BaseFinder", "Finds bases: green area over chunks with many containers"); addSetting("minimum", 5, 1); addToggle("chunkbox", false); }
        @Override protected void scan(ChunkAccess c, List<Found> out) { scanCluster(this, c, out, false, "Base", (int) get("minimum")); }
    }

    /** Chunks with many player-made blocks (redstone parts, beds, tables, metal blocks...). */
    public static class BaseBlocks extends FinderModule {
        public final Set<Block> blocks = new LinkedHashSet<>(List.of(
                Blocks.BEACON, Blocks.ENCHANTING_TABLE, Blocks.ANVIL, Blocks.TNT, Blocks.OBSERVER, Blocks.PISTON, Blocks.STICKY_PISTON,
                Blocks.HOPPER, Blocks.DISPENSER, Blocks.DROPPER, Blocks.REDSTONE_LAMP, Blocks.IRON_BLOCK, Blocks.GOLD_BLOCK,
                Blocks.DIAMOND_BLOCK, Blocks.EMERALD_BLOCK, Blocks.NETHERITE_BLOCK, Blocks.LANTERN, Blocks.SOUL_LANTERN,
                Blocks.CRAFTING_TABLE, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.BOOKSHELF));
        public BaseBlocks() { super("BaseBlocks", "Finds chunks with many player-made blocks"); addSetting("minimum", 6, 1); }
        private boolean match(BlockState st) { return blocks.contains(st.getBlock()) || st.is(net.minecraft.tags.BlockTags.BEDS); }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            int minX = c.getPos().getMinBlockX(), minZ = c.getPos().getMinBlockZ();
            int n = 0, x0 = Integer.MAX_VALUE, y0 = Integer.MAX_VALUE, z0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, y1 = Integer.MIN_VALUE, z1 = Integer.MIN_VALUE;
            LevelChunkSection[] secs = c.getSections();
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection s = secs[i];
                if (s == null || s.hasOnlyAir() || !s.maybeHas(this::match)) continue;
                int baseY = (c.getMinSectionY() + i) << 4;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                    if (!match(s.getBlockState(x, y, z))) continue;
                    n++;
                    x0 = Math.min(x0, minX + x); y0 = Math.min(y0, baseY + y); z0 = Math.min(z0, minZ + z);
                    x1 = Math.max(x1, minX + x); y1 = Math.max(y1, baseY + y); z1 = Math.max(z1, minZ + z);
                }
            }
            if (n < (int) get("minimum")) return;
            AABB area = new AABB(x0, y0, z0, x1 + 1, y1 + 1, z1 + 1).inflate(1.0);
            out.add(new Found(BlockPos.containing(area.getCenter()), "Base blocks " + n, area));
        }
    }

    public static class ChestFinder extends FinderModule {
        public ChestFinder() { super("ChestFinder", "Finds stashes (many chests/barrels/shulkers)"); addSetting("minimum", 8, 1); addToggle("chunkbox", false); }
        @Override protected void scan(ChunkAccess c, List<Found> out) { scanCluster(this, c, out, true, "Stash", (int) get("minimum")); }
    }

    /** Spawners (normal + trial) with boxes and tracer lines. */
    public static class SpawnerEsp extends FinderModule {
        public SpawnerEsp() { super("SpawnerESP", "Finds mob spawners (boxes + lines)"); addSetting("radius", 8, 1); }
        @Override protected int color() { return 0xFFEF4444; }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            for (BlockEntity be : blockEntities(c)) {
                if (be instanceof SpawnerBlockEntity) out.add(new Found(be.getBlockPos(), "Spawner"));
                else if (be instanceof TrialSpawnerBlockEntity) out.add(new Found(be.getBlockPos(), "Trial Spawner"));
            }
        }
    }

    /** Chests, hoppers, barrels, shulkers, furnaces... each type has its own colour, with boxes and lines from the crosshair. */
    public static class StorageEsp extends FinderModule {
        public StorageEsp() {
            super("StorageESP", "Chests, hoppers, barrels, shulkers... colored boxes + lines");
            addSetting("radius", 8, 1);
            addToggle("chests", true); addToggle("barrels", true); addToggle("shulkers", true);
            addToggle("hoppers", true); addToggle("furnaces", true); addToggle("others", true);
        }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            for (BlockEntity be : blockEntities(c)) {
                if (!storage(be)) continue;
                String label; int col; boolean show;
                if (be instanceof ChestBlockEntity) {
                    boolean trapped = be instanceof TrappedChestBlockEntity;
                    label = trapped ? "Trapped Chest" : "Chest"; col = trapped ? 0xFFEF4444 : 0xFFF59E0B; show = on("chests");
                } else if (be instanceof EnderChestBlockEntity) { label = "Ender Chest"; col = 0xFF22D3EE; show = on("chests"); }
                else if (be instanceof BarrelBlockEntity) { label = "Barrel"; col = 0xFFB45309; show = on("barrels"); }
                else if (be instanceof ShulkerBoxBlockEntity) { label = "Shulker"; col = 0xFFC084FC; show = on("shulkers"); }
                else if (be instanceof HopperBlockEntity) { label = "Hopper"; col = 0xFFE5E7EB; show = on("hoppers"); }
                else if (be instanceof AbstractFurnaceBlockEntity) { label = "Furnace"; col = 0xFF9CA3AF; show = on("furnaces"); }
                else { label = be.getClass().getSimpleName().replace("BlockEntity", ""); col = 0xFF60A5FA; show = on("others"); }
                if (show) out.add(new Found(be.getBlockPos(), label, null, col));
            }
        }
    }

    public static class ShulkerFinder extends FinderModule {
        public ShulkerFinder() { super("ShulkerFinder", "Finds shulker boxes"); }
        @Override protected int color() { return 0xFFC084FC; }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            for (BlockEntity be : blockEntities(c)) if (be instanceof ShulkerBoxBlockEntity) out.add(new Found(be.getBlockPos(), "Shulker"));
        }
    }

    public static class BlockEsp extends FinderModule {
        public final Set<Block> blocks = new LinkedHashSet<>();
        public BlockEsp() {
            super("BlockESP", "Finds chosen blocks (.blockesp add <id>)");
            blocks.add(Blocks.ANCIENT_DEBRIS); blocks.add(Blocks.DIAMOND_ORE); blocks.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        }
        @Override protected int color() { return 0xFFFACC15; }
        @Override public void saveExtra(com.google.gson.JsonObject o) {
            com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
            for (Block b : blocks) arr.add(BuiltInRegistries.BLOCK.getKey(b).toString());
            o.add("blocks", arr);
        }
        @Override public void loadExtra(com.google.gson.JsonObject o) {
            if (!o.has("blocks")) return;
            blocks.clear();
            for (var e : o.getAsJsonArray("blocks")) {
                var id = net.minecraft.resources.Identifier.tryParse(e.getAsString());
                if (id != null) BuiltInRegistries.BLOCK.getOptional(id).ifPresent(blocks::add);
            }
        }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            if (blocks.isEmpty()) return;
            int minX = c.getPos().getMinBlockX(), minZ = c.getPos().getMinBlockZ();
            LevelChunkSection[] secs = c.getSections();
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection s = secs[i];
                if (s == null || s.hasOnlyAir() || !s.maybeHas(st -> blocks.contains(st.getBlock()))) continue;
                int baseY = (c.getMinSectionY() + i) << 4;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                    BlockState st = s.getBlockState(x, y, z);
                    if (blocks.contains(st.getBlock())) {
                        out.add(new Found(new BlockPos(minX + x, baseY + y, minZ + z), BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath()));
                        if (out.size() > 400) return;
                    }
                }
            }
        }
    }
}
