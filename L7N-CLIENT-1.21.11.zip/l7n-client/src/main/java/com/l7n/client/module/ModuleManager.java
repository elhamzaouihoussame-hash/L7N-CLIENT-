package com.l7n.client.module;

import com.l7n.client.module.impl.*;
import net.minecraft.client.Minecraft;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> all = new ArrayList<>();

    public ModuleManager() {
        // Movement (idea: Meteor-style)
        all.add(new SprintModule());
        all.add(new FlightModule());
        // Render
        all.add(new CoordsModule());
        all.add(new ArrayListModule());
        // Misc
        all.add(new WatermarkModule());
        all.get(all.size() - 1).setEnabled(true);
        all.get(all.size() - 2).setEnabled(true);
    }
    public List<Module> in(Module.Category c) { return all.stream().filter(m -> m.category == c).toList(); }
    public <T extends Module> T get(Class<T> c) { for (Module m : all) if (c.isInstance(m)) return c.cast(m); return null; }
    public void tick(Minecraft mc) { for (Module m : all) if (m.isEnabled()) m.tick(mc); }
}
