package com.l7n.client.module.impl;
import com.l7n.client.module.Module;
public class WatermarkModule extends Module {
    public WatermarkModule() { super("Watermark", "L7N logo + name on screen", Category.RENDER); }
}
