package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class FullbrightModule extends Module {
    public FullbrightModule() { super("Fullbright", "See in the dark", Category.RENDER); }
    @Override public void tick(Minecraft mc) {
        if (!mc.player.hasEffect(MobEffects.NIGHT_VISION))
            mc.player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 100000, 0, false, false));
    }
    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.removeEffect(MobEffects.NIGHT_VISION);
    }
}
