package com.l7n.client.module.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.l7n.client.CommandManager;
import com.l7n.client.L7NClient;
import com.l7n.client.Util;
import com.l7n.client.gui.Notifier;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.GameType;
import net.minecraft.world.scores.PlayerTeam;
import java.util.*;
import java.util.regex.Pattern;

public final class StaffModules {
    private StaffModules() {}

    /** Staff members online (rank text in tab/team prefix, or names you add with .staff name <player>). Shows skin heads. */
    public static class StaffList extends Module {
        public final Set<String> keywords = new LinkedHashSet<>(List.of("owner", "admin", "mod", "helper", "staff", "dev", "manager", "support", "trial", "operator"));
        public final Set<String> names = new LinkedHashSet<>();
        private final List<String> lines = new ArrayList<>();
        private final List<PlayerInfo> icons = new ArrayList<>();
        private final Set<String> seen = new HashSet<>();
        private int cd; private boolean first = true;

        public StaffList() {
            super("StaffList", "Staff online with skin heads (move it with .hud)", Category.RENDER);
            addToggle("alert", true); addToggle("spectators", false);
        }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() { return lines; }
        @Override public List<PlayerInfo> lineIcons() { return icons; }
        @Override protected void onEnable() { first = true; seen.clear(); cd = 0; }
        @Override protected void onDisable() { lines.clear(); icons.clear(); }

        @Override public void saveExtra(JsonObject o) {
            JsonArray k = new JsonArray(), n = new JsonArray();
            keywords.forEach(k::add); names.forEach(n::add);
            o.add("keywords", k); o.add("names", n);
        }
        @Override public void loadExtra(JsonObject o) {
            if (o.has("keywords")) { keywords.clear(); o.getAsJsonArray("keywords").forEach(e -> keywords.add(e.getAsString())); }
            if (o.has("names")) { names.clear(); o.getAsJsonArray("names").forEach(e -> names.add(e.getAsString())); }
        }

        public String display(PlayerInfo pi, String name) {
            Component shown = pi.getTabListDisplayName();
            return shown != null ? shown.getString() : PlayerTeam.formatNameForTeam(pi.getTeam(), Component.literal(name)).getString();
        }
        /** Rank/prefix texts currently shown in the tab list, with counts (use them with .staff add <word>). */
        public Map<String, Integer> ranks(Minecraft mc) {
            Map<String, Integer> m = new LinkedHashMap<>();
            var conn = mc.getConnection();
            if (conn == null) return m;
            for (PlayerInfo pi : conn.getOnlinePlayers()) {
                String n = Util.name(pi);
                String rest = display(pi, n).replaceAll("(?i)" + Pattern.quote(n), "").trim();
                if (!rest.isEmpty()) m.merge(rest, 1, Integer::sum);
            }
            return m;
        }
        public boolean isStaff(PlayerInfo pi) {
            String name = Util.name(pi);
            if (names.contains(name.toLowerCase())) return true;
            if (pi.getGameMode() == GameType.SPECTATOR && on("spectators")) return true;
            String rest = display(pi, name).replaceAll("(?i)" + Pattern.quote(name), "").toLowerCase();
            for (String k : keywords) if (rest.contains(k.toLowerCase())) return true;
            return false;
        }

        @Override public void tick(Minecraft mc) {
            if (cd-- > 0) return;
            cd = 20;
            var conn = mc.getConnection();
            if (conn == null) return;
            List<String> found = new ArrayList<>();
            List<PlayerInfo> foundInfo = new ArrayList<>();
            Set<String> now = new HashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) {
                if (!isStaff(pi)) continue;
                String name = Util.name(pi), full = display(pi, name);
                found.add((full.isBlank() ? name : full.trim()) + (pi.getGameMode() == GameType.SPECTATOR ? " [SPEC]" : ""));
                foundInfo.add(pi);
                now.add(name);
            }
            lines.clear(); icons.clear();
            if (!found.isEmpty()) {
                lines.add("Staff (" + found.size() + ")"); icons.add(null);
                for (int i = 0; i < found.size() && i < 12; i++) { lines.add(found.get(i)); icons.add(foundInfo.get(i)); }
            }
            if (on("alert") && !first) for (String n : now) if (!seen.contains(n)) CommandManager.info("§cStaff online: §f" + n);
            seen.clear(); seen.addAll(now); first = false;
        }
    }

    /** Heuristic vanish detection + a centre-screen alert when a spectator/admin is watching you. */
    public static class AntiVanish extends Module {
        private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
        private final List<String> lines = new ArrayList<>();
        private final Set<String> announced = new HashSet<>();
        private final Map<String, Long> watchers = new HashMap<>();
        private int cd, watchCd;

        public AntiVanish() {
            super("AntiVanish", "Detects vanished players and admins watching you", Category.MISC);
            addToggle("chat", true); addToggle("watch", true);
            addSetting("watchrange", 90, 5); addSetting("watchheight", 90, 5); addSetting("ghostrange", 10, 1);
        }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() { return lines; }
        @Override protected void onDisable() { lines.clear(); announced.clear(); watchers.clear(); }

        private void checkWatchers(Minecraft mc, net.minecraft.client.multiplayer.ClientPacketListener conn) {
            StaffList sl = L7NClient.modules.get(StaffList.class);
            long now = System.currentTimeMillis();
            for (var p : mc.level.players()) {
                if (p == mc.player) continue;
                PlayerInfo pi = conn.getPlayerInfo(p.getUUID());
                double hd = Math.hypot(p.getX() - mc.player.getX(), p.getZ() - mc.player.getZ()), vd = Math.abs(p.getY() - mc.player.getY());
                boolean inRange = hd <= get("watchrange") && vd <= get("watchheight");
                boolean spec = pi != null && pi.getGameMode() == GameType.SPECTATOR && inRange;
                boolean ghost = pi == null && p.getUUID().version() != 2 && hd <= get("ghostrange") && vd <= get("watchheight");
                if (!spec && !ghost) continue;
                String name = p.getName().getString();
                Long last = watchers.get(name);
                if (last != null && now - last < 30000) continue;
                watchers.put(name, now);
                boolean staff = sl != null && pi != null && sl.isStaff(pi);
                Notifier.push(staff ? "ADMIN IS WATCHING YOU" : (ghost ? "HIDDEN PLAYER NEAR YOU" : "SPECTATOR IS WATCHING YOU"), name);
                CommandManager.info("§c" + (staff ? "Admin " : "Spectator ") + name + " is watching you");
            }
        }

        @Override public void tick(Minecraft mc) {
            var conn = mc.getConnection();
            if (conn == null || mc.level == null) return;
            if (on("watch") && watchCd-- <= 0) { watchCd = 10; checkWatchers(mc, conn); }
            if (cd-- > 0) return;
            cd = 40;
            Set<String> tab = new HashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) tab.add(Util.name(pi).toLowerCase());
            Set<String> flagged = new LinkedHashSet<>();
            for (var p : mc.level.players()) {
                if (p == mc.player) continue;
                if (conn.getPlayerInfo(p.getUUID()) == null && p.getUUID().version() != 2) flagged.add(p.getName().getString() + " (near, not in tab)");
            }
            for (PlayerTeam t : mc.level.getScoreboard().getPlayerTeams())
                for (String n : t.getPlayers())
                    if (NAME.matcher(n).matches() && !tab.contains(n.toLowerCase())) flagged.add(n + " (team, not in tab)");
            lines.clear();
            if (!flagged.isEmpty()) {
                lines.add("Vanished? (" + flagged.size() + ")");
                int i = 0;
                for (String f : flagged) { if (i++ < 8) lines.add(" " + f); }
            }
            if (on("chat")) for (String f : flagged) if (announced.add(f)) CommandManager.info("§eVanished? §f" + f);
        }
    }

    /** Toggles CoreProtect inspect mode so clicking a block shows who placed/broke it. Needs CoreProtect + permission on the server. */
    public static class Inspector extends Module {
        public Inspector() { super("Inspector", "Click a block to see who placed it (CoreProtect)", Category.MISC); }
        private void send() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) mc.player.connection.sendCommand("co inspect");
        }
        @Override protected void onEnable() { send(); }
        @Override protected void onDisable() { send(); }
    }
}
