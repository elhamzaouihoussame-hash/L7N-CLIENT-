package com.l7n.client.module.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.context.ParsedArgument;
import com.mojang.brigadier.context.ParsedCommandNode;
import com.mojang.brigadier.context.StringRange;
import com.mojang.brigadier.suggestion.Suggestion;
import com.l7n.client.CommandManager;
import com.l7n.client.L7NClient;
import com.l7n.client.Util;
import com.l7n.client.gui.Notifier;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.GameType;
import net.minecraft.world.scores.PlayerTeam;
import java.util.*;
import java.util.regex.Pattern;

public final class StaffModules {
    private StaffModules() {}

    /** Staff members online (rank text in tab/team prefix, or names you add with .staff name <player>). Shows skin heads. */
    public static class StaffList extends Module {
        public final Set<String> keywords = new LinkedHashSet<>(List.of("owner", "admin", "mod", "helper", "staff", "dev", "manager", "support", "trial", "operator"));
        public final Set<String> names = new LinkedHashSet<>();
        private final List<String> lines = new ArrayList<>();
        private final List<PlayerInfo> icons = new ArrayList<>();
        private final Set<String> seen = new HashSet<>();
        private int cd; private boolean first = true;

        public StaffList() {
            super("StaffList", "Staff online with skin heads (move it with .hud)", Category.RENDER);
            addToggle("alert", true); addToggle("spectators", false);
        }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() { return lines; }
        @Override public List<PlayerInfo> lineIcons() { return icons; }
        @Override protected void onEnable() { first = true; seen.clear(); cd = 0; }
        @Override protected void onDisable() { lines.clear(); icons.clear(); }

        @Override public void saveExtra(JsonObject o) {
            JsonArray k = new JsonArray(), n = new JsonArray();
            keywords.forEach(k::add); names.forEach(n::add);
            o.add("keywords", k); o.add("names", n);
        }
        @Override public void loadExtra(JsonObject o) {
            if (o.has("keywords")) { keywords.clear(); o.getAsJsonArray("keywords").forEach(e -> keywords.add(e.getAsString())); }
            if (o.has("names")) { names.clear(); o.getAsJsonArray("names").forEach(e -> names.add(e.getAsString())); }
        }

        public String display(PlayerInfo pi, String name) {
            Component shown = pi.getTabListDisplayName();
            return shown != null ? shown.getString() : PlayerTeam.formatNameForTeam(pi.getTeam(), Component.literal(name)).getString();
        }
        /** Rank/prefix texts currently shown in the tab list, with counts (use them with .staff add <word>). */
        public Map<String, Integer> ranks(Minecraft mc) {
            Map<String, Integer> m = new LinkedHashMap<>();
            var conn = mc.getConnection();
            if (conn == null) return m;
            for (PlayerInfo pi : conn.getOnlinePlayers()) {
                String n = Util.name(pi);
                String rest = display(pi, n).replaceAll("(?i)" + Pattern.quote(n), "").trim();
                if (!rest.isEmpty()) m.merge(rest, 1, Integer::sum);
            }
            return m;
        }
        public boolean isStaff(PlayerInfo pi) {
            String name = Util.name(pi);
            if (names.contains(name.toLowerCase())) return true;
            if (pi.getGameMode() == GameType.SPECTATOR && on("spectators")) return true;
            String rest = display(pi, name).replaceAll("(?i)" + Pattern.quote(name), "").toLowerCase();
            for (String k : keywords) if (rest.contains(k.toLowerCase())) return true;
            return false;
        }

        @Override public void tick(Minecraft mc) {
            if (cd-- > 0) return;
            cd = 20;
            var conn = mc.getConnection();
            if (conn == null) return;
            List<String> found = new ArrayList<>();
            List<PlayerInfo> foundInfo = new ArrayList<>();
            Set<String> now = new HashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) {
                if (!isStaff(pi)) continue;
                String name = Util.name(pi), full = display(pi, name);
                found.add((full.isBlank() ? name : full.trim()) + (pi.getGameMode() == GameType.SPECTATOR ? " [SPEC]" : ""));
                foundInfo.add(pi);
                now.add(name);
            }
            lines.clear(); icons.clear();
            if (!found.isEmpty()) {
                lines.add("Staff (" + found.size() + ")"); icons.add(null);
                for (int i = 0; i < found.size() && i < 12; i++) { lines.add(found.get(i)); icons.add(foundInfo.get(i)); }
            }
            if (on("alert") && !first) for (String n : now) if (!seen.contains(n)) CommandManager.info("§cStaff online: §f" + n);
            seen.clear(); seen.addAll(now); first = false;
        }
    }

    /**
     * Finds admins who are in spectator mode or vanished.
     * - Spectator: the tab list tells every client each player's game mode (the server never sends a spectator's body to normal players).
     * - Vanish: asks the server for the player-name suggestions of /msg and compares them with the tab list; names that are
     *   suggested but missing from the tab list are vanished players (works when the vanish plugin only hides tab/entities).
     * - Extra hints: players in a scoreboard team but not in tab, and player entities that are not in tab.
     */
    public static class AntiVanish extends Module {
        private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
        private static final String[] PROBES = {"minecraft:msg ", "msg ", "minecraft:tell "};
        private final List<String> lines = new ArrayList<>();
        private final Set<String> announced = new HashSet<>();
        private final Set<String> specNow = new LinkedHashSet<>();
        private final Set<String> specAnnounced = new HashSet<>();
        private final Set<String> heur = new LinkedHashSet<>();
        private final Map<String, Long> sugVanished = new LinkedHashMap<>();
        private int specCd, sugCd, cd, probe;

        public AntiVanish() {
            super("AntiVanish", "Detects admins in spectator mode or vanished", Category.MISC);
            addToggle("chat", true); addToggle("spectator", true); addToggle("suggest", true); addToggle("staffonly", false);
            addSetting("ghostrange", 10, 1);
        }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() { return lines; }
        @Override protected void onDisable() {
            lines.clear(); announced.clear(); specNow.clear(); specAnnounced.clear(); heur.clear(); sugVanished.clear();
        }

        private StaffList staffList() { return L7NClient.modules.get(StaffList.class); }
        private boolean isAdminName(String n) { StaffList sl = staffList(); return sl != null && sl.names.contains(n.toLowerCase()); }

        private void rebuild() {
            lines.clear();
            if (!specNow.isEmpty()) {
                lines.add("Spectators (" + specNow.size() + ")");
                int i = 0;
                for (String n : specNow) if (i++ < 8) lines.add(" " + n);
            }
            Set<String> v = new LinkedHashSet<>(sugVanished.keySet());
            v.addAll(heur);
            if (!v.isEmpty()) {
                lines.add("Vanished? (" + v.size() + ")");
                int i = 0;
                for (String n : v) if (i++ < 8) lines.add(" " + n);
            }
        }

        private void scanSpectators(Minecraft mc, net.minecraft.client.multiplayer.ClientPacketListener conn) {
            StaffList sl = staffList();
            String me = mc.player.getName().getString();
            Set<String> found = new LinkedHashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) {
                if (pi.getGameMode() != GameType.SPECTATOR) continue;
                String n = Util.name(pi);
                if (n.equalsIgnoreCase(me)) continue;
                boolean staff = sl != null && sl.isStaff(pi);
                if (on("staffonly") && !staff) continue;
                found.add(n);
                if (specAnnounced.add(n)) {
                    Notifier.push(staff ? "ADMIN IN SPECTATOR MODE" : "PLAYER IN SPECTATOR MODE", n);
                    if (on("chat")) CommandManager.info("§e" + (staff ? "Admin " : "Player ") + n + " is in spectator mode");
                }
            }
            specAnnounced.retainAll(found);
            specNow.clear(); specNow.addAll(found);
            rebuild();
        }

        private void probeSuggestions(Minecraft mc, net.minecraft.client.multiplayer.ClientPacketListener conn) {
            try {
                String input = PROBES[probe++ % PROBES.length];
                Map<String, ParsedArgument<Object, ?>> args = new HashMap<>();
                CommandContext<Object> ctx = new CommandContext<>(null, input, args, null, null,
                        new ArrayList<ParsedCommandNode<Object>>(), StringRange.at(0), null, null, false);
                conn.getSuggestionsProvider().customSuggestion(ctx).thenAccept(sug -> {
                    Set<String> names = new HashSet<>();
                    for (Suggestion x : sug.getList()) names.add(x.getText());
                    mc.execute(() -> onSuggestions(mc, names));
                });
            } catch (Throwable ignored) {}
        }

        private void onSuggestions(Minecraft mc, Set<String> names) {
            var conn = mc.getConnection();
            if (conn == null || mc.player == null) return;
            Set<String> tab = new HashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) tab.add(Util.name(pi).toLowerCase());
            String me = mc.player.getName().getString();
            long now = System.currentTimeMillis();
            for (String n : names) {
                if (!NAME.matcher(n).matches() || n.equalsIgnoreCase(me) || tab.contains(n.toLowerCase())) continue;
                if (sugVanished.put(n, now) == null) {
                    boolean admin = isAdminName(n);
                    Notifier.push(admin ? "VANISHED ADMIN" : "VANISHED PLAYER", n);
                    if (on("chat")) CommandManager.info("§c" + (admin ? "Vanished admin: " : "Vanished player: ") + n);
                }
            }
            sugVanished.values().removeIf(t -> now - t > 60000);
            rebuild();
        }

        @Override public void tick(Minecraft mc) {
            var conn = mc.getConnection();
            if (conn == null || mc.level == null) return;
            if (on("spectator") && specCd-- <= 0) { specCd = 10; scanSpectators(mc, conn); }
            if (on("suggest") && sugCd-- <= 0 && mc.screen == null) { sugCd = 100; probeSuggestions(mc, conn); }
            if (cd-- > 0) return;
            cd = 40;
            Set<String> tab = new HashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) tab.add(Util.name(pi).toLowerCase());
            heur.clear();
            for (var p : mc.level.players()) {
                if (p == mc.player) continue;
                if (conn.getPlayerInfo(p.getUUID()) == null && p.getUUID().version() != 2
                        && mc.player.distanceTo(p) <= get("ghostrange"))
                    heur.add(p.getName().getString() + " (near, not in tab)");
            }
            for (PlayerTeam t : mc.level.getScoreboard().getPlayerTeams())
                for (String n : t.getPlayers())
                    if (NAME.matcher(n).matches() && !tab.contains(n.toLowerCase())) heur.add(n + " (team, not in tab)");
            if (on("chat")) for (String f : heur) if (announced.add(f)) CommandManager.info("§eVanished? §f" + f);
            rebuild();
        }
    }

    /** Toggles CoreProtect inspect mode so clicking a block shows who placed/broke it. Needs CoreProtect + permission on the server. */
    public static class Inspector extends Module {
        public Inspector() { super("Inspector", "Click a block to see who placed it (CoreProtect)", Category.MISC); }
        private void send() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) mc.player.connection.sendCommand("co inspect");
        }
        @Override protected void onEnable() { send(); }
        @Override protected void onDisable() { send(); }
    }
}
