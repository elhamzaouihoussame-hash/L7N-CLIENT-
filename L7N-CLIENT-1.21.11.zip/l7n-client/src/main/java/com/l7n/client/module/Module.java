package com.l7n.client.module;

import net.minecraft.client.Minecraft;

public abstract class Module {
    public final String name, description;
    public final Category category;
    private boolean enabled;
    public float anim; // 0..1 used by the GUI for the toggle animation

    public enum Category { COMBAT, MOVEMENT, RENDER, MISC }

    protected Module(String name, String description, Category category) {
        this.name = name; this.description = description; this.category = category;
    }
    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }
    protected void onEnable() {}
    protected void onDisable() {}
    public void tick(Minecraft mc) {}
}
