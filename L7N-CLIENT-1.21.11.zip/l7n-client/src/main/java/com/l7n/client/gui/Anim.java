package com.l7n.client.gui;
/** Small animation helpers (own implementation, Anubis-style slide + fade + stagger). */
public final class Anim {
    public static float easeOutBack(float t) { t = Math.clamp(t, 0f, 1f); float c1 = 1.70158f, c3 = c1 + 1; return 1 + c3 * (float) Math.pow(t - 1, 3) + c1 * (float) Math.pow(t - 1, 2); }
    public static float easeOutCubic(float t) { t = Math.clamp(t, 0f, 1f); return 1 - (float) Math.pow(1 - t, 3); }
    public static float approach(float cur, float target, float speed) { return cur + (target - cur) * Math.min(1f, speed); }
    public static int lerpColor(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int g = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int bl = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        int al = (int) (((a >>> 24)) + ((((b >>> 24)) - ((a >>> 24))) * t));
        return al << 24 | r << 16 | g << 8 | bl;
    }
    public static int alpha(int color, float a) { return ((int) (Math.clamp(a, 0f, 1f) * 255) << 24) | (color & 0xFFFFFF); }
}
