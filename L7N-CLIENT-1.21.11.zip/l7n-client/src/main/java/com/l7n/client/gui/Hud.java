package com.l7n.client.gui;

import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import com.l7n.client.module.impl.*;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class Hud {
    public static final int PURPLE = 0xFFA855F7, DARK = 0xE60B0618;

    public static void register() {
        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath("l7n", "hud"), (g, delta) -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.options.hideGui || mc.player == null) return;
            var mm = L7NClient.modules;
            if (mm.get(WatermarkModule.class).isEnabled()) {
                g.fill(4, 4, 112, 24, DARK);
                g.fill(4, 4, 6, 24, PURPLE);
                g.drawString(mc.font, "L7N CLIENT", 12, 10, PURPLE);
            }
            if (mm.get(CoordsModule.class).isEnabled()) {
                String s = String.format("XYZ %.1f / %.1f / %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
                g.drawString(mc.font, s, 6, mc.getWindow().getGuiScaledHeight() - 12, 0xFFFFFFFF);
            }
            if (mm.get(ArrayListModule.class).isEnabled()) {
                int y = 4, w = mc.getWindow().getGuiScaledWidth();
                for (Module m : mm.all) {
                    if (!m.isEnabled()) continue;
                    int tw = mc.font.width(m.name);
                    g.fill(w - tw - 8, y, w, y + 11, DARK);
                    g.fill(w - 2, y, w, y + 11, PURPLE);
                    g.drawString(mc.font, m.name, w - tw - 5, y + 2, PURPLE);
                    y += 11;
                }
            }
        });
    }
}
