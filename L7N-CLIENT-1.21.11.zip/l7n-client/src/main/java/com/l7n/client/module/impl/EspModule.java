package com.l7n.client.module.impl;

import com.l7n.client.Data;
import com.l7n.client.gui.Projector;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class EspModule extends Module {
    public EspModule() {
        super("ESP", "Boxes and tracer lines on players/mobs (through walls)", Category.RENDER);
        addToggle("players", true); addToggle("mobs", false); addToggle("boxes", true); addToggle("tracers", true);
        addSetting("range", 96, 8); addToggle("glow", false);
    }

    @Override public void renderOverlay(GuiGraphics g, Minecraft mc, Projector p, float pt) {
        Entity camEnt = mc.getCameraEntity();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity le) || e == camEnt || !le.isAlive()) continue;
            boolean isPlayer = e instanceof Player;
            if (isPlayer && !on("players")) continue;
            if (!isPlayer && !on("mobs")) continue;
            if (camEnt.distanceTo(e) > get("range")) continue;
            Vec3 shift = le.getEyePosition(pt).subtract(le.getEyePosition());
            AABB bb = le.getBoundingBox().move(shift);
            int col = isPlayer ? (Data.isFriend(e.getName().getString()) ? 0xFF4ADE80 : 0xFFA855F7) : 0xFFFBBF24;
            if (on("boxes")) { double[] r = p.rect(bb); if (r != null) p.rectOutline(g, r, col); }
            if (on("tracers")) p.tracer(g, bb.getCenter(), col);
        }
    }

    @Override public void tick(Minecraft mc) {
        if (!on("glow")) return;
        for (Entity e : mc.level.entitiesForRendering()) if (e instanceof LivingEntity && e != mc.player) e.setGlowingTag(true);
    }
    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) for (Entity e : mc.level.entitiesForRendering()) e.setGlowingTag(false);
    }
}
