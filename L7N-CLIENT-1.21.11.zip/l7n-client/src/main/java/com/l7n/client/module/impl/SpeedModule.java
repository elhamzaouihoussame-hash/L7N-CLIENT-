package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

public class SpeedModule extends Module {
    public SpeedModule() { super("Speed", "Move faster", Category.MOVEMENT); addSetting("speed", 0.4, 0.05); }
    @Override public void tick(Minecraft mc) {
        double f = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
        double s = (mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0);
        if (f == 0 && s == 0) return;
        double len = Math.sqrt(f * f + s * s); f /= len; s /= len;
        double yaw = Math.toRadians(mc.player.getYRot()), sp = get("speed");
        double dx = -Math.sin(yaw) * f + Math.cos(yaw) * s, dz = Math.cos(yaw) * f + Math.sin(yaw) * s;
        Vec3 v = mc.player.getDeltaMovement();
        mc.player.setDeltaMovement(dx * sp, v.y, dz * sp);
    }
}
