package com.l7n.client.module.impl;
import com.l7n.client.module.Module;
public class CoordsModule extends Module {
    public CoordsModule() { super("Coords", "Show XYZ on screen", Category.RENDER); }
}
