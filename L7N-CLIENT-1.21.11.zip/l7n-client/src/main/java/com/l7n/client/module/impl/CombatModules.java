package com.l7n.client.module.impl;

import com.l7n.client.Data;
import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.Random;

public final class CombatModules {
    private CombatModules() {}

    static Player nearestPlayer(Minecraft mc, double range) {
        Player best = null; double bd = range;
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || Data.isFriend(p.getName().getString())) continue;
            double d = mc.player.distanceTo(p);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    public static class Criticals extends Module {
        public Criticals() { super("Criticals", "Critical hits (used by KillAura/TriggerBot/Mace)", Category.COMBAT); }
        public static void apply(Minecraft mc) {
            Criticals c = L7NClient.modules.get(Criticals.class);
            if (c == null || !c.isEnabled() || !mc.player.onGround()) return;
            double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + 0.0625, z, false, false));
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
        }
    }

    public static class TriggerBot extends Module {
        public TriggerBot() { super("TriggerBot", "Attacks what your crosshair is on", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null) return;
            if (!(mc.hitResult instanceof EntityHitResult r)) return;
            Entity e = r.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (e instanceof Player fp && Data.isFriend(fp.getName().getString())) return;
            if (mc.player.getAttackStrengthScale(0f) < 1f) return;
            Criticals.apply(mc);
            mc.gameMode.attack(mc.player, e);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    public static class Mace extends Module {
        private int cd;
        public Mace() { super("Mace", "Smash attack with a mace on the entity you look at", Category.COMBAT); addSetting("height", 10, 1); }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null) return;
            if (!mc.player.getMainHandItem().is(Items.MACE)) return;
            if (!(mc.hitResult instanceof EntityHitResult r)) return;
            Entity e = r.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (e instanceof Player fp && Data.isFriend(fp.getName().getString())) return;
            if (mc.player.getAttackStrengthScale(0f) < 1f) return;
            double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ(), h = get("height");
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + h, z, false, false));
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
            mc.gameMode.attack(mc.player, e);
            mc.player.swing(InteractionHand.MAIN_HAND);
            cd = 10;
        }
    }

    public static class AutoTotem extends Module {
        private int cd;
        public AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand (instant)", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null) return;
            if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
            var inv = mc.player.getInventory();
            for (int i = 0; i < 36; i++) {
                if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                    int slot = i < 9 ? 36 + i : i;
                    mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot, 40, ClickType.SWAP, mc.player);
                    cd = 5;
                    return;
                }
            }
        }
    }

    /** Human-like totem swap: totem must be in the hotbar, random reaction delay, uses the offhand-swap action like the F key. */
    public static class LegitTotem extends Module {
        private final Random rnd = new Random();
        private int wait = -1, restore = -1, prev;
        public LegitTotem() {
            super("LegitTotem", "Human-like totem swap (hotbar + offhand key, random delay)", Category.COMBAT);
            addSetting("mindelay", 4, 1); addSetting("maxdelay", 9, 1);
        }
        @Override public void tick(Minecraft mc) {
            if (restore >= 0) { if (restore-- == 0) BlockUtil.select(mc, prev); return; }
            if (mc.screen != null) { wait = -1; return; }
            if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) { wait = -1; return; }
            int slot = BlockUtil.hotbar(mc, s -> s.is(Items.TOTEM_OF_UNDYING));
            if (slot < 0) { wait = -1; return; }
            if (wait < 0) {
                int lo = (int) get("mindelay"), hi = Math.max(lo, (int) get("maxdelay"));
                wait = lo + rnd.nextInt(hi - lo + 1);
            }
            if (wait > 0) { wait--; return; }
            prev = mc.player.getInventory().getSelectedSlot();
            BlockUtil.select(mc, slot);
            mc.player.connection.send(new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
            wait = -1;
            restore = 3;
        }
    }

    /** Places a respawn anchor above the nearest player, charges it with glowstone and explodes it. Needs both items in the hotbar. */
    public static class AnchorAura extends Module {
        private int cd;
        public AnchorAura() {
            super("AnchorAura", "Place, charge and explode respawn anchors near players", Category.COMBAT);
            addSetting("range", 4.5, 0.5); addSetting("delay", 2, 1); addSetting("minhealth", 8, 1);
        }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (mc.player.getHealth() < get("minhealth")) return;
            Player target = nearestPlayer(mc, get("range") + 2);
            if (target == null) return;
            BlockPos pos = target.blockPosition().above(2);
            if (mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(pos)) > get("range")) return;
            BlockState st = mc.level.getBlockState(pos);
            if (st.is(Blocks.RESPAWN_ANCHOR)) {
                if (st.getValue(RespawnAnchorBlock.CHARGE) == 0) {
                    int glow = BlockUtil.hotbar(mc, s -> s.is(Items.GLOWSTONE));
                    if (glow < 0) return;
                    BlockUtil.select(mc, glow);
                } else {
                    int other = BlockUtil.hotbar(mc, s -> !s.is(Items.GLOWSTONE));
                    if (other < 0) return;
                    BlockUtil.select(mc, other);
                }
                BlockUtil.interact(mc, pos);
            } else if (st.canBeReplaced()) {
                int anchor = BlockUtil.hotbar(mc, s -> s.is(Items.RESPAWN_ANCHOR));
                if (anchor < 0) return;
                BlockUtil.select(mc, anchor);
                BlockUtil.place(mc, pos);
            } else return;
            cd = (int) get("delay");
        }
    }
}
