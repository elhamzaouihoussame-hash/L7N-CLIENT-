package com.l7n.client.module.impl;

import com.l7n.client.Data;
import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.Random;

public final class CombatModules {
    private CombatModules() {}

    static Player nearestPlayer(Minecraft mc, double range) {
        Player best = null; double bd = range;
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || Data.isFriend(p.getName().getString())) continue;
            double d = mc.player.distanceTo(p);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    /** Estimated explosion damage (no armor) at a distance. power 6 = end crystal, 5 = respawn anchor. */
    static double explosionDamage(double dist, double power) {
        double d = dist / (power * 2.0);
        if (d >= 1) return 0;
        double impact = 1.0 - d;
        return (impact * impact + impact) / 2.0 * 7.0 * power * 2.0 + 1.0;
    }

    /** Swap a totem from the inventory into the offhand. @return true if a swap was sent. */
    static boolean equipTotem(Minecraft mc) {
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return false;
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i;
                mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot, 40, ClickType.SWAP, mc.player);
                return true;
            }
        }
        return false;
    }

    public static class Criticals extends Module {
        public Criticals() { super("Criticals", "Critical hits (used by KillAura/TriggerBot/Mace)", Category.COMBAT); }
        public static void apply(Minecraft mc) {
            Criticals c = L7NClient.modules.get(Criticals.class);
            if (c == null || !c.isEnabled() || !mc.player.onGround()) return;
            double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + 0.0625, z, false, false));
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
        }
    }

    public static class TriggerBot extends Module {
        public TriggerBot() { super("TriggerBot", "Attacks what your crosshair is on", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null) return;
            if (!(mc.hitResult instanceof EntityHitResult r)) return;
            Entity e = r.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (e instanceof Player fp && Data.isFriend(fp.getName().getString())) return;
            if (mc.player.getAttackStrengthScale(0f) < 1f) return;
            Criticals.apply(mc);
            mc.gameMode.attack(mc.player, e);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    /** Like KillAura, but only smashes with the mace while you are falling from at least "minheight" blocks. */
    public static class Mace extends Module {
        private int cd;
        public Mace() {
            super("Mace", "Mace smash on nearby entities when falling from a height (like KillAura)", Category.COMBAT);
            addSetting("range", 3.5, 0.1); addSetting("minheight", 3, 0.5);
            addToggle("players", true); addToggle("mobs", false); addToggle("rotate", true); addToggle("autoswitch", true);
            addToggle("exploit", false); addSetting("height", 10, 1);
        }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (mc.player.onGround() || mc.player.fallDistance < get("minheight")) return;
            if (!mc.player.getMainHandItem().is(Items.MACE)) {
                if (!on("autoswitch")) return;
                int slot = BlockUtil.hotbar(mc, s -> s.is(Items.MACE));
                if (slot < 0) return;
                BlockUtil.select(mc, slot);
            }
            LivingEntity best = null; double bd = get("range");
            for (Entity e : mc.level.entitiesForRendering()) {
                if (!(e instanceof LivingEntity le) || le == mc.player || !le.isAlive() || le instanceof ArmorStand) continue;
                boolean isPlayer = le instanceof Player;
                if (isPlayer && (!on("players") || Data.isFriend(le.getName().getString()))) continue;
                if (!isPlayer && !on("mobs")) continue;
                double d = mc.player.distanceTo(le);
                if (d <= bd) { bd = d; best = le; }
            }
            if (best == null || mc.player.getAttackStrengthScale(0f) < 1f) return;
            if (on("rotate")) BlockUtil.face(mc, best.getBoundingBox().getCenter());
            if (on("exploit")) {
                double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ(), h = get("height");
                mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + h, z, false, false));
                mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
            }
            mc.gameMode.attack(mc.player, best);
            mc.player.swing(InteractionHand.MAIN_HAND);
            cd = 4;
        }
    }

    public static class AutoTotem extends Module {
        private int cd;
        public AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand (instant)", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null) return;
            if (equipTotem(mc)) cd = 5;
        }
    }

    /** Human-like totem swap: totem must be in the hotbar, random reaction delay, uses the offhand-swap action like the F key. */
    public static class LegitTotem extends Module {
        private final Random rnd = new Random();
        private int wait = -1, restore = -1, prev;
        public LegitTotem() {
            super("LegitTotem", "Human-like totem swap (hotbar + offhand key, random delay)", Category.COMBAT);
            addSetting("mindelay", 4, 1); addSetting("maxdelay", 9, 1);
        }
        @Override public void tick(Minecraft mc) {
            if (restore >= 0) { if (restore-- == 0) BlockUtil.select(mc, prev); return; }
            if (mc.screen != null) { wait = -1; return; }
            if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) { wait = -1; return; }
            int slot = BlockUtil.hotbar(mc, s -> s.is(Items.TOTEM_OF_UNDYING));
            if (slot < 0) { wait = -1; return; }
            if (wait < 0) {
                int lo = (int) get("mindelay"), hi = Math.max(lo, (int) get("maxdelay"));
                wait = lo + rnd.nextInt(hi - lo + 1);
            }
            if (wait > 0) { wait--; return; }
            prev = mc.player.getInventory().getSelectedSlot();
            BlockUtil.select(mc, slot);
            mc.player.connection.send(new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
            wait = -1;
            restore = 3;
        }
    }

    /**
     * Crystal PvP: put obsidian/bedrock on the ground near an enemy and this places a crystal on the best block,
     * breaks crystals near the enemy, and hits the enemy once with a sword every "hitdelay" ticks.
     */
    public static class CrystalAura extends Module {
        private int cd, hitCd, saved = -1;
        public CrystalAura() {
            super("CrystalAura", "Auto place/break end crystals on obsidian + one sword hit", Category.COMBAT);
            addSetting("range", 4.5, 0.5); addSetting("breakrange", 3.8, 0.2); addSetting("targetrange", 10, 1);
            addSetting("mindamage", 4, 0.5); addSetting("maxself", 8, 0.5); addSetting("delay", 2, 1); addSetting("hitdelay", 12, 1);
            addToggle("place", true); addToggle("break", true); addToggle("hit", true); addToggle("rotate", true);
        }
        private void remember(Minecraft mc) { if (saved < 0) saved = mc.player.getInventory().getSelectedSlot(); }
        private void restoreSlot(Minecraft mc) { if (saved >= 0) { BlockUtil.select(mc, saved); saved = -1; } }
        @Override protected void onDisable() { saved = -1; }

        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            Player target = nearestPlayer(mc, get("targetrange"));
            if (target == null) { restoreSlot(mc); return; }
            if (mc.player.getHealth() < 6) return;
            if (hitCd > 0) hitCd--;
            if (cd > 0) { cd--; return; }

            // 1) one sword hit on the enemy
            if (on("hit") && hitCd == 0 && mc.player.distanceTo(target) <= 3.0 && mc.player.getAttackStrengthScale(0f) >= 1f) {
                int sword = BlockUtil.hotbar(mc, s -> s.is(ItemTags.SWORDS));
                if (sword >= 0) { remember(mc); BlockUtil.select(mc, sword); }
                if (on("rotate")) BlockUtil.face(mc, target.getBoundingBox().getCenter());
                mc.gameMode.attack(mc.player, target);
                mc.player.swing(InteractionHand.MAIN_HAND);
                hitCd = (int) get("hitdelay"); cd = 1;
                return;
            }

            // 2) break the closest crystal near the enemy
            if (on("break")) {
                EndCrystal best = null; double bd = 1e9;
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (!(e instanceof EndCrystal c) || !c.isAlive()) continue;
                    double eyeD = mc.player.getEyePosition().distanceTo(c.getBoundingBox().getCenter());
                    if (eyeD > get("breakrange")) continue;
                    if (target.position().distanceTo(c.position()) > 12) continue;
                    double self = explosionDamage(mc.player.position().distanceTo(c.position()), 6);
                    if (self > get("maxself") || self >= mc.player.getHealth() - 2) continue;
                    if (eyeD < bd) { bd = eyeD; best = c; }
                }
                if (best != null) {
                    if (on("rotate")) BlockUtil.face(mc, best.getBoundingBox().getCenter());
                    mc.gameMode.attack(mc.player, best);
                    mc.player.swing(InteractionHand.MAIN_HAND);
                    cd = (int) get("delay");
                    return;
                }
            }

            // 3) place a crystal on the best obsidian/bedrock block
            if (on("place") && placeCrystal(mc, target)) cd = (int) get("delay");
        }

        private boolean placeCrystal(Minecraft mc, Player target) {
            Vec3 eye = mc.player.getEyePosition(), tp = target.position(), me = mc.player.position();
            BlockPos tb = target.blockPosition(), bestBase = null;
            double bestScore = -1e9;
            for (int dx = -5; dx <= 5; dx++) for (int dy = -3; dy <= 1; dy++) for (int dz = -5; dz <= 5; dz++) {
                BlockPos b = tb.offset(dx, dy, dz);
                BlockState st = mc.level.getBlockState(b);
                if (!st.is(Blocks.OBSIDIAN) && !st.is(Blocks.BEDROCK)) continue;
                if (!mc.level.isEmptyBlock(b.above()) || !mc.level.isEmptyBlock(b.above(2))) continue;
                Vec3 top = new Vec3(b.getX() + 0.5, b.getY() + 1, b.getZ() + 0.5);
                if (eye.distanceTo(top) > get("range")) continue;
                double td = explosionDamage(tp.distanceTo(top), 6), sd = explosionDamage(me.distanceTo(top), 6);
                if (td < get("mindamage") || sd > get("maxself") || sd >= mc.player.getHealth() - 2) continue;
                if (!mc.level.getEntities((Entity) null, new AABB(b.above()).expandTowards(0, 1, 0), e -> true).isEmpty()) continue;
                double score = td - sd * 0.5;
                if (score > bestScore) { bestScore = score; bestBase = b; }
            }
            if (bestBase == null) return false;
            InteractionHand hand = InteractionHand.MAIN_HAND;
            if (mc.player.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
            else {
                int slot = BlockUtil.hotbar(mc, s -> s.is(Items.END_CRYSTAL));
                if (slot < 0) return false;
                remember(mc);
                BlockUtil.select(mc, slot);
            }
            Vec3 hit = new Vec3(bestBase.getX() + 0.5, bestBase.getY() + 1, bestBase.getZ() + 0.5);
            if (on("rotate")) BlockUtil.face(mc, hit);
            mc.gameMode.useItemOn(mc.player, hand, new BlockHitResult(hit, Direction.UP, bestBase, false));
            mc.player.swing(hand);
            return true;
        }
    }

    /**
     * Respawn anchors. Default: YOU place the anchor near an enemy, then this charges it with glowstone,
     * keeps a totem in your offhand and detonates it. Turn "place" on to also let it place the anchor above the enemy.
     */
    public static class AnchorAura extends Module {
        private int cd;
        public AnchorAura() {
            super("AnchorAura", "You place the anchor; it charges, holds a totem and explodes it", Category.COMBAT);
            addSetting("range", 4.5, 0.5); addSetting("targetrange", 8, 1); addSetting("delay", 2, 1);
            addSetting("minhealth", 8, 1); addSetting("maxself", 10, 0.5);
            addToggle("place", false); addToggle("totem", true);
        }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (mc.player.getHealth() < get("minhealth")) return;
            Player target = nearestPlayer(mc, get("targetrange"));
            if (target == null) return;
            if (on("totem") && equipTotem(mc)) { cd = 3; return; }

            Vec3 eye = mc.player.getEyePosition();
            BlockPos pos = null;
            if (on("place")) {
                pos = target.blockPosition().above(2);
                if (eye.distanceTo(Vec3.atCenterOf(pos)) > get("range")) return;
            } else {
                BlockPos me = mc.player.blockPosition();
                double bd = 1e9;
                for (int dx = -5; dx <= 5; dx++) for (int dy = -5; dy <= 5; dy++) for (int dz = -5; dz <= 5; dz++) {
                    BlockPos b = me.offset(dx, dy, dz);
                    if (!mc.level.getBlockState(b).is(Blocks.RESPAWN_ANCHOR)) continue;
                    if (eye.distanceTo(Vec3.atCenterOf(b)) > get("range")) continue;
                    double td = target.position().distanceTo(Vec3.atCenterOf(b));
                    if (td <= get("targetrange") && td < bd) { bd = td; pos = b; }
                }
                if (pos == null) return;
            }

            BlockState st = mc.level.getBlockState(pos);
            if (st.is(Blocks.RESPAWN_ANCHOR)) {
                if (st.getValue(RespawnAnchorBlock.CHARGE) == 0) {
                    int glow = BlockUtil.hotbar(mc, s -> s.is(Items.GLOWSTONE));
                    if (glow < 0) return;
                    BlockUtil.select(mc, glow);
                } else {
                    boolean totem = mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
                    double self = explosionDamage(mc.player.position().distanceTo(Vec3.atCenterOf(pos)), 5);
                    if (!totem && (self > get("maxself") || self >= mc.player.getHealth() - 2)) return;
                    int other = BlockUtil.hotbar(mc, s -> !s.is(Items.GLOWSTONE));
                    if (other < 0) return;
                    BlockUtil.select(mc, other);
                }
                BlockUtil.interact(mc, pos);
            } else if (on("place") && st.canBeReplaced()) {
                int anchor = BlockUtil.hotbar(mc, s -> s.is(Items.RESPAWN_ANCHOR));
                if (anchor < 0) return;
                BlockUtil.select(mc, anchor);
                BlockUtil.place(mc, pos);
            } else return;
            cd = (int) get("delay");
        }
    }

    static boolean isSpear(ItemStack s) {
        return !s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().endsWith("_spear");
    }

    /**
     * Mace swap with a spear: poke with the spear; when you are falling from "minheight" blocks or more it swaps
     * to the mace, smashes, and swaps back to the spear.
     */
    public static class SpearMaceSwap extends Module {
        private int cd, restore = -1;
        public SpearMaceSwap() {
            super("SpearMaceSwap", "Spear pokes, swaps to the mace for the smash when falling, then back", Category.COMBAT);
            addSetting("range", 3.5, 0.1); addSetting("spearrange", 4.0, 0.1); addSetting("minheight", 3, 0.5);
            addToggle("players", true); addToggle("mobs", false); addToggle("rotate", true); addToggle("spear", true);
        }
        @Override public void tick(Minecraft mc) {
            if (restore >= 0) { BlockUtil.select(mc, restore); restore = -1; cd = 2; return; }
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            LivingEntity best = null; double bd = Math.max(get("range"), get("spearrange"));
            for (Entity e : mc.level.entitiesForRendering()) {
                if (!(e instanceof LivingEntity le) || le == mc.player || !le.isAlive() || le instanceof ArmorStand) continue;
                boolean isPlayer = le instanceof Player;
                if (isPlayer && (!on("players") || Data.isFriend(le.getName().getString()))) continue;
                if (!isPlayer && !on("mobs")) continue;
                double d = mc.player.distanceTo(le);
                if (d <= bd) { bd = d; best = le; }
            }
            if (best == null) return;
            var inv = mc.player.getInventory();
            boolean falling = !mc.player.onGround() && mc.player.fallDistance >= get("minheight");
            if (falling && bd <= get("range")) {
                int mace = BlockUtil.hotbar(mc, st -> st.is(Items.MACE));
                if (mace < 0) return;
                int prev = inv.getSelectedSlot();
                BlockUtil.select(mc, mace);
                if (on("rotate")) BlockUtil.face(mc, best.getBoundingBox().getCenter());
                mc.gameMode.attack(mc.player, best);
                mc.player.swing(InteractionHand.MAIN_HAND);
                if (prev != mace) restore = prev;
                cd = 3;
                return;
            }
            if (on("spear") && bd <= get("spearrange")) {
                int sp = BlockUtil.hotbar(mc, CombatModules::isSpear);
                if (sp < 0) return;
                if (inv.getSelectedSlot() != sp) BlockUtil.select(mc, sp);
                if (mc.player.getAttackStrengthScale(0f) < 1f) return;
                if (on("rotate")) BlockUtil.face(mc, best.getBoundingBox().getCenter());
                mc.gameMode.attack(mc.player, best);
                mc.player.swing(InteractionHand.MAIN_HAND);
                cd = 4;
            }
        }
    }

    /** Swaps to an axe to hit a player who is blocking with a shield (disables the shield), then swaps back. */
    public static class ShieldBreaker extends Module {
        private int cd, restore = -1;
        private Player pending;
        public ShieldBreaker() {
            super("ShieldBreaker", "Swap to an axe and break the shield of a blocking player", Category.COMBAT);
            addSetting("range", 3.5, 0.1); addToggle("rotate", true);
        }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (restore >= 0) { BlockUtil.select(mc, restore); restore = -1; cd = 4; return; }
            if (pending != null) {
                Player t = pending; pending = null;
                if (t.isAlive() && t.isBlocking() && mc.player.distanceTo(t) <= get("range")) {
                    if (on("rotate")) BlockUtil.face(mc, t.getBoundingBox().getCenter());
                    mc.gameMode.attack(mc.player, t);
                    mc.player.swing(InteractionHand.MAIN_HAND);
                }
                if (swapFrom >= 0 && swapFrom != mc.player.getInventory().getSelectedSlot()) restore = swapFrom;
                swapFrom = -1;
                return;
            }
            if (cd > 0) { cd--; return; }
            Player target = null; double bd = get("range");
            for (Player p : mc.level.players()) {
                if (p == mc.player || !p.isAlive() || !p.isBlocking() || Data.isFriend(p.getName().getString())) continue;
                double d = mc.player.distanceTo(p);
                if (d <= bd) { bd = d; target = p; }
            }
            if (target == null) return;
            int axe = BlockUtil.hotbar(mc, st -> st.is(ItemTags.AXES));
            if (axe < 0) return;
            swapFrom = mc.player.getInventory().getSelectedSlot();
            BlockUtil.select(mc, axe);
            pending = target;
            cd = 8;
        }
        private int swapFrom = -1;
    }

    /**
     * A basic mace bot. It walks/sprints to the nearest player like a person (random strafes and jumps, turn-rate limited aim),
     * then uses the common mace tricks with items from your HOTBAR:
     *  - wind charge boost: fires a wind charge at its feet, flies up, then falls on the target and smashes with the mace
     *  - pearl catch: throws an ender pearl at a far target, then fires a wind charge after "windwait" ticks
     *  - elytra catch: if an elytra is worn and the target is far, it glides to the target using fireworks,
     *    swaps to a chestplate (from the hotbar) when close, then drops and smashes
     *  - spear pokes when close on the ground
     * Needs in the hotbar: mace, wind charges, ender pearls (optional), spear (optional), a chestplate + fireworks (for elytra).
     */
    public static class AutoMace extends Module {
        private final Random rnd = new Random();
        private int cd, fwCd, restoreSlot = -1, restoreIn, windIn = -1, strafeT, strafeDir, jumpT;

        public AutoMace() {
            super("AutoMace", "Bot: approach, wind-charge/pearl catch, elytra catch, mace + spear smash", Category.COMBAT);
            addSetting("range", 60, 5); addSetting("reach", 3.5, 0.1); addSetting("minheight", 3, 0.5);
            addSetting("turn", 16, 1); addSetting("pearlmin", 8, 1); addSetting("pearlmax", 28, 1); addSetting("windwait", 6, 1);
            addSetting("divedist", 12, 1);
            addToggle("windcharge", true); addToggle("pearl", true); addToggle("elytra", true); addToggle("spear", true); addToggle("human", true);
        }

        private void release(Minecraft mc) {
            var o = mc.options;
            o.keyUp.setDown(false); o.keyDown.setDown(false); o.keyLeft.setDown(false); o.keyRight.setDown(false);
            o.keyJump.setDown(false); o.keySprint.setDown(false);
        }
        @Override protected void onDisable() {
            Minecraft mc = Minecraft.getInstance();
            release(mc);
            if (mc.player != null && restoreSlot >= 0) BlockUtil.select(mc, restoreSlot);
            restoreSlot = -1; windIn = -1;
        }

        private void useFromHotbar(Minecraft mc, int slot) {
            if (restoreSlot < 0) restoreSlot = mc.player.getInventory().getSelectedSlot();
            BlockUtil.select(mc, slot);
            mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
            mc.player.swing(InteractionHand.MAIN_HAND);
            restoreIn = 3;
        }

        private void aim(Minecraft mc, Vec3 pos, double maxTurn) {
            Vec3 to = pos.subtract(mc.player.getEyePosition());
            float wy = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90);
            float wp = (float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z)));
            if (on("human")) { wy += (float) (rnd.nextGaussian() * 0.6); wp += (float) (rnd.nextGaussian() * 0.4); }
            float t = (float) maxTurn;
            mc.player.setYRot(mc.player.getYRot() + Math.clamp(Mth.wrapDegrees(wy - mc.player.getYRot()), -t, t));
            mc.player.setXRot(Math.clamp(mc.player.getXRot() + Math.clamp(wp - mc.player.getXRot(), -t, t), -90f, 90f));
        }

        /** Pitch (degrees) that makes a thrown ender pearl land closest to the target. */
        private float pearlPitch(Minecraft mc, Vec3 target) {
            Vec3 eye = mc.player.getEyePosition();
            double horiz = Math.hypot(target.x - eye.x, target.z - eye.z), height = target.y - eye.y;
            float best = 0; double bestErr = 1e9;
            for (int pd = -80; pd <= 40; pd++) {
                double pr = Math.toRadians(pd), vh = Math.cos(pr) * 1.5, vy = -Math.sin(pr) * 1.5, d = 0, y = 0;
                for (int t = 0; t < 120; t++) {
                    d += vh; y += vy; vh *= 0.99; vy *= 0.99; vy -= 0.03;
                    double err = Math.hypot(d - horiz, y - height);
                    if (err < bestErr) { bestErr = err; best = pd; }
                    if (d > horiz + 6 && y < height) break;
                }
            }
            return best;
        }

        private boolean swapToChestplate(Minecraft mc) {
            if (!mc.player.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA)) return false;
            int slot = BlockUtil.hotbar(mc, st -> !st.isEmpty() && BuiltInRegistries.ITEM.getKey(st.getItem()).getPath().endsWith("_chestplate"));
            if (slot < 0) return false;
            mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, 6, slot, ClickType.SWAP, mc.player);
            return true;
        }

        @Override public void tick(Minecraft mc) {
            release(mc);
            if (mc.screen != null || mc.level == null || mc.gameMode == null) return;
            var me = mc.player;
            var o = mc.options;
            if (restoreIn > 0 && --restoreIn == 0 && restoreSlot >= 0) { BlockUtil.select(mc, restoreSlot); restoreSlot = -1; }
            if (cd > 0) cd--;
            if (fwCd > 0) fwCd--;
            Player target = nearestPlayer(mc, get("range"));
            if (target == null) return;
            Vec3 tc = target.getBoundingBox().getCenter();
            double dist = me.distanceTo(target), turn = get("turn");
            boolean air = !me.onGround();
            boolean elytraWorn = me.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);

            // pearl catch: fire the wind charge a few ticks after the pearl left the hand
            if (windIn > 0 && --windIn == 0) {
                windIn = -1;
                int wc = BlockUtil.hotbar(mc, st -> st.is(Items.WIND_CHARGE));
                if (wc >= 0) { me.setXRot(75f); useFromHotbar(mc, wc); }
                return;
            }
            if (on("human") && rnd.nextInt(100) < 6) return; // tiny hesitation, like a person

            // 1) smash: falling far enough and the target is in reach
            if (air && !me.isFallFlying() && me.fallDistance >= get("minheight") && dist <= get("reach")) {
                int mace = BlockUtil.hotbar(mc, st -> st.is(Items.MACE));
                if (mace >= 0) {
                    if (me.getInventory().getSelectedSlot() != mace) { if (restoreSlot < 0) restoreSlot = me.getInventory().getSelectedSlot(); BlockUtil.select(mc, mace); }
                    aim(mc, tc, 90);
                    if (me.getAttackStrengthScale(0f) >= 0.9f) { mc.gameMode.attack(me, target); me.swing(InteractionHand.MAIN_HAND); restoreIn = 4; }
                    return;
                }
            }

            // 2) gliding: dive on the target, firework when slow, swap to a chestplate when close
            if (me.isFallFlying()) {
                aim(mc, dist > 20 ? tc.add(0, 4, 0) : tc, turn);
                if (fwCd == 0 && me.getDeltaMovement().length() < 1.0 && dist > get("divedist")) {
                    if (me.getOffhandItem().is(Items.FIREWORK_ROCKET)) {
                        mc.gameMode.useItem(me, InteractionHand.OFF_HAND); me.swing(InteractionHand.OFF_HAND); fwCd = 25;
                    } else {
                        int fw = BlockUtil.hotbar(mc, st -> st.is(Items.FIREWORK_ROCKET));
                        if (fw >= 0) { useFromHotbar(mc, fw); fwCd = 25; }
                    }
                }
                if (dist < get("divedist") && swapToChestplate(mc)) fwCd = 60;
                return;
            }

            // 3) in the air (after a wind charge / pearl / jump): steer toward the target, start gliding if far
            if (air) {
                aim(mc, tc, turn);
                o.keyUp.setDown(true); o.keySprint.setDown(true);
                if (on("elytra") && elytraWorn && dist > 30 && me.getDeltaMovement().y < 0) o.keyJump.setDown(true);
                return;
            }

            // 4) on the ground: walk like a person
            aim(mc, tc, turn);
            o.keyUp.setDown(true); o.keySprint.setDown(true);
            if (on("human")) {
                if (--strafeT <= 0) { strafeT = 8 + rnd.nextInt(14); strafeDir = rnd.nextInt(3) - 1; }
                if (strafeDir < 0) o.keyLeft.setDown(true); else if (strafeDir > 0) o.keyRight.setDown(true);
                if (--jumpT <= 0) { jumpT = 12 + rnd.nextInt(25); o.keyJump.setDown(true); }
            }
            if (me.horizontalCollision) o.keyJump.setDown(true);
            if (on("elytra") && elytraWorn && dist > 30) { o.keyJump.setDown(true); return; }

            int wind = BlockUtil.hotbar(mc, st -> st.is(Items.WIND_CHARGE));
            int pearl = BlockUtil.hotbar(mc, st -> st.is(Items.ENDER_PEARL));
            if (on("windcharge") && cd == 0 && wind >= 0 && dist <= 10) {
                me.setXRot(85f);
                useFromHotbar(mc, wind);
                cd = 30;
                return;
            }
            if (on("pearl") && cd == 0 && pearl >= 0 && wind >= 0 && dist >= get("pearlmin") && dist <= get("pearlmax")) {
                aim(mc, tc, 90);
                me.setXRot(pearlPitch(mc, tc));
                useFromHotbar(mc, pearl);
                windIn = (int) get("windwait");
                cd = 80;
                return;
            }
            if (on("spear") && dist <= 4.5) {
                int sp = BlockUtil.hotbar(mc, CombatModules::isSpear);
                if (sp >= 0) {
                    if (me.getInventory().getSelectedSlot() != sp) BlockUtil.select(mc, sp);
                    if (me.getAttackStrengthScale(0f) >= 1f) { mc.gameMode.attack(me, target); me.swing(InteractionHand.MAIN_HAND); }
                    return;
                }
            }
            if (dist <= get("reach") && me.getAttackStrengthScale(0f) >= 1f) {
                int sw = BlockUtil.hotbar(mc, st -> st.is(ItemTags.SWORDS));
                if (sw >= 0) { BlockUtil.select(mc, sw); mc.gameMode.attack(me, target); me.swing(InteractionHand.MAIN_HAND); }
            }
        }
    }
}
