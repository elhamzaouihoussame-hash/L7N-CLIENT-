package com.l7n.client.module.impl;

import com.l7n.client.Data;
import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.Random;

public final class CombatModules {
    private CombatModules() {}

    static Player nearestPlayer(Minecraft mc, double range) {
        Player best = null; double bd = range;
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || Data.isFriend(p.getName().getString())) continue;
            double d = mc.player.distanceTo(p);
            if (d <= bd) { bd = d; best = p; }
        }
        return best;
    }

    /** Estimated explosion damage (no armor) at a distance. power 6 = end crystal, 5 = respawn anchor. */
    static double explosionDamage(double dist, double power) {
        double d = dist / (power * 2.0);
        if (d >= 1) return 0;
        double impact = 1.0 - d;
        return (impact * impact + impact) / 2.0 * 7.0 * power * 2.0 + 1.0;
    }

    /** Swap a totem from the inventory into the offhand. @return true if a swap was sent. */
    static boolean equipTotem(Minecraft mc) {
        if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return false;
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? 36 + i : i;
                mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot, 40, ClickType.SWAP, mc.player);
                return true;
            }
        }
        return false;
    }

    public static class Criticals extends Module {
        public Criticals() { super("Criticals", "Critical hits (used by KillAura/TriggerBot/Mace)", Category.COMBAT); }
        public static void apply(Minecraft mc) {
            Criticals c = L7NClient.modules.get(Criticals.class);
            if (c == null || !c.isEnabled() || !mc.player.onGround()) return;
            double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + 0.0625, z, false, false));
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
        }
    }

    public static class TriggerBot extends Module {
        public TriggerBot() { super("TriggerBot", "Attacks what your crosshair is on", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null) return;
            if (!(mc.hitResult instanceof EntityHitResult r)) return;
            Entity e = r.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (e instanceof Player fp && Data.isFriend(fp.getName().getString())) return;
            if (mc.player.getAttackStrengthScale(0f) < 1f) return;
            Criticals.apply(mc);
            mc.gameMode.attack(mc.player, e);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    /** Like KillAura, but only smashes with the mace while you are falling from at least "minheight" blocks. */
    public static class Mace extends Module {
        private int cd;
        public Mace() {
            super("Mace", "Mace smash on nearby entities when falling from a height (like KillAura)", Category.COMBAT);
            addSetting("range", 3.5, 0.1); addSetting("minheight", 3, 0.5);
            addToggle("players", true); addToggle("mobs", false); addToggle("rotate", true); addToggle("autoswitch", true);
            addToggle("exploit", false); addSetting("height", 10, 1);
        }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (mc.player.onGround() || mc.player.fallDistance < get("minheight")) return;
            if (!mc.player.getMainHandItem().is(Items.MACE)) {
                if (!on("autoswitch")) return;
                int slot = BlockUtil.hotbar(mc, s -> s.is(Items.MACE));
                if (slot < 0) return;
                BlockUtil.select(mc, slot);
            }
            LivingEntity best = null; double bd = get("range");
            for (Entity e : mc.level.entitiesForRendering()) {
                if (!(e instanceof LivingEntity le) || le == mc.player || !le.isAlive() || le instanceof ArmorStand) continue;
                boolean isPlayer = le instanceof Player;
                if (isPlayer && (!on("players") || Data.isFriend(le.getName().getString()))) continue;
                if (!isPlayer && !on("mobs")) continue;
                double d = mc.player.distanceTo(le);
                if (d <= bd) { bd = d; best = le; }
            }
            if (best == null || mc.player.getAttackStrengthScale(0f) < 1f) return;
            if (on("rotate")) BlockUtil.face(mc, best.getBoundingBox().getCenter());
            if (on("exploit")) {
                double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ(), h = get("height");
                mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + h, z, false, false));
                mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
            }
            mc.gameMode.attack(mc.player, best);
            mc.player.swing(InteractionHand.MAIN_HAND);
            cd = 4;
        }
    }

    public static class AutoTotem extends Module {
        private int cd;
        public AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand (instant)", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null) return;
            if (equipTotem(mc)) cd = 5;
        }
    }

    /** Human-like totem swap: totem must be in the hotbar, random reaction delay, uses the offhand-swap action like the F key. */
    public static class LegitTotem extends Module {
        private final Random rnd = new Random();
        private int wait = -1, restore = -1, prev;
        public LegitTotem() {
            super("LegitTotem", "Human-like totem swap (hotbar + offhand key, random delay)", Category.COMBAT);
            addSetting("mindelay", 4, 1); addSetting("maxdelay", 9, 1);
        }
        @Override public void tick(Minecraft mc) {
            if (restore >= 0) { if (restore-- == 0) BlockUtil.select(mc, prev); return; }
            if (mc.screen != null) { wait = -1; return; }
            if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) { wait = -1; return; }
            int slot = BlockUtil.hotbar(mc, s -> s.is(Items.TOTEM_OF_UNDYING));
            if (slot < 0) { wait = -1; return; }
            if (wait < 0) {
                int lo = (int) get("mindelay"), hi = Math.max(lo, (int) get("maxdelay"));
                wait = lo + rnd.nextInt(hi - lo + 1);
            }
            if (wait > 0) { wait--; return; }
            prev = mc.player.getInventory().getSelectedSlot();
            BlockUtil.select(mc, slot);
            mc.player.connection.send(new ServerboundPlayerActionPacket(ServerboundPlayerActionPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ZERO, Direction.DOWN));
            wait = -1;
            restore = 3;
        }
    }

    /**
     * Crystal PvP: put obsidian/bedrock on the ground near an enemy and this places a crystal on the best block,
     * breaks crystals near the enemy, and hits the enemy once with a sword every "hitdelay" ticks.
     */
    public static class CrystalAura extends Module {
        private int cd, hitCd, saved = -1;
        public CrystalAura() {
            super("CrystalAura", "Auto place/break end crystals on obsidian + one sword hit", Category.COMBAT);
            addSetting("range", 4.5, 0.5); addSetting("breakrange", 3.8, 0.2); addSetting("targetrange", 10, 1);
            addSetting("mindamage", 4, 0.5); addSetting("maxself", 8, 0.5); addSetting("delay", 2, 1); addSetting("hitdelay", 12, 1);
            addToggle("place", true); addToggle("break", true); addToggle("hit", true); addToggle("rotate", true);
        }
        private void remember(Minecraft mc) { if (saved < 0) saved = mc.player.getInventory().getSelectedSlot(); }
        private void restoreSlot(Minecraft mc) { if (saved >= 0) { BlockUtil.select(mc, saved); saved = -1; } }
        @Override protected void onDisable() { saved = -1; }

        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            Player target = nearestPlayer(mc, get("targetrange"));
            if (target == null) { restoreSlot(mc); return; }
            if (mc.player.getHealth() < 6) return;
            if (hitCd > 0) hitCd--;
            if (cd > 0) { cd--; return; }

            // 1) one sword hit on the enemy
            if (on("hit") && hitCd == 0 && mc.player.distanceTo(target) <= 3.0 && mc.player.getAttackStrengthScale(0f) >= 1f) {
                int sword = BlockUtil.hotbar(mc, s -> s.is(ItemTags.SWORDS));
                if (sword >= 0) { remember(mc); BlockUtil.select(mc, sword); }
                if (on("rotate")) BlockUtil.face(mc, target.getBoundingBox().getCenter());
                mc.gameMode.attack(mc.player, target);
                mc.player.swing(InteractionHand.MAIN_HAND);
                hitCd = (int) get("hitdelay"); cd = 1;
                return;
            }

            // 2) break the closest crystal near the enemy
            if (on("break")) {
                EndCrystal best = null; double bd = 1e9;
                for (Entity e : mc.level.entitiesForRendering()) {
                    if (!(e instanceof EndCrystal c) || !c.isAlive()) continue;
                    double eyeD = mc.player.getEyePosition().distanceTo(c.getBoundingBox().getCenter());
                    if (eyeD > get("breakrange")) continue;
                    if (target.position().distanceTo(c.position()) > 12) continue;
                    double self = explosionDamage(mc.player.position().distanceTo(c.position()), 6);
                    if (self > get("maxself") || self >= mc.player.getHealth() - 2) continue;
                    if (eyeD < bd) { bd = eyeD; best = c; }
                }
                if (best != null) {
                    if (on("rotate")) BlockUtil.face(mc, best.getBoundingBox().getCenter());
                    mc.gameMode.attack(mc.player, best);
                    mc.player.swing(InteractionHand.MAIN_HAND);
                    cd = (int) get("delay");
                    return;
                }
            }

            // 3) place a crystal on the best obsidian/bedrock block
            if (on("place") && placeCrystal(mc, target)) cd = (int) get("delay");
        }

        private boolean placeCrystal(Minecraft mc, Player target) {
            Vec3 eye = mc.player.getEyePosition(), tp = target.position(), me = mc.player.position();
            BlockPos tb = target.blockPosition(), bestBase = null;
            double bestScore = -1e9;
            for (int dx = -5; dx <= 5; dx++) for (int dy = -3; dy <= 1; dy++) for (int dz = -5; dz <= 5; dz++) {
                BlockPos b = tb.offset(dx, dy, dz);
                BlockState st = mc.level.getBlockState(b);
                if (!st.is(Blocks.OBSIDIAN) && !st.is(Blocks.BEDROCK)) continue;
                if (!mc.level.isEmptyBlock(b.above()) || !mc.level.isEmptyBlock(b.above(2))) continue;
                Vec3 top = new Vec3(b.getX() + 0.5, b.getY() + 1, b.getZ() + 0.5);
                if (eye.distanceTo(top) > get("range")) continue;
                double td = explosionDamage(tp.distanceTo(top), 6), sd = explosionDamage(me.distanceTo(top), 6);
                if (td < get("mindamage") || sd > get("maxself") || sd >= mc.player.getHealth() - 2) continue;
                if (!mc.level.getEntities((Entity) null, new AABB(b.above()).expandTowards(0, 1, 0), e -> true).isEmpty()) continue;
                double score = td - sd * 0.5;
                if (score > bestScore) { bestScore = score; bestBase = b; }
            }
            if (bestBase == null) return false;
            InteractionHand hand = InteractionHand.MAIN_HAND;
            if (mc.player.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
            else {
                int slot = BlockUtil.hotbar(mc, s -> s.is(Items.END_CRYSTAL));
                if (slot < 0) return false;
                remember(mc);
                BlockUtil.select(mc, slot);
            }
            Vec3 hit = new Vec3(bestBase.getX() + 0.5, bestBase.getY() + 1, bestBase.getZ() + 0.5);
            if (on("rotate")) BlockUtil.face(mc, hit);
            mc.gameMode.useItemOn(mc.player, hand, new BlockHitResult(hit, Direction.UP, bestBase, false));
            mc.player.swing(hand);
            return true;
        }
    }

    /**
     * Respawn anchors. Default: YOU place the anchor near an enemy, then this charges it with glowstone,
     * keeps a totem in your offhand and detonates it. Turn "place" on to also let it place the anchor above the enemy.
     */
    public static class AnchorAura extends Module {
        private int cd;
        public AnchorAura() {
            super("AnchorAura", "You place the anchor; it charges, holds a totem and explodes it", Category.COMBAT);
            addSetting("range", 4.5, 0.5); addSetting("targetrange", 8, 1); addSetting("delay", 2, 1);
            addSetting("minhealth", 8, 1); addSetting("maxself", 10, 0.5);
            addToggle("place", false); addToggle("totem", true);
        }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (mc.player.getHealth() < get("minhealth")) return;
            Player target = nearestPlayer(mc, get("targetrange"));
            if (target == null) return;
            if (on("totem") && equipTotem(mc)) { cd = 3; return; }

            Vec3 eye = mc.player.getEyePosition();
            BlockPos pos = null;
            if (on("place")) {
                pos = target.blockPosition().above(2);
                if (eye.distanceTo(Vec3.atCenterOf(pos)) > get("range")) return;
            } else {
                BlockPos me = mc.player.blockPosition();
                double bd = 1e9;
                for (int dx = -5; dx <= 5; dx++) for (int dy = -5; dy <= 5; dy++) for (int dz = -5; dz <= 5; dz++) {
                    BlockPos b = me.offset(dx, dy, dz);
                    if (!mc.level.getBlockState(b).is(Blocks.RESPAWN_ANCHOR)) continue;
                    if (eye.distanceTo(Vec3.atCenterOf(b)) > get("range")) continue;
                    double td = target.position().distanceTo(Vec3.atCenterOf(b));
                    if (td <= get("targetrange") && td < bd) { bd = td; pos = b; }
                }
                if (pos == null) return;
            }

            BlockState st = mc.level.getBlockState(pos);
            if (st.is(Blocks.RESPAWN_ANCHOR)) {
                if (st.getValue(RespawnAnchorBlock.CHARGE) == 0) {
                    int glow = BlockUtil.hotbar(mc, s -> s.is(Items.GLOWSTONE));
                    if (glow < 0) return;
                    BlockUtil.select(mc, glow);
                } else {
                    boolean totem = mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
                    double self = explosionDamage(mc.player.position().distanceTo(Vec3.atCenterOf(pos)), 5);
                    if (!totem && (self > get("maxself") || self >= mc.player.getHealth() - 2)) return;
                    int other = BlockUtil.hotbar(mc, s -> !s.is(Items.GLOWSTONE));
                    if (other < 0) return;
                    BlockUtil.select(mc, other);
                }
                BlockUtil.interact(mc, pos);
            } else if (on("place") && st.canBeReplaced()) {
                int anchor = BlockUtil.hotbar(mc, s -> s.is(Items.RESPAWN_ANCHOR));
                if (anchor < 0) return;
                BlockUtil.select(mc, anchor);
                BlockUtil.place(mc, pos);
            } else return;
            cd = (int) get("delay");
        }
    }
}
