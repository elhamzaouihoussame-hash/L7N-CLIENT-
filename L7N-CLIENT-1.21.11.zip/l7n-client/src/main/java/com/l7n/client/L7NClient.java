package com.l7n.client;

import com.l7n.client.gui.ClickGuiScreen;
import com.l7n.client.gui.Hud;
import com.l7n.client.module.ModuleManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class L7NClient implements ClientModInitializer {
    public static final String NAME = "L7N CLIENT";
    public static final Identifier LOGO = Identifier.fromNamespaceAndPath("l7n", "textures/gui/logo.png");
    public static final int LOGO_W = 556, LOGO_H = 370; // actual size of logo.png
    public static ModuleManager modules;
    private static KeyMapping openGui;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("l7n", "main"));
        openGui = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.l7n.gui", InputConstants.KEY_RSHIFT, cat));
        Hud.register();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.consumeClick()) mc.setScreen(new ClickGuiScreen());
            if (mc.player != null) modules.tick(mc);
        });
    }
}
