package com.l7n.client;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.l7n.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private Config() {}
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("l7n-client.json"); }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : L7NClient.modules.all) {
                JsonObject o = new JsonObject(), s = new JsonObject();
                o.addProperty("hudX", m.hudX); o.addProperty("hudY", m.hudY);
                for (var e : m.settings.entrySet()) s.addProperty(e.getKey(), e.getValue());
                o.add("settings", s);
                m.saveExtra(o);
                root.add(m.name, o);
            }
            com.google.gson.JsonArray fr = new com.google.gson.JsonArray();
            Data.friends.forEach(fr::add);
            root.add("_friends", fr);
            JsonObject wp = new JsonObject();
            for (var e : Data.waypoints.entrySet()) {
                com.google.gson.JsonArray a = new com.google.gson.JsonArray();
                for (double d : e.getValue()) a.add(d);
                wp.add(e.getKey(), a);
            }
            root.add("_waypoints", wp);
            Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(root));
        } catch (Exception ignored) {}
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            Data.friends.clear(); Data.waypoints.clear();
            if (root.has("_friends")) root.getAsJsonArray("_friends").forEach(e -> Data.friends.add(e.getAsString()));
            if (root.has("_waypoints")) for (var e : root.getAsJsonObject("_waypoints").entrySet()) {
                var a = e.getValue().getAsJsonArray();
                Data.waypoints.put(e.getKey(), new double[]{a.get(0).getAsDouble(), a.get(1).getAsDouble(), a.get(2).getAsDouble()});
            }
            for (Module m : L7NClient.modules.all) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("hudX")) m.hudX = o.get("hudX").getAsInt();
                if (o.has("hudY")) m.hudY = o.get("hudY").getAsInt();
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (String k : m.settings.keySet()) if (s.has(k)) m.settings.put(k, s.get(k).getAsDouble());
                }
                m.loadExtra(o);
            }
        } catch (Exception ignored) {}
    }
}
