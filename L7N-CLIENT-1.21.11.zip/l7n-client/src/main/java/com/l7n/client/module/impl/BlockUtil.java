package com.l7n.client.module.impl;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.function.Predicate;

final class BlockUtil {
    private BlockUtil() {}

    static int hotbar(Minecraft mc, Predicate<ItemStack> p) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) if (p.test(inv.getItem(i))) return i;
        return -1;
    }
    /** Turn the player toward a world position. */
    static void face(Minecraft mc, Vec3 target) {
        Vec3 to = target.subtract(mc.player.getEyePosition());
        mc.player.setYRot((float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90));
        mc.player.setXRot((float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z))));
    }
    static void select(Minecraft mc, int slot) { mc.player.getInventory().setSelectedSlot(slot); }

    /** Right click the given face/centre of a block. */
    static void interact(Minecraft mc, BlockPos pos) {
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    /** Place the held block at pos by clicking an adjacent solid block. */
    static boolean place(Minecraft mc, BlockPos pos) {
        if (!mc.level.getBlockState(pos).canBeReplaced()) return false;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.relative(d);
            if (mc.level.getBlockState(n).canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 hit = new Vec3(n.getX() + 0.5 + face.getStepX() * 0.5, n.getY() + 0.5 + face.getStepY() * 0.5, n.getZ() + 0.5 + face.getStepZ() * 0.5);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            mc.player.swing(InteractionHand.MAIN_HAND);
            return true;
        }
        return false;
    }
}
