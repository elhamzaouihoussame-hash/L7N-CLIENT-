package com.l7n.client.gui;

import com.l7n.client.Config;
import com.l7n.client.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Tap a HUD element to select it, then tap anywhere to move it there. Right click on an element resets it. */
public class HudEditorScreen extends Screen {
    private final Screen parent;
    private Module selected;

    public HudEditorScreen(Screen parent) { super(Component.literal("HUD editor")); this.parent = parent; }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { Config.save(); }
    @Override public void onClose() { minecraft.setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0xB0050210);
        g.drawCenteredString(font, "Tap an element, then tap where to put it. Right click = reset. ESC = done.", width / 2, height - 12, 0xFFA855F7);
        for (Hud.Box b : Hud.boxes(minecraft, true)) {
            Hud.drawBox(g, minecraft, b);
            if (b.m() == selected) {
                int x = b.x(), y = b.y() - 1, w = b.w(), h = b.h() + 1;
                g.fill(x, y, x + w, y + 1, 0xFFFFFFFF); g.fill(x, y + h - 1, x + w, y + h, 0xFFFFFFFF);
                g.fill(x, y, x + 1, y + h, 0xFFFFFFFF); g.fill(x + w - 1, y, x + w, y + h, 0xFFFFFFFF);
            }
        }
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        double mx = ev.x(), my = ev.y();
        for (Hud.Box b : Hud.boxes(minecraft, true)) {
            if (mx >= b.x() && mx < b.x() + b.w() && my >= b.y() - 1 && my < b.y() + b.h()) {
                if (ev.button() == 1) { b.m().hudX = -1; b.m().hudY = -1; selected = null; }
                else selected = b.m();
                return true;
            }
        }
        if (selected != null && ev.button() == 0) {
            selected.hudX = Math.clamp((long) mx, 0, Math.max(0, width - 20));
            selected.hudY = Math.clamp((long) my, 0, Math.max(0, height - 12));
            return true;
        }
        return super.mouseClicked(ev, dbl);
    }
}
