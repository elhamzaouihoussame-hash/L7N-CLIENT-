package com.l7n.client.module.impl;
import com.l7n.client.module.Module;
public class ArrayListModule extends Module {
    public ArrayListModule() { super("ArrayList", "Show enabled modules", Category.RENDER); }
}
