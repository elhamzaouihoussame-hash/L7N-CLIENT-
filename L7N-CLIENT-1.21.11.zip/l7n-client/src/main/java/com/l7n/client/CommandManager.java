package com.l7n.client;

import com.l7n.client.gui.ClickGuiScreen;
import com.l7n.client.gui.HudEditorScreen;
import com.l7n.client.gui.ModuleSettingsScreen;
import com.l7n.client.module.Module;
import com.l7n.client.module.impl.StaffModules;
import com.l7n.client.module.impl.WorldModules;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import java.util.Optional;

/** Chat commands. Type them in chat starting with a dot, e.g. .toggle killaura */
public class CommandManager {
    public static void info(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("§d[L7N] §f" + s), false);
    }

    private static net.minecraft.world.entity.player.Player findPlayer(Minecraft mc, String name) {
        if (mc.level == null) return null;
        for (var p : mc.level.players()) if (p.getName().getString().equalsIgnoreCase(name)) return p;
        return null;
    }

    /** @return true if the message was a client command (and must not be sent to the server) */
    public static boolean handle(String msg) {
        if (!msg.startsWith(".") || msg.startsWith("..")) return false;
        String[] a = msg.substring(1).trim().split("\\s+");
        Minecraft mc = Minecraft.getInstance();
        var mm = L7NClient.modules;
        switch (a[0].toLowerCase()) {
            case "help" -> {
                info(".modules | .toggle <module> | .set <module> <setting> <value> | .settings [module]");
                info(".gui | .hud (move HUD) | .panic | .config save|load");
                info(".staff ranks (see this server's rank tags) | .staff add|remove <word> | .staff name|unname <player>");
                info(".blockesp add|remove|list <block> | .friend add|remove|list <name>");
                info(".fov <30-110> | .tp <x y z> | .pos | .copypos | .wp add|del|list <name>");
                info(".players | .ping | .health | .dist <player> | .lookat <player> | .clearchat | .vclip <n> | .say <text>");
            }
            case "modules" -> {
                StringBuilder sb = new StringBuilder();
                for (Module m : mm.all) sb.append(m.isEnabled() ? "§a" : "§7").append(m.name).append(" ");
                info(sb.toString());
            }
            case "toggle", "t" -> {
                if (a.length < 2) { info("Usage: .toggle <module>"); break; }
                mm.byName(a[1]).ifPresentOrElse(m -> { m.toggle(); info(m.name + (m.isEnabled() ? " §aON" : " §cOFF")); },
                        () -> info("Unknown module: " + a[1]));
            }
            case "settings" -> {
                if (a.length < 2) mc.execute(() -> mc.setScreen(new ClickGuiScreen()));
                else mm.byName(a[1]).ifPresentOrElse(m -> mc.execute(() -> mc.setScreen(new ModuleSettingsScreen(m, null))),
                        () -> info("Unknown module: " + a[1]));
            }
            case "hud" -> mc.execute(() -> mc.setScreen(new HudEditorScreen(null)));
            case "gui" -> mc.execute(() -> mc.setScreen(new ClickGuiScreen()));
            case "set" -> {
                if (a.length < 4) { info("Usage: .set <module> <setting> <value>"); break; }
                mm.byName(a[1]).ifPresentOrElse(m -> {
                    if (!m.settings.containsKey(a[2].toLowerCase())) { info("Unknown setting. Use .settings " + m.name); return; }
                    try {
                        double v = switch (a[3].toLowerCase()) { case "on", "true" -> 1; case "off", "false" -> 0; default -> Double.parseDouble(a[3]); };
                        m.settings.put(a[2].toLowerCase(), v);
                        Config.save();
                        info(m.name + "." + a[2] + " = " + v);
                    } catch (NumberFormatException e) { info("Value must be a number or on/off"); }
                }, () -> info("Unknown module: " + a[1]));
            }
            case "panic" -> { for (Module m : mm.all) m.setEnabled(false); info("All modules disabled"); }
            case "config" -> {
                if (a.length > 1 && a[1].equalsIgnoreCase("load")) { Config.load(); info("Config loaded"); }
                else { Config.save(); info("Config saved"); }
            }
            case "staff" -> staff(a);
            case "blockesp" -> blockEsp(a);
            case "friend", "friends" -> friend(a);
            case "wp", "waypoint" -> waypoint(a);
            case "vclip" -> {
                if (a.length < 2 || mc.player == null) { info("Usage: .vclip <blocks>"); break; }
                try { double d = Double.parseDouble(a[1]); mc.player.setPos(mc.player.getX(), mc.player.getY() + d, mc.player.getZ()); info("Teleported " + d + " blocks"); }
                catch (NumberFormatException e) { info("Value must be a number"); }
            }
            case "say" -> { if (a.length > 1 && mc.player != null) mc.player.connection.sendChat(msg.substring(5).trim()); }
            case "pos" -> { if (mc.player != null) info(String.format("XYZ %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ())); }
            case "copypos" -> {
                if (mc.player == null) break;
                mc.keyboardHandler.setClipboard(String.format("%d %d %d", (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ()));
                info("Coordinates copied");
            }
            case "tp" -> {
                if (a.length < 4 || mc.player == null) { info("Usage: .tp <x> <y> <z>"); break; }
                try { mc.player.setPos(Double.parseDouble(a[1]), Double.parseDouble(a[2]), Double.parseDouble(a[3])); info("Teleported (client side)"); }
                catch (NumberFormatException e) { info("Coordinates must be numbers"); }
            }
            case "fov" -> {
                if (a.length < 2) { info("Usage: .fov <30-110>"); break; }
                try { int v = Math.clamp(Integer.parseInt(a[1]), 30, 110); mc.options.fov().set(v); info("FOV = " + v); }
                catch (NumberFormatException e) { info("Value must be a number"); }
            }
            case "clearchat" -> mc.gui.getChat().clearMessages(false);
            case "players" -> {
                var conn = mc.getConnection();
                if (conn == null) break;
                StringBuilder sb = new StringBuilder();
                int n = 0;
                for (PlayerInfo pi : conn.getOnlinePlayers()) { n++; if (n <= 30) sb.append(Util.name(pi)).append(" "); }
                info("Online (" + n + "): " + sb);
            }
            case "ping" -> {
                var conn = mc.getConnection();
                if (conn == null || mc.player == null) break;
                PlayerInfo me = conn.getPlayerInfo(mc.player.getUUID());
                info(me == null ? "Ping unknown" : "Ping: " + me.getLatency() + " ms");
            }
            case "health" -> {
                if (mc.player != null) info(String.format("Health %.1f  Food %d", mc.player.getHealth(), mc.player.getFoodData().getFoodLevel()));
            }
            case "dist" -> {
                if (a.length < 2 || mc.player == null) { info("Usage: .dist <player>"); break; }
                var p = findPlayer(mc, a[1]);
                info(p == null ? "Player not nearby: " + a[1] : String.format("%s is %.1f blocks away", p.getName().getString(), (double) mc.player.distanceTo(p)));
            }
            case "lookat" -> {
                if (a.length < 2 || mc.player == null) { info("Usage: .lookat <player>"); break; }
                var p = findPlayer(mc, a[1]);
                if (p == null) { info("Player not nearby: " + a[1]); break; }
                var to = p.getEyePosition().subtract(mc.player.getEyePosition());
                mc.player.setYRot((float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90));
                mc.player.setXRot((float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z))));
            }
            default -> info("Unknown command. Type .help");
        }
        return true;
    }

    private static void friend(String[] a) {
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) { info("Friends: " + Data.friends); return; }
        if (a.length < 3) { info("Usage: .friend add|remove <name> | list"); return; }
        String n = a[2].toLowerCase();
        switch (a[1].toLowerCase()) {
            case "add" -> { Data.friends.add(n); info("Friend added: " + n); }
            case "remove" -> { Data.friends.remove(n); info("Friend removed: " + n); }
            default -> { info("Usage: .friend add|remove <name> | list"); return; }
        }
        Config.save();
    }

    private static void waypoint(String[] a) {
        Minecraft mc = Minecraft.getInstance();
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            if (Data.waypoints.isEmpty()) { info("No waypoints"); return; }
            for (var e : Data.waypoints.entrySet()) {
                double[] c = e.getValue();
                String dist = mc.player == null ? "" : String.format(" (%d m)", (int) Math.sqrt(mc.player.distanceToSqr(c[0], c[1], c[2])));
                info(String.format("%s: %d %d %d%s", e.getKey(), (int) c[0], (int) c[1], (int) c[2], dist));
            }
            return;
        }
        if (a.length < 3) { info("Usage: .wp add|del <name> | list"); return; }
        String n = a[2].toLowerCase();
        switch (a[1].toLowerCase()) {
            case "add" -> {
                if (mc.player == null) return;
                Data.waypoints.put(n, new double[]{mc.player.getX(), mc.player.getY(), mc.player.getZ()});
                info("Waypoint saved: " + n);
            }
            case "del" -> { Data.waypoints.remove(n); info("Waypoint removed: " + n); }
            default -> { info("Usage: .wp add|del <name> | list"); return; }
        }
        Config.save();
    }

    private static void staff(String[] a) {
        StaffModules.StaffList sl = L7NClient.modules.get(StaffModules.StaffList.class);
        if (a.length >= 2 && a[1].equalsIgnoreCase("ranks")) {
            var r = sl.ranks(Minecraft.getInstance());
            info(r.isEmpty() ? "No rank tags in the tab list on this server. Use .staff name <player>" : "Rank tags here: " + r + "  -> pick the staff ones with .staff add <word>");
            return;
        }
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) { info("Words: " + sl.keywords + "  Names: " + sl.names); return; }
        if (a.length < 3) { info("Usage: .staff add|remove <word> | name|unname <player>"); return; }
        String v = a[2].toLowerCase();
        switch (a[1].toLowerCase()) {
            case "add" -> { sl.keywords.add(v); info("Added word " + v); }
            case "remove" -> { sl.keywords.remove(v); info("Removed word " + v); }
            case "name" -> { sl.names.add(v); info("Added staff name " + v); }
            case "unname" -> { sl.names.remove(v); info("Removed staff name " + v); }
            default -> { info("Usage: .staff add|remove <word> | name|unname <player>"); return; }
        }
        Config.save();
    }

    private static void blockEsp(String[] a) {
        WorldModules.BlockEsp be = L7NClient.modules.get(WorldModules.BlockEsp.class);
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            StringBuilder sb = new StringBuilder();
            for (Block b : be.blocks) sb.append(BuiltInRegistries.BLOCK.getKey(b).getPath()).append(" ");
            info("BlockESP: " + (sb.length() == 0 ? "(empty)" : sb));
            return;
        }
        if (a.length < 3) { info("Usage: .blockesp add|remove <block> | list"); return; }
        Identifier id = Identifier.tryParse(a[2]);
        Optional<Block> b = id == null ? Optional.empty() : BuiltInRegistries.BLOCK.getOptional(id);
        if (b.isEmpty()) { info("Unknown block: " + a[2]); return; }
        switch (a[1].toLowerCase()) {
            case "add" -> { be.blocks.add(b.get()); info("Added " + a[2]); }
            case "remove" -> { be.blocks.remove(b.get()); info("Removed " + a[2]); }
            default -> { info("Usage: .blockesp add|remove <block> | list"); return; }
        }
        Config.save();
    }
}
