package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;

public class StepModule extends Module {
    public StepModule() { super("Step", "Walk up blocks without jumping", Category.MOVEMENT); addSetting("height", 1.0, 0.5); }
    private void apply(Minecraft mc, double v) {
        if (mc.player == null) return;
        AttributeInstance a = mc.player.getAttribute(Attributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(v);
    }
    @Override public void tick(Minecraft mc) { apply(mc, get("height")); }
    @Override protected void onDisable() { apply(Minecraft.getInstance(), 0.6); }
}
