package com.l7n.client.gui;

import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int PW = 110, HEAD = 18, ROW = 15, GAP = 8;
    private static final int PURPLE = 0xFFA855F7, DARK = 0xF00B0618, ROW_BG = 0xCC140A2A;
    private long openedAt;
    private final Module.Category[] cats = Module.Category.values();

    public ClickGuiScreen() { super(Component.literal("L7N CLIENT")); }

    @Override protected void init() { openedAt = System.currentTimeMillis(); }
    @Override public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        float open = Anim.easeOutCubic((System.currentTimeMillis() - openedAt) / 350f);
        g.fill(0, 0, width, height, Anim.alpha(0x05020D, 0.75f * open)); // fade-in dim

        // logo watermark (your image) behind the panels
        int lw = 220, lh = lw * L7NClient.LOGO_H / L7NClient.LOGO_W;
        g.blit(RenderPipelines.GUI_TEXTURED, L7NClient.LOGO, (width - lw) / 2, height - lh - 4, 0, 0, lw, lh, lw, lh, lw, lh);

        int total = cats.length * PW + (cats.length - 1) * GAP, x0 = (width - total) / 2;
        for (int i = 0; i < cats.length; i++) {
            // staggered slide-down + back-ease per panel
            float p = Anim.easeOutBack((System.currentTimeMillis() - openedAt - i * 70L) / 450f);
            float a = Math.clamp(p, 0f, 1f);
            int x = x0 + i * (PW + GAP), y = (int) (20 - (1 - p) * 40);
            List<Module> mods = L7NClient.modules.in(cats[i]);
            g.fill(x, y, x + PW, y + HEAD, Anim.alpha(PURPLE, a));
            g.drawString(font, cats[i].name(), x + 6, y + 5, Anim.alpha(0xFFFFFF, a) | 0xFF000000 & 0);
            int ry = y + HEAD;
            for (Module m : mods) {
                m.anim = Anim.approach(m.anim, m.isEnabled() ? 1f : 0f, 0.18f);
                boolean hover = mx >= x && mx < x + PW && my >= ry && my < ry + ROW;
                g.fill(x, ry, x + PW, ry + ROW, Anim.alpha(hover ? 0x2A1550 : 0x140A2A, 0.85f * a));
                g.fill(x, ry, x + 2 + (int) (m.anim * (PW - 2)), ry + ROW, Anim.alpha(PURPLE, 0.35f * m.anim * a));
                g.drawString(font, m.name, x + 6, ry + 4, Anim.lerpColor(0xFFAAAAAA, 0xFFFFFFFF, m.anim));
                ry += ROW;
            }
        }
        g.drawCenteredString(font, "L7N CLIENT  -  Play · Connect · Grow", width / 2, height - 12, PURPLE);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        if (ev.button() != 0) return super.mouseClicked(ev, dbl);
        int total = cats.length * PW + (cats.length - 1) * GAP, x0 = (width - total) / 2;
        for (int i = 0; i < cats.length; i++) {
            int x = x0 + i * (PW + GAP), ry = 20 + HEAD;
            for (Module m : L7NClient.modules.in(cats[i])) {
                if (ev.x() >= x && ev.x() < x + PW && ev.y() >= ry && ev.y() < ry + ROW) { m.toggle(); return true; }
                ry += ROW;
            }
        }
        return super.mouseClicked(ev, dbl);
    }
}
