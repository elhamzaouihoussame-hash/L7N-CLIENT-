package com.l7n.client.module.impl;

import com.l7n.client.Data;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.ClientInput;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class MovementModules {
    private MovementModules() {}

    public static class Spider extends Module {
        public Spider() { super("Spider", "Climb walls", Category.MOVEMENT); addSetting("speed", 0.2, 0.05); }
        @Override public void tick(Minecraft mc) {
            if (mc.player.horizontalCollision) { Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, get("speed"), v.z); }
        }
    }

    public static class Glide extends Module {
        public Glide() { super("Glide", "Fall slowly", Category.MOVEMENT); addSetting("fall", 0.05, 0.01); }
        @Override public void tick(Minecraft mc) {
            Vec3 v = mc.player.getDeltaMovement();
            if (!mc.player.onGround() && !mc.player.isInWater() && !mc.player.isFallFlying() && v.y < -get("fall"))
                mc.player.setDeltaMovement(v.x, -get("fall"), v.z);
        }
    }

    /** While gliding with an elytra, steer toward the nearest player. */
    public static class ElytraTarget extends Module {
        public ElytraTarget() {
            super("ElytraTarget", "Elytra auto-pilot toward the nearest player", Category.MOVEMENT);
            addSetting("range", 150, 10); addSetting("turn", 12, 1); addSetting("speed", 1.5, 0.1); addToggle("boost", true);
        }
        @Override public void tick(Minecraft mc) {
            if (mc.level == null || !mc.player.isFallFlying()) return;
            Player best = null; double bd = get("range");
            for (Player p : mc.level.players()) {
                if (p == mc.player || !p.isAlive() || Data.isFriend(p.getName().getString())) continue;
                double d = mc.player.distanceTo(p);
                if (d <= bd) { bd = d; best = p; }
            }
            if (best == null) return;
            Vec3 to = best.getBoundingBox().getCenter().subtract(mc.player.getEyePosition());
            float wantYaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90);
            float wantPitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z)));
            float turn = (float) get("turn");
            mc.player.setYRot(mc.player.getYRot() + Math.clamp(Mth.wrapDegrees(wantYaw - mc.player.getYRot()), -turn, turn));
            mc.player.setXRot(mc.player.getXRot() + Math.clamp(wantPitch - mc.player.getXRot(), -turn, turn));
            if (on("boost")) mc.player.setDeltaMovement(mc.player.getLookAngle().scale(get("speed")));
        }
    }

    /** Detached camera. Your player stays where it is (its input is frozen) while the camera flies around. */
    public static class Freecam extends Module {
        private static final class FrozenInput extends ClientInput {}
        private final FrozenInput frozen = new FrozenInput();
        private ClientInput saved;
        private ArmorStand cam;

        public Freecam() { super("Freecam", "Fly the camera around, your player stays put", Category.MOVEMENT); addSetting("speed", 0.8, 0.1); }

        @Override protected void onEnable() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return;
            cam = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
            cam.setNoGravity(true);
            cam.setInvisible(true);
            Vec3 e = mc.player.getEyePosition();
            cam.setPos(e.x, e.y - cam.getEyeHeight(), e.z);
            cam.setYRot(mc.player.getYRot());
            cam.setXRot(mc.player.getXRot());
            cam.baseTick();
            saved = mc.player.input;
            mc.player.input = frozen;
            mc.setCameraEntity(cam);
        }

        @Override protected void onDisable() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                if (mc.player.input == frozen && saved != null) mc.player.input = saved;
                mc.setCameraEntity(mc.player);
            }
            cam = null;
        }

        @Override public void tick(Minecraft mc) {
            if (cam == null) return;
            if (mc.player.input != frozen) { saved = mc.player.input; mc.player.input = frozen; }
            if (mc.getCameraEntity() != cam) mc.setCameraEntity(cam);
            cam.baseTick();
            cam.setYRot(mc.player.getYRot());
            cam.setXRot(mc.player.getXRot());
            if (mc.screen != null) return;
            Vec3 look = mc.player.getLookAngle();
            double yaw = Math.toRadians(mc.player.getYRot());
            Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
            Vec3 mv = Vec3.ZERO;
            var o = mc.options;
            if (o.keyUp.isDown()) mv = mv.add(look);
            if (o.keyDown.isDown()) mv = mv.subtract(look);
            if (o.keyLeft.isDown()) mv = mv.subtract(right);
            if (o.keyRight.isDown()) mv = mv.add(right);
            if (o.keyJump.isDown()) mv = mv.add(0, 1, 0);
            if (o.keyShift.isDown()) mv = mv.subtract(0, 1, 0);
            if (mv.lengthSqr() > 0) {
                mv = mv.normalize().scale(get("speed"));
                cam.setPos(cam.getX() + mv.x, cam.getY() + mv.y, cam.getZ() + mv.z);
            }
        }
    }
}
