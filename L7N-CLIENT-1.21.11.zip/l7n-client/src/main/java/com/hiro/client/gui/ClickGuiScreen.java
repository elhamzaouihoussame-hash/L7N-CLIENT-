package com.hiro.client.gui;

import com.hiro.client.Config;
import com.hiro.client.HiroClient;
import com.hiro.client.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int HEAD = 18, ROW = 13, GAP = 8;
    private static final int PURPLE = 0xFFA855F7;
    private static final int BOTTOM_RESERVED = 24;
    private static final double SCROLL_STEP = ROW * 2.0;
    private long openedAt;
    private final Module.Category[] cats = Module.Category.values();
    private final double[] categoryScroll = new double[cats.length];

    public ClickGuiScreen() { super(Component.literal("HIRO CLIENT")); }
    @Override protected void init() { openedAt = System.currentTimeMillis(); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { Config.save(); }

    private int pw() { return Math.clamp((width - 8 - (cats.length - 1) * GAP) / cats.length, 70, 110); }
    private int x0() { return (width - (cats.length * pw() + (cats.length - 1) * GAP)) / 2; }
    private int categoryY(int index, long now) {
        float p = Anim.easeOutBack((now - openedAt - index * 70L) / 450f);
        return (int) (14 - (1 - p) * 40);
    }
    private int viewportBottom() { return Math.max(HEAD + 20, height - BOTTOM_RESERVED); }
    private int viewportHeight() { return Math.max(20, viewportBottom() - (14 + HEAD)); }
    private double maxScroll(int index) {
        int count = HiroClient.modules.in(cats[index]).size();
        return Math.max(0, count * ROW - viewportHeight());
    }
    private void clampScroll(int index) {
        categoryScroll[index] = Math.max(0, Math.min(categoryScroll[index], maxScroll(index)));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        long now = System.currentTimeMillis();
        float open = Anim.easeOutCubic((now - openedAt) / 350f);
        Background.draw(g, width, height, open);

        int pw = pw(), x0 = x0();
        int contentBottom = viewportBottom();
        for (int i = 0; i < cats.length; i++) {
            int x = x0 + i * (pw + GAP);
            int y = categoryY(i, now);
            float p = Anim.easeOutBack((now - openedAt - i * 70L) / 450f);
            float a = Math.clamp(p, 0f, 1f);
            g.fill(x, y, x + pw, y + HEAD, Anim.alpha(PURPLE, a));
            g.drawString(font, cats[i].name(), x + 6, y + 5, Anim.alpha(0xFFFFFF, a));

            int top = y + HEAD;
            int bottom = Math.max(top + 1, contentBottom);
            List<Module> mods = HiroClient.modules.in(cats[i]);
            clampScroll(i);
            g.enableScissor(x, top, x + pw, bottom);
            int rowY = (int) Math.round(top - categoryScroll[i]);
            for (Module m : mods) {
                m.anim = Anim.approach(m.anim, m.isEnabled() ? 1f : 0f, 0.18f);
                boolean hover = mx >= x && mx < x + pw && my >= rowY && my < rowY + ROW;
                g.fill(x, rowY, x + pw, rowY + ROW, Anim.alpha(hover ? 0x2A1550 : 0x140A2A, 0.85f * a));
                g.fill(x, rowY, x + 2 + (int) (m.anim * (pw - 2)), rowY + ROW, Anim.alpha(PURPLE, 0.35f * m.anim * a));
                g.drawString(font, font.plainSubstrByWidth(m.name, pw - 8), x + 6, rowY + 3,
                        Anim.lerpColor(0xFFAAAAAA, 0xFFFFFFFF, m.anim));
                rowY += ROW;
            }
            g.disableScissor();

            // Small scrollbar shown only when the category has more modules than fit.
            double max = maxScroll(i);
            if (max > 0) {
                int trackX = x + pw - 3;
                int trackTop = top + 1;
                int trackBottom = bottom - 1;
                int trackH = Math.max(1, trackBottom - trackTop);
                int thumbH = Math.max(10, (int) (trackH * (viewportHeight() / (double) (mods.size() * ROW))));
                int thumbTravel = Math.max(0, trackH - thumbH);
                int thumbY = trackTop + (int) (thumbTravel * (categoryScroll[i] / max));
                g.fill(trackX, trackTop, trackX + 2, trackBottom, 0x55444444);
                g.fill(trackX, thumbY, trackX + 2, thumbY + thumbH, 0xFFD8B4FE);
            }
        }

        boolean hov = mx >= width - 84 && mx < width - 4 && my >= 1 && my < 13;
        g.fill(width - 84, 1, width - 4, 13, hov ? 0xFFC084FC : PURPLE);
        g.drawCenteredString(font, "COMMANDS", width - 44, 3, 0xFFFFFFFF);
        g.drawCenteredString(font, "HIRO CLIENT  -  Left click: toggle  |  Right click: settings", width / 2, height - 12, PURPLE);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int pw = pw(), x0 = x0();
        long now = System.currentTimeMillis();
        for (int i = 0; i < cats.length; i++) {
            int x = x0 + i * (pw + GAP);
            int top = categoryY(i, now) + HEAD;
            int bottom = viewportBottom();
            if (mouseX >= x && mouseX < x + pw && mouseY >= top && mouseY < bottom) {
                categoryScroll[i] -= verticalAmount * SCROLL_STEP;
                clampScroll(i);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        if (ev.x() >= width - 84 && ev.x() < width - 4 && ev.y() >= 1 && ev.y() < 13) {
            minecraft.setScreen(new CommandsScreen(this));
            return true;
        }
        int pw = pw(), x0 = x0();
        long now = System.currentTimeMillis();
        for (int i = 0; i < cats.length; i++) {
            int x = x0 + i * (pw + GAP);
            int top = categoryY(i, now) + HEAD;
            int bottom = viewportBottom();
            if (ev.x() < x || ev.x() >= x + pw || ev.y() < top || ev.y() >= bottom) continue;
            List<Module> mods = HiroClient.modules.in(cats[i]);
            int index = (int) ((ev.y() - top + categoryScroll[i]) / ROW);
            if (index >= 0 && index < mods.size()) {
                Module m = mods.get(index);
                if (ev.button() == 1) minecraft.setScreen(m instanceof com.hiro.client.module.impl.AutoLoginModule ? new AutoLoginScreen(this) : new ModuleSettingsScreen(m, this));
                else if (ev.button() == 0) m.toggle();
                return true;
            }
            return true;
        }
        return super.mouseClicked(ev, dbl);
    }
}
