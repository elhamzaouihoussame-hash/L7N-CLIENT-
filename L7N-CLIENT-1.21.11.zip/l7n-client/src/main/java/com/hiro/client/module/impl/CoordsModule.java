package com.hiro.client.module.impl;
import com.hiro.client.module.Module;
public class CoordsModule extends Module {
    public CoordsModule() { super("Coords", "Show XYZ on screen", Category.RENDER); }
}
