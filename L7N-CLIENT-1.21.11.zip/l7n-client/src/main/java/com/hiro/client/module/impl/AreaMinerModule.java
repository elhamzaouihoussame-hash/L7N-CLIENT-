package com.hiro.client.module.impl;

import com.hiro.client.CommandManager;
import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Mines every block inside a box you mark with two corners (like WorldEdit //pos1 and //pos2), top layer first.
 * Mark the corners from the "Build" tab in Commands, then enable this module.
 */
public class AreaMinerModule extends Module {
    private BlockPos p1, p2;
    private int cd;

    public AreaMinerModule() {
        super("AreaMiner", "Mines everything inside two marked corners, layer by layer", Category.MISC);
        addSetting("reach", 4.5, 0.5); addToggle("avoidlava", true); addToggle("leaveborder", false);
    }

    public void setPos1(BlockPos p) { p1 = p; CommandManager.info("AreaMiner pos1: " + p.getX() + " " + p.getY() + " " + p.getZ()); }
    public void setPos2(BlockPos p) { p2 = p; CommandManager.info("AreaMiner pos2: " + p.getX() + " " + p.getY() + " " + p.getZ()); }
    public boolean ready() { return p1 != null && p2 != null; }

    @Override protected void onEnable() {
        if (!ready()) { CommandManager.info("Mark pos1 and pos2 first (Build tab in Commands)"); setEnabled(false); }
    }
    @Override protected void onDisable() { Minecraft.getInstance().options.keyAttack.setDown(false); }

    private boolean inside(BlockPos p) {
        int minX = Math.min(p1.getX(), p2.getX()), maxX = Math.max(p1.getX(), p2.getX());
        int minY = Math.min(p1.getY(), p2.getY()), maxY = Math.max(p1.getY(), p2.getY());
        int minZ = Math.min(p1.getZ(), p2.getZ()), maxZ = Math.max(p1.getZ(), p2.getZ());
        return p.getX() >= minX && p.getX() <= maxX && p.getY() >= minY && p.getY() <= maxY && p.getZ() >= minZ && p.getZ() <= maxZ;
    }

    @Override public void tick(Minecraft mc) {
        var o = mc.options;
        o.keyAttack.setDown(false);
        if (!ready() || mc.screen != null || mc.gameMode == null || mc.level == null) return;
        if (cd > 0) { cd--; return; }
        int minX = Math.min(p1.getX(), p2.getX()), maxX = Math.max(p1.getX(), p2.getX());
        int minY = Math.min(p1.getY(), p2.getY()), maxY = Math.max(p1.getY(), p2.getY());
        int minZ = Math.min(p1.getZ(), p2.getZ()), maxZ = Math.max(p1.getZ(), p2.getZ());

        BlockPos target = null; double bd = Double.MAX_VALUE;
        for (int y = maxY; y >= minY; y--) {
            boolean any = false;
            for (int x = minX; x <= maxX; x++) for (int z = minZ; z <= maxZ; z++) {
                BlockPos p = new BlockPos(x, y, z);
                BlockState st = mc.level.getBlockState(p);
                if (st.isAir() || st.liquid()) continue;
                any = true;
                double d = mc.player.blockPosition().distSqr(p);
                if (d < bd) { bd = d; target = p; }
            }
            if (any) break; // finish this layer before moving down, so you never dig under solid blocks
        }
        if (target == null) { CommandManager.info("Area fully mined"); setEnabled(false); return; }

        if (on("avoidlava")) {
            var nb = mc.level.getFluidState(target.above());
            if (nb.is(FluidTags.LAVA) || mc.level.getFluidState(target).is(FluidTags.LAVA)) {
                CommandManager.info("Lava near the next block, stopping (.panic-safe)");
                setEnabled(false);
                return;
            }
        }
        int slot = BlockUtil.hotbar(mc, st -> st.getItem().components().has(net.minecraft.core.component.DataComponents.TOOL));
        if (slot >= 0) BlockUtil.select(mc, slot);

        Vec3 center = Vec3.atCenterOf(target);
        double dist = mc.player.getEyePosition().distanceTo(center);
        if (dist > get("reach")) { BlockUtil.face(mc, center); o.keyUp.setDown(true); return; }
        o.keyUp.setDown(false);
        BlockUtil.face(mc, center);
        mc.gameMode.destroyBlock(target);
        o.keyAttack.setDown(true);
        cd = 1;
    }
}
