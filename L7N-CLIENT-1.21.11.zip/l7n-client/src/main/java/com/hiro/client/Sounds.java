package com.hiro.client;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/** Custom sounds the client registers for itself. */
public final class Sounds {
    private Sounds() {}
    public static final SoundEvent MENU_OPEN = SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("hiro", "menu_open"));

    public static void playMenuOpen(Minecraft mc) {
        if (mc.player != null) mc.player.playSound(MENU_OPEN, 1.0f, 1.0f);
    }
}
