package com.hiro.client.module.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Cracked-server auto login. Keeps any number of servers (ip -> command). When you join one of them it waits
 * "delay" ticks and then sends the saved command (for example "/login 12345").
 * The list is edited in the ClickGUI: right click AutoLogin.
 */
public class AutoLoginModule extends Module {
    /** normalized server ip -> command */
    public final Map<String, String> servers = new LinkedHashMap<>();
    private Object lastPlayer;
    private int timer = -1;

    public AutoLoginModule() {
        super("AutoLogin", "Sends your login command when you join a saved server (cracked). Right click to edit the server list", Category.MISC);
        addSetting("delay", 40, 5); // ticks after joining (20 = 1 second)
    }

    public static String norm(String ip) {
        String s = ip == null ? "" : ip.trim().toLowerCase();
        if (s.endsWith(":25565")) s = s.substring(0, s.length() - 6);
        return s;
    }

    @Override public void saveExtra(JsonObject o) {
        JsonArray a = new JsonArray();
        for (var e : servers.entrySet()) {
            JsonObject s = new JsonObject();
            s.addProperty("ip", e.getKey());
            s.addProperty("cmd", e.getValue());
            a.add(s);
        }
        o.add("servers", a);
    }

    @Override public void loadExtra(JsonObject o) {
        servers.clear();
        if (!o.has("servers")) return;
        for (var el : o.getAsJsonArray("servers")) {
            JsonObject s = el.getAsJsonObject();
            servers.put(norm(s.get("ip").getAsString()), s.get("cmd").getAsString());
        }
    }

    @Override protected void onDisable() { timer = -1; lastPlayer = null; }

    @Override public void tick(Minecraft mc) {
        var p = mc.player;
        if (p == null) { lastPlayer = null; timer = -1; return; }
        if (p != lastPlayer) { // joined (or rejoined) a server
            lastPlayer = p;
            timer = -1;
            var sd = mc.getCurrentServer();
            if (sd != null && servers.containsKey(norm(sd.ip))) timer = Math.max(1, (int) get("delay"));
        }
        if (timer > 0 && --timer == 0) {
            var sd = mc.getCurrentServer();
            var conn = mc.getConnection();
            String cmd = sd == null ? null : servers.get(norm(sd.ip));
            if (conn == null || cmd == null || cmd.isBlank()) return;
            if (cmd.startsWith("/")) conn.sendCommand(cmd.substring(1));
            else conn.sendChat(cmd);
        }
    }
}
