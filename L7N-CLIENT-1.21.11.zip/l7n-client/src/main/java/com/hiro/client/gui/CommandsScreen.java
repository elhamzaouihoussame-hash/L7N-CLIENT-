package com.hiro.client.gui;

import com.hiro.client.AnimePack;
import com.hiro.client.Config;
import com.hiro.client.Data;
import com.hiro.client.HiroClient;
import com.hiro.client.Util;
import com.hiro.client.module.Module;
import com.hiro.client.module.impl.EmoteModule;
import com.hiro.client.module.impl.FinderModule;
import com.hiro.client.module.impl.StaffModules;
import com.hiro.client.module.impl.WorldModules;
import com.hiro.client.module.impl.SchematicBuilderModule;
import com.hiro.client.module.impl.AreaMinerModule;
import com.hiro.client.module.impl.ElytraFinderModule;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import java.util.ArrayList;
import java.util.List;

/** Every command is here as a button, so you never need to type in chat. Left click = run, right click = remove/alternative. */
public class CommandsScreen extends Screen {
    private static final int PURPLE = 0xFFA855F7, RH = 18, GAP = 3, TOP = 32;
    private static final String[] TABS = {"General", "Friends", "Staff", "Waypoints", "Finds", "Blocks", "Emotes", "Build"};
    private static final Block[] PRESETS = {
        Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE, Blocks.ANCIENT_DEBRIS, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
        Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE, Blocks.COAL_ORE, Blocks.LAPIS_ORE,
        Blocks.REDSTONE_ORE, Blocks.NETHER_GOLD_ORE, Blocks.NETHER_QUARTZ_ORE, Blocks.SPAWNER, Blocks.CHEST, Blocks.TRAPPED_CHEST,
        Blocks.ENDER_CHEST, Blocks.BARREL, Blocks.TNT, Blocks.OBSIDIAN, Blocks.NETHERITE_BLOCK, Blocks.BEACON, Blocks.END_PORTAL_FRAME
    };
    private final Screen parent;
    private int tab;
    private float scrollPx;

    private record Entry(String label, String status, Runnable run, Runnable alt) {}

    public CommandsScreen(Screen parent) { super(Component.literal("HIRO Commands")); this.parent = parent; }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { Config.save(); }
    @Override public void onClose() { minecraft.setScreen(parent); }

    private void note(String text) { Notifier.push("HIRO", text); }
    private String me() { return minecraft.player == null ? "" : minecraft.player.getName().getString(); }
    private void toggleModule(String name) { HiroClient.modules.byName(name).ifPresent(Module::toggle); }
    private String moduleState(String name) { return HiroClient.modules.byName(name).map(m -> m.isEnabled() ? "ON" : "OFF").orElse(""); }
    private String coords(double x, double y, double z) { return (int) x + " " + (int) y + " " + (int) z; }
    private void copy(String s) { minecraft.keyboardHandler.setClipboard(s); note("Copied: " + s); }
    private List<PlayerInfo> others() {
        List<PlayerInfo> l = new ArrayList<>();
        var conn = minecraft.getConnection();
        if (conn != null) for (PlayerInfo pi : conn.getOnlinePlayers()) if (!Util.name(pi).equalsIgnoreCase(me())) l.add(pi);
        return l;
    }

    private List<Entry> entries() {
        List<Entry> l = new ArrayList<>();
        var mc = minecraft;
        switch (tab) {
            case 0 -> {
                l.add(new Entry("PANIC (disable all)", "", () -> { for (Module m : HiroClient.modules.all) m.setEnabled(false); note("All modules disabled"); }, null));
                l.add(new Entry("AutoMace bot", moduleState("AutoMace"), () -> toggleModule("AutoMace"), null));
                l.add(new Entry("AutoFind (bases)", moduleState("AutoFind"), () -> toggleModule("AutoFind"), null));
                l.add(new Entry("HUD editor (move lists)", "", () -> mc.setScreen(new HudEditorScreen(this)), null));
                l.add(new Entry("Anime skin + katana", "toggle", () -> AnimePack.toggle(null), null));
                l.add(new Entry("Save config", "", () -> { Config.save(); note("Config saved"); }, null));
                l.add(new Entry("Load config", "", () -> { Config.load(); note("Config loaded"); }, null));
                l.add(new Entry("Copy my coordinates", "", () -> { if (mc.player != null) copy(coords(mc.player.getX(), mc.player.getY(), mc.player.getZ())); }, null));
                l.add(new Entry("Show my position", "", () -> { if (mc.player != null) note("XYZ " + coords(mc.player.getX(), mc.player.getY(), mc.player.getZ())); }, null));
                l.add(new Entry("Show ping", "", () -> {
                    var conn = mc.getConnection();
                    PlayerInfo pi = conn == null || mc.player == null ? null : conn.getPlayerInfo(mc.player.getUUID());
                    note(pi == null ? "Ping unknown" : "Ping: " + pi.getLatency() + " ms");
                }, null));
                l.add(new Entry("Show health", "", () -> { if (mc.player != null) note(String.format("Health %.1f  Food %d", mc.player.getHealth(), mc.player.getFoodData().getFoodLevel())); }, null));
                l.add(new Entry("FOV -5", String.valueOf(mc.options.fov().get()), () -> mc.options.fov().set(Math.clamp(mc.options.fov().get() - 5, 30, 110)), null));
                l.add(new Entry("FOV +5", String.valueOf(mc.options.fov().get()), () -> mc.options.fov().set(Math.clamp(mc.options.fov().get() + 5, 30, 110)), null));
                l.add(new Entry("Move up 5 blocks", "", () -> { if (mc.player != null) mc.player.setPos(mc.player.getX(), mc.player.getY() + 5, mc.player.getZ()); }, null));
                l.add(new Entry("Move down 5 blocks", "", () -> { if (mc.player != null) mc.player.setPos(mc.player.getX(), mc.player.getY() - 5, mc.player.getZ()); }, null));
                l.add(new Entry("Clear chat", "", () -> mc.gui.getChat().clearMessages(false), null));
            }
            case 1 -> {
                for (PlayerInfo pi : others()) {
                    String n = Util.name(pi);
                    l.add(new Entry(n, Data.isFriend(n) ? "FRIEND" : "", () -> {
                        if (Data.isFriend(n)) Data.friends.remove(n.toLowerCase()); else Data.friends.add(n.toLowerCase());
                        Config.save();
                    }, null));
                }
                if (l.isEmpty()) l.add(new Entry("No other players online", "", null, null));
            }
            case 2 -> {
                StaffModules.StaffList sl = HiroClient.modules.get(StaffModules.StaffList.class);
                for (var e : sl.ranks(mc).entrySet()) {
                    String[] words = e.getKey().toLowerCase().replaceAll("[^a-z0-9]+", " ").trim().split(" ");
                    boolean all = words.length > 0 && !words[0].isEmpty();
                    for (String w : words) if (w.length() >= 3 && !sl.keywords.contains(w)) all = false;
                    final boolean isOn = all;
                    l.add(new Entry("Rank: " + e.getKey() + " x" + e.getValue(), isOn ? "STAFF" : "", () -> {
                        for (String w : words) if (w.length() >= 3) { if (isOn) sl.keywords.remove(w); else sl.keywords.add(w); }
                        Config.save();
                    }, null));
                }
                for (PlayerInfo pi : others()) {
                    String n = Util.name(pi);
                    l.add(new Entry(n, sl.names.contains(n.toLowerCase()) ? "STAFF" : "", () -> {
                        if (!sl.names.remove(n.toLowerCase())) sl.names.add(n.toLowerCase());
                        Config.save();
                    }, null));
                }
                if (l.isEmpty()) l.add(new Entry("No players online", "", null, null));
            }
            case 3 -> {
                l.add(new Entry("+ Add waypoint here", "", () -> {
                    if (mc.player == null) return;
                    int i = Data.waypoints.size() + 1;
                    while (Data.waypoints.containsKey("wp" + i)) i++;
                    Data.waypoints.put("wp" + i, new double[]{mc.player.getX(), mc.player.getY(), mc.player.getZ()});
                    Config.save();
                }, null));
                for (var e : new ArrayList<>(Data.waypoints.entrySet())) {
                    double[] c = e.getValue();
                    String dist = mc.player == null ? "" : " (" + (int) Math.sqrt(mc.player.distanceToSqr(c[0], c[1], c[2])) + "m)";
                    l.add(new Entry(e.getKey(), coords(c[0], c[1], c[2]) + dist, () -> copy(coords(c[0], c[1], c[2])), () -> { Data.waypoints.remove(e.getKey()); Config.save(); }));
                }
            }
            case 4 -> {
                for (Module m : HiroClient.modules.all) {
                    if (!(m instanceof FinderModule fm) || !fm.isEnabled()) continue;
                    for (var f : fm.results()) {
                        var p = f.pos();
                        String dist = mc.player == null ? "" : " (" + (int) Math.sqrt(p.distSqr(mc.player.blockPosition())) + "m)";
                        l.add(new Entry(fm.name + ": " + f.label(), p.getX() + " " + p.getY() + " " + p.getZ() + dist, () -> copy(p.getX() + " " + p.getY() + " " + p.getZ()), null));
                    }
                }
                if (l.isEmpty()) l.add(new Entry("Enable BaseFinder / BaseBlocks / SpawnerESP / StorageESP first", "", null, null));
            }
            case 5 -> {
                WorldModules.BlockEsp be = HiroClient.modules.get(WorldModules.BlockEsp.class);
                l.add(new Entry("BlockESP module", be.isEnabled() ? "ON" : "OFF", be::toggle, null));
                for (Block b : PRESETS) {
                    String name = BuiltInRegistries.BLOCK.getKey(b).getPath();
                    l.add(new Entry(name, be.blocks.contains(b) ? "ON" : "", () -> {
                        if (!be.blocks.remove(b)) be.blocks.add(b);
                        Config.save();
                    }, null));
                }
            }
            case 7 -> {
                SchematicBuilderModule sb = HiroClient.modules.get(SchematicBuilderModule.class);
                AreaMinerModule am = HiroClient.modules.get(AreaMinerModule.class);
                ElytraFinderModule ef = HiroClient.modules.get(ElytraFinderModule.class);
                l.add(new Entry("ElytraFinder module", ef.isEnabled() ? "ON" : "OFF", ef::toggle, null));
                l.add(new Entry("--- AutoBuilder ---", "", null, null));
                l.add(new Entry("AutoBuilder module", sb.isEnabled() ? "ON" : "OFF", sb::toggle, null));
                String loaded = sb.loadedName();
                l.add(new Entry("Loaded: " + (loaded == null ? "none" : loaded), loaded == null ? "" : sb.progressText(), null, null));
                for (String f : SchematicBuilderModule.list())
                    l.add(new Entry(f, "", () -> sb.select(f, mc), null));
                if (SchematicBuilderModule.list().isEmpty())
                    l.add(new Entry("Put .litematic/.schem/.nbt files in config/hiro-client/schematics", "", null, null));
                l.add(new Entry("--- Area Miner ---", "", null, null));
                l.add(new Entry("AreaMiner module", am.isEnabled() ? "ON" : "OFF", am::toggle, null));
                l.add(new Entry("Set pos1 here", "", () -> { if (mc.player != null) am.setPos1(mc.player.blockPosition()); }, null));
                l.add(new Entry("Set pos2 here", "", () -> { if (mc.player != null) am.setPos2(mc.player.blockPosition()); }, null));
            }
            default -> {
                EmoteModule em = HiroClient.modules.get(EmoteModule.class);
                l.add(new Entry("STOP dancing", em.isEnabled() ? "ON" : "", () -> em.setEnabled(false), null));
                for (int i = 0; i < EmoteModule.NAMES.length; i++) {
                    final int n = i + 1;
                    l.add(new Entry(n + " " + EmoteModule.NAMES[i], em.isEnabled() && (int) em.get("dance") == n ? "ON" : "", () -> {
                        em.settings.put("dance", (double) n);
                        em.setEnabled(true);
                        em.restart();
                    }, null));
                }
            }
        }
        return l;
    }

    private int cols() { return width >= 380 ? 3 : 2; }
    private int colW() { return (width - 8 - (cols() - 1) * GAP) / cols(); }
    private int listTop() { return TOP; }
    private int listBottom() { return height - 22; }
    private int contentHeight(int count) { return ((count + cols() - 1) / cols()) * (RH + GAP); }
    private float maxScroll(int count) { return Math.max(0, contentHeight(count) - (listBottom() - listTop())); }
    private void clampScroll(int count) { scrollPx = Math.clamp(scrollPx, 0, maxScroll(count)); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        Background.draw(g, width, height, 1f);
        g.drawString(font, "HIRO Commands", 6, 3, PURPLE);
        boolean backHov = mx >= width - 44 && mx < width - 4 && my >= 1 && my < 12;
        g.fill(width - 44, 1, width - 4, 12, backHov ? 0xFF3B1D72 : 0xFF241042);
        g.drawCenteredString(font, "Back", width - 24, 3, 0xFFFFFFFF);

        int tw = (width - 8) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int x = 4 + i * tw;
            g.fill(x, 14, x + tw - 2, 28, i == tab ? PURPLE : 0xFF241042);
            g.drawCenteredString(font, font.plainSubstrByWidth(TABS[i], tw - 4), x + (tw - 2) / 2, 17, 0xFFFFFFFF);
        }

        List<Entry> list = entries();
        clampScroll(list.size());
        int cw = colW(), top = listTop(), bottom = listBottom();
        g.enableScissor(0, top, width, bottom);
        int firstRow = (int) (scrollPx / (RH + GAP));
        int y0 = top - (int) (scrollPx % (RH + GAP));
        for (int row = firstRow; y0 + (row - firstRow) * (RH + GAP) < bottom; row++) {
            int y = y0 + (row - firstRow) * (RH + GAP);
            for (int c = 0; c < cols(); c++) {
                int idx = row * cols() + c;
                if (idx < 0 || idx >= list.size()) continue;
                int x = 4 + c * (cw + GAP);
                Entry e = list.get(idx);
                boolean hover = mx >= x && mx < x + cw && my >= y && my < y + RH && my >= top && my < bottom;
                g.fill(x, y, x + cw, y + RH, hover ? 0xF02A1550 : 0xF0140A2A);
                int sw = e.status().isEmpty() ? 0 : font.width(e.status()) + 6;
                g.drawString(font, font.plainSubstrByWidth(e.label(), cw - 8 - sw), x + 4, y + 5, e.run() == null ? 0xFF888888 : 0xFFFFFFFF);
                if (!e.status().isEmpty()) {
                    boolean good = e.status().equals("ON") || e.status().equals("FRIEND") || e.status().equals("STAFF");
                    g.drawString(font, e.status(), x + cw - sw + 2, y + 5, good ? 0xFF4ADE80 : 0xFFCBB6F5);
                }
            }
        }
        g.disableScissor();

        float maxS = maxScroll(list.size());
        if (maxS > 0) {
            int trackH = bottom - top;
            int thumbH = Math.max(14, (int) ((float) trackH * trackH / (trackH + maxS)));
            int thumbY = top + (int) ((trackH - thumbH) * (scrollPx / maxS));
            g.fill(width - 4, top, width - 2, bottom, 0x50FFFFFF);
            g.fill(width - 4, thumbY, width - 2, thumbY + thumbH, PURPLE);
        }

        g.fill(4, height - 17, 64, height - 3, 0xFF241042);
        g.drawCenteredString(font, "Up", 34, height - 14, 0xFFFFFFFF);
        g.fill(width - 64, height - 17, width - 4, height - 3, 0xFF241042);
        g.drawCenteredString(font, "Down", width - 34, height - 14, 0xFFFFFFFF);
        g.drawCenteredString(font, "Scroll / drag the list, or Up / Down  |  Left: run  |  Right: remove", width / 2, height - 14, 0xFFAAAAAA);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        scrollPx -= scrollY * (RH + GAP) * 2;
        clampScroll(entries().size());
        return true;
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent ev, double dragX, double dragY) {
        if (ev.y() >= listTop() && ev.y() < listBottom()) {
            scrollPx -= dragY;
            clampScroll(entries().size());
            return true;
        }
        return super.mouseDragged(ev, dragX, dragY);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        double mx = ev.x(), my = ev.y();
        if (mx >= width - 44 && mx < width - 4 && my >= 1 && my < 12) { minecraft.setScreen(parent); return true; }
        int tw = (width - 8) / TABS.length;
        if (my >= 14 && my < 28) {
            for (int i = 0; i < TABS.length; i++) if (mx >= 4 + i * tw && mx < 4 + (i + 1) * tw - 2) { tab = i; scrollPx = 0; return true; }
        }
        List<Entry> list = entries();
        int top = listTop(), bottom = listBottom(), cw = colW();
        if (my >= height - 17 && my < height - 3) {
            if (mx >= 4 && mx < 64) { scrollPx -= (bottom - top) * 0.8f; clampScroll(list.size()); return true; }
            if (mx >= width - 64 && mx < width - 4) { scrollPx += (bottom - top) * 0.8f; clampScroll(list.size()); return true; }
        }
        if (my < top || my >= bottom) return super.mouseClicked(ev, dbl);
        int firstRow = (int) (scrollPx / (RH + GAP));
        int y0 = top - (int) (scrollPx % (RH + GAP));
        for (int row = firstRow; y0 + (row - firstRow) * (RH + GAP) < bottom; row++) {
            int y = y0 + (row - firstRow) * (RH + GAP);
            if (my < y || my >= y + RH) continue;
            for (int c = 0; c < cols(); c++) {
                int idx = row * cols() + c;
                if (idx < 0 || idx >= list.size()) continue;
                int x = 4 + c * (cw + GAP);
                if (mx >= x && mx < x + cw) {
                    Entry e = list.get(idx);
                    if (ev.button() == 1) { if (e.alt() != null) e.alt().run(); }
                    else if (ev.button() == 0 && e.run() != null) e.run().run();
                    return true;
                }
            }
        }
        return super.mouseClicked(ev, dbl);
    }
}
