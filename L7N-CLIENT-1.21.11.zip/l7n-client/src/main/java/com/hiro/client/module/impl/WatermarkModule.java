package com.hiro.client.module.impl;
import com.hiro.client.module.Module;
public class WatermarkModule extends Module {
    public WatermarkModule() { super("Watermark", "HIRO logo + name on screen", Category.RENDER); }
}
