package com.hiro.client.gui;

import com.hiro.client.HiroClient;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;

/** The HIRO image covering the whole screen (cropped to fill, never stretched), slightly darkened so the menu stays readable. */
public final class Background {
    private Background() {}
    private static final int TEX = 512;

    /** @param fade 0..1, the image fades in from black */
    public static void draw(GuiGraphics g, int w, int h, float fade) {
        float aspect = (float) w / h;
        int rw = TEX, rh = TEX;
        if (aspect >= 1f) rh = Math.round(TEX / aspect); else rw = Math.round(TEX * aspect);
        g.blit(RenderPipelines.GUI_TEXTURED, HiroClient.LOGO, 0, 0, (TEX - rw) / 2, (TEX - rh) / 2, w, h, rw, rh, TEX, TEX);
        g.fill(0, 0, w, h, Anim.alpha(0x000000, 0.40f + 0.60f * (1f - Math.clamp(fade, 0f, 1f))));
    }
}
