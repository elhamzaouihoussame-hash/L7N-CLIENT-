package com.hiro.client.module.impl;

import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Fast crystal PvP. Every tick it runs as many place + break cycles as "speed" asks for
 * (speed = cycles per second, 20 = one per tick). Crystals are placed on obsidian / bedrock near the
 * enemy and blown up right away. Raise or lower "speed" in the module settings.
 */
public class CrystalSpeedModule extends Module {
    private double acc;
    private int saved = -1, tickNo;
    private final Map<BlockPos, Integer> placed = new HashMap<>();
    private final Set<Integer> hit = new HashSet<>();

    public CrystalSpeedModule() {
        super("CrystalSpeed", "Places crystals fast and explodes them by itself. Speed is adjustable in settings", Category.COMBAT);
        addSetting("speed", 20, 2);          // place+break cycles per second (20 = 1 per tick)
        addSetting("range", 4.5, 0.5); addSetting("breakrange", 4.5, 0.5); addSetting("targetrange", 10, 1);
        addSetting("mindamage", 4, 0.5); addSetting("maxself", 8, 0.5);
        addToggle("place", true); addToggle("break", true); addToggle("rotate", true);
    }

    private void remember(Minecraft mc) { if (saved < 0) saved = mc.player.getInventory().getSelectedSlot(); }
    private void restoreSlot(Minecraft mc) { if (saved >= 0) { BlockUtil.select(mc, saved); saved = -1; } }
    @Override protected void onDisable() { saved = -1; acc = 0; placed.clear(); }

    @Override public void tick(Minecraft mc) {
        if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
        tickNo++;
        placed.values().removeIf(t -> tickNo - t > 3);
        Player target = CombatModules.nearestPlayer(mc, get("targetrange"));
        if (target == null) { restoreSlot(mc); acc = 0; return; }
        if (mc.player.getHealth() < 6) return;

        acc = Math.min(acc + Math.max(1, get("speed")) / 20.0, 6); // at most 6 cycles in one tick
        hit.clear();
        while (acc >= 1) {
            acc -= 1;
            boolean did = false;
            if (on("break")) did |= breakOne(mc, target);
            if (on("place")) did |= placeOne(mc, target);
            if (!did) { acc = Math.min(acc, 1); break; }
        }
    }

    private boolean breakOne(Minecraft mc, Player target) {
        EndCrystal best = null; double bd = 1e9;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof EndCrystal c) || !c.isAlive() || hit.contains(c.getId())) continue;
            double eyeD = mc.player.getEyePosition().distanceTo(c.getBoundingBox().getCenter());
            if (eyeD > get("breakrange")) continue;
            if (target.position().distanceTo(c.position()) > 12) continue;
            double self = CombatModules.explosionDamage(mc.player.position().distanceTo(c.position()), 6);
            if (self > get("maxself") || self >= mc.player.getHealth() - 2) continue;
            if (eyeD < bd) { bd = eyeD; best = c; }
        }
        if (best == null) return false;
        if (on("rotate")) BlockUtil.face(mc, best.getBoundingBox().getCenter());
        mc.gameMode.attack(mc.player, best);
        mc.player.swing(InteractionHand.MAIN_HAND);
        hit.add(best.getId());
        return true;
    }

    private boolean placeOne(Minecraft mc, Player target) {
        Vec3 eye = mc.player.getEyePosition(), tp = target.position(), me = mc.player.position();
        BlockPos tb = target.blockPosition(), bestBase = null;
        double bestScore = -1e9;
        for (int dx = -5; dx <= 5; dx++) for (int dy = -3; dy <= 1; dy++) for (int dz = -5; dz <= 5; dz++) {
            BlockPos b = tb.offset(dx, dy, dz);
            if (placed.containsKey(b)) continue;
            BlockState st = mc.level.getBlockState(b);
            if (!st.is(Blocks.OBSIDIAN) && !st.is(Blocks.BEDROCK)) continue;
            if (!mc.level.isEmptyBlock(b.above()) || !mc.level.isEmptyBlock(b.above(2))) continue;
            Vec3 top = new Vec3(b.getX() + 0.5, b.getY() + 1, b.getZ() + 0.5);
            if (eye.distanceTo(top) > get("range")) continue;
            double td = CombatModules.explosionDamage(tp.distanceTo(top), 6), sd = CombatModules.explosionDamage(me.distanceTo(top), 6);
            if (td < get("mindamage") || sd > get("maxself") || sd >= mc.player.getHealth() - 2) continue;
            if (!mc.level.getEntities((Entity) null, new AABB(b.above()).expandTowards(0, 1, 0), e -> true).isEmpty()) continue;
            double score = td - sd * 0.5;
            if (score > bestScore) { bestScore = score; bestBase = b; }
        }
        if (bestBase == null) return false;
        InteractionHand hand = InteractionHand.MAIN_HAND;
        if (mc.player.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
        else {
            int slot = BlockUtil.hotbar(mc, s -> s.is(Items.END_CRYSTAL));
            if (slot < 0) return false;
            remember(mc);
            BlockUtil.select(mc, slot);
        }
        Vec3 hitPos = new Vec3(bestBase.getX() + 0.5, bestBase.getY() + 1, bestBase.getZ() + 0.5);
        if (on("rotate")) BlockUtil.face(mc, hitPos);
        mc.gameMode.useItemOn(mc.player, hand, new BlockHitResult(hitPos, Direction.UP, bestBase, false));
        mc.player.swing(hand);
        placed.put(bestBase, tickNo);
        return true;
    }
}
