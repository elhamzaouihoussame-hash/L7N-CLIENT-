package com.hiro.client.module.impl;

import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import java.util.function.Predicate;

/**
 * Stand-alone mace bot. Turn it on and it plays by itself:
 * look up + ender pearl, wind charge launch, elytra glide, never walks or flies toward an enemy.
 * When anybody gets close it puts on a chestplate and hits everyone in reach (360 degrees) with the mace.
 */
public class ElytraMaceBot extends Module {
    private static final int IDLE = 0, WIND = 1, RISE = 2;
    private int phase, timer, invCd, tick;

    public ElytraMaceBot() {
        super("AutoElytraMace", "Bot: look up, pearl + wind charge, elytra, chestplate, mace hits in 360 degrees. Never chases", Category.COMBAT);
        addSetting("range", 60, 5);        // a player must be this close before the bot launches
        addSetting("reach", 3.5, 0.1);     // mace hit distance, any direction
        addSetting("swapdist", 10, 1);     // put the chestplate on when someone is this close
        addSetting("pearlangle", 90, 5);   // degrees UP for the pearl throw
        addSetting("windangle", 90, 5);    // degrees DOWN for the wind charge throw
        addSetting("windwait", 6, 1);      // ticks between pearl and wind charge
        addSetting("glideangle", 10, 1);   // degrees UP while gliding (keeps height)
        addToggle("pearl", true); addToggle("windcharge", true); addToggle("elytra", true); addToggle("chestplate", true);
    }

    private void release(Minecraft mc) {
        var o = mc.options;
        o.keyUp.setDown(false); o.keyDown.setDown(false); o.keyLeft.setDown(false); o.keyRight.setDown(false);
        o.keyJump.setDown(false); o.keySprint.setDown(false);
    }
    @Override protected void onDisable() { release(Minecraft.getInstance()); phase = IDLE; timer = 0; }

    private static boolean isChestplate(ItemStack st) {
        return !st.isEmpty() && BuiltInRegistries.ITEM.getKey(st.getItem()).getPath().endsWith("_chestplate");
    }
    private static boolean keep(ItemStack st) {
        return st.is(Items.MACE) || st.is(Items.ENDER_PEARL) || st.is(Items.WIND_CHARGE) || st.is(Items.ELYTRA) || isChestplate(st);
    }

    /** Find an item in the hotbar, or swap it in from the inventory (into a slot that holds nothing important). */
    private int ensureHotbar(Minecraft mc, Predicate<ItemStack> test) {
        int found = BlockUtil.hotbar(mc, test);
        if (found >= 0) return found;
        var inv = mc.player.getInventory();
        int dest = -1;
        for (int h = 0; h < 9 && dest < 0; h++) if (inv.getItem(h).isEmpty()) dest = h;
        for (int h = 0; h < 9 && dest < 0; h++) if (!keep(inv.getItem(h))) dest = h;
        if (dest < 0) dest = inv.getSelectedSlot();
        for (int i = 9; i < 36; i++) {
            if (test.test(inv.getItem(i))) {
                mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, i, dest, ClickType.SWAP, mc.player);
                return dest;
            }
        }
        return -1;
    }

    /** Swap the chest armor slot (menu slot 6) with a hotbar slot. */
    private void swapChest(Minecraft mc, int hotbarSlot) {
        mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, 6, hotbarSlot, ClickType.SWAP, mc.player);
        invCd = 4;
    }

    private void use(Minecraft mc, int slot) {
        BlockUtil.select(mc, slot);
        mc.gameMode.useItem(mc.player, InteractionHand.MAIN_HAND);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private void holdMace(Minecraft mc) {
        int m = ensureHotbar(mc, st -> st.is(Items.MACE));
        if (m >= 0 && mc.player.getInventory().getSelectedSlot() != m) BlockUtil.select(mc, m);
    }

    @Override public void tick(Minecraft mc) {
        release(mc);
        if (mc.screen != null || mc.level == null || mc.gameMode == null) return;
        var me = mc.player;
        if (!me.isAlive()) { phase = IDLE; return; }
        if (timer > 0) timer--;
        if (invCd > 0) invCd--;
        tick++;
        boolean elyWorn = me.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);

        // 1) anybody in mace reach (360 degrees, no facing check): chestplate on, mace out, hit
        Player hit = CombatModules.nearestPlayer(mc, get("reach"));
        if (hit != null) {
            if (on("chestplate") && elyWorn) {
                if (invCd == 0) { int cp = ensureHotbar(mc, ElytraMaceBot::isChestplate); if (cp >= 0) { swapChest(mc, cp); } }
                return;
            }
            int mace = ensureHotbar(mc, st -> st.is(Items.MACE));
            if (mace < 0) return;
            if (me.getInventory().getSelectedSlot() != mace) BlockUtil.select(mc, mace);
            BlockUtil.face(mc, hit.getBoundingBox().getCenter());
            if (me.getAttackStrengthScale(0f) >= 0.9f) { mc.gameMode.attack(me, hit); me.swing(InteractionHand.MAIN_HAND); }
            return;
        }

        // 2) somebody is close: get the chestplate on early, hold the mace, do NOT go toward them
        Player close = CombatModules.nearestPlayer(mc, get("swapdist"));
        if (close != null) {
            if (on("chestplate") && elyWorn && !me.onGround() && invCd == 0) {
                int cp = ensureHotbar(mc, ElytraMaceBot::isChestplate);
                if (cp >= 0) { swapChest(mc, cp); return; }
            }
            holdMace(mc);
            if (!me.isFallFlying()) return; // falling with the mace; wait for them to come into reach
        }

        // 3) gliding: keep height, never aim at anybody
        if (me.isFallFlying()) {
            float want = -(float) get("glideangle");
            me.setXRot(me.getXRot() + Math.clamp(Mth.wrapDegrees(want - me.getXRot()), -4f, 4f));
            return;
        }

        // 4) in the air and falling: wear the elytra and open it
        if (!me.onGround()) {
            phase = IDLE; timer = Math.max(timer, 60);
            if (!on("elytra") || close != null) return;
            if (me.getDeltaMovement().y < -0.05) {
                if (!elyWorn) {
                    if (invCd == 0) { int el = ensureHotbar(mc, st -> st.is(Items.ELYTRA)); if (el >= 0) swapChest(mc, el); }
                    return;
                }
                if ((tick & 1) == 0) mc.options.keyJump.setDown(true); // fresh key press every other tick
            }
            return;
        }

        // 5) on the ground: wait for somebody in range, then launch (pearl first, wind charge after)
        Player far = CombatModules.nearestPlayer(mc, get("range"));
        if (far == null) { phase = IDLE; holdMace(mc); return; }
        switch (phase) {
            case IDLE -> {
                if (timer > 0) { holdMace(mc); return; }
                if (on("windcharge") && ensureHotbar(mc, st -> st.is(Items.WIND_CHARGE)) < 0) return;
                int pearl = on("pearl") ? ensureHotbar(mc, st -> st.is(Items.ENDER_PEARL)) : -1;
                if (pearl >= 0) {
                    me.setXRot(-(float) get("pearlangle")); // look up
                    use(mc, pearl);
                }
                phase = WIND;
                timer = (int) get("windwait");
            }
            case WIND -> {
                if (timer > 0) return;
                int wind = on("windcharge") ? BlockUtil.hotbar(mc, st -> st.is(Items.WIND_CHARGE)) : -1;
                if (wind >= 0) {
                    me.setXRot((float) get("windangle")); // look down at the feet
                    mc.options.keyJump.setDown(true);
                    use(mc, wind);
                }
                phase = RISE;
                timer = 10;
            }
            case RISE -> {
                mc.options.keyJump.setDown(true);
                if (timer == 0) { phase = IDLE; timer = 60; }
            }
            default -> phase = IDLE;
        }
    }
}
