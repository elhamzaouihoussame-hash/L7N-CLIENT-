package com.hiro.client.module.impl;

import com.hiro.client.CommandManager;

import com.hiro.client.Data;
import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.ClientInput;
import net.minecraft.util.Mth;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Items;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public final class MovementModules {
    private MovementModules() {}

    public static class Spider extends Module {
        public Spider() { super("Spider", "Climb walls", Category.MOVEMENT); addSetting("speed", 0.2, 0.05); }
        @Override public void tick(Minecraft mc) {
            if (mc.player.horizontalCollision) { Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, get("speed"), v.z); }
        }
    }

    public static class Glide extends Module {
        public Glide() { super("Glide", "Fall slowly", Category.MOVEMENT); addSetting("fall", 0.05, 0.01); }
        @Override public void tick(Minecraft mc) {
            Vec3 v = mc.player.getDeltaMovement();
            if (!mc.player.onGround() && !mc.player.isInWater() && !mc.player.isFallFlying() && v.y < -get("fall"))
                mc.player.setDeltaMovement(v.x, -get("fall"), v.z);
        }
    }

    /**
     * While gliding with an elytra: steer toward the nearest player, keep a sword in your hand, and use fireworks
     * automatically. Fireworks are taken from ANYWHERE in your inventory and used from the offhand, so your sword
     * never leaves your hand.
     */
    public static class ElytraTarget extends Module {
        private int fwCd, swapped = -1;
        public ElytraTarget() {
            super("ElytraTarget", "Elytra auto-pilot to the nearest player, auto firework from the inventory, sword in hand", Category.MOVEMENT);
            addSetting("range", 150, 10); addSetting("turn", 12, 1); addSetting("speed", 1.5, 0.1);
            addToggle("boost", false); addToggle("firework", true); addSetting("minspeed", 1.0, 0.1); addSetting("fwdelay", 25, 1);
            addToggle("sword", true); addToggle("restore", true);
        }
        private void swapOffhand(Minecraft mc, int menuSlot) {
            mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, menuSlot, 40, ClickType.SWAP, mc.player);
        }
        /** @return true when a firework is in the offhand and ready to use. */
        private boolean prepareFirework(Minecraft mc) {
            if (mc.player.getOffhandItem().is(Items.FIREWORK_ROCKET)) return true;
            var inv = mc.player.getInventory();
            for (int i = 0; i < 36; i++) {
                if (inv.getItem(i).is(Items.FIREWORK_ROCKET)) {
                    int slot = i < 9 ? 36 + i : i;
                    swapOffhand(mc, slot);
                    swapped = slot;
                    return false; // use it on the next tick
                }
            }
            return false;
        }
        @Override public void tick(Minecraft mc) {
            if (mc.level == null || mc.gameMode == null) return;
            if (!mc.player.isFallFlying()) {
                if (swapped >= 0 && on("restore")) swapOffhand(mc, swapped);
                swapped = -1;
                return;
            }
            if (on("sword") && !mc.player.getMainHandItem().is(ItemTags.SWORDS)) {
                int sw = BlockUtil.hotbar(mc, st -> st.is(ItemTags.SWORDS));
                if (sw >= 0) BlockUtil.select(mc, sw);
            }
            Player best = null; double bd = get("range");
            for (Player p : mc.level.players()) {
                if (p == mc.player || !p.isAlive() || Data.isFriend(p.getName().getString())) continue;
                double d = mc.player.distanceTo(p);
                if (d <= bd) { bd = d; best = p; }
            }
            if (best != null) {
                Vec3 to = best.getBoundingBox().getCenter().subtract(mc.player.getEyePosition());
                float wantYaw = (float) (Math.toDegrees(Math.atan2(to.z, to.x)) - 90);
                float wantPitch = (float) -Math.toDegrees(Math.atan2(to.y, Math.hypot(to.x, to.z)));
                float turn = (float) get("turn");
                mc.player.setYRot(mc.player.getYRot() + Math.clamp(Mth.wrapDegrees(wantYaw - mc.player.getYRot()), -turn, turn));
                mc.player.setXRot(mc.player.getXRot() + Math.clamp(wantPitch - mc.player.getXRot(), -turn, turn));
                if (on("boost")) mc.player.setDeltaMovement(mc.player.getLookAngle().scale(get("speed")));
            }
            if (on("firework")) {
                if (fwCd > 0) { fwCd--; return; }
                if (mc.player.getDeltaMovement().length() >= get("minspeed")) return;
                if (prepareFirework(mc)) {
                    mc.gameMode.useItem(mc.player, InteractionHand.OFF_HAND);
                    mc.player.swing(InteractionHand.OFF_HAND);
                    fwCd = (int) get("fwdelay");
                } else fwCd = 2;
            }
        }
    }

    /**
     * Detached camera. Your player stays exactly where it is (its input is frozen) while a stand-in camera flies
     * around freely. Sprint = faster. Turns itself off if you take damage, die, or change world/screen errors.
     * The camera object is never ticked by the game (we only ever move its position/rotation fields ourselves),
     * which avoids the freezes older versions of this module could cause.
     */
    public static class Freecam extends Module {
        private static final class FrozenInput extends ClientInput {}
        private final FrozenInput frozen = new FrozenInput();
        private ClientInput saved;
        private ArmorStand cam;

        public Freecam() {
            super("Freecam", "Detached noclip camera; move and look independently while your player stays still", Category.MOVEMENT);
            addSetting("speed", 0.8, 0.1); addSetting("sprintspeed", 2.5, 0.1); addToggle("autooff", true);
        }

        @Override protected void onEnable() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) { cam = null; setEnabled(false); return; }
            try {
                cam = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
                cam.setInvisible(true);
                Vec3 e = mc.player.getEyePosition();
                cam.setPos(e.x, e.y, e.z);
                cam.xo = e.x; cam.yo = e.y; cam.zo = e.z;
                cam.setYRot(mc.player.getYRot());
                cam.setXRot(mc.player.getXRot());
                cam.yRotO = cam.getYRot();
                cam.xRotO = cam.getXRot();
                saved = mc.player.input;
                mc.player.input = frozen;
                mc.setCameraEntity(cam);
            } catch (Exception ex) {
                cam = null;
                CommandManager.info("Freecam could not start: " + ex.getMessage());
                setEnabled(false);
            }
        }

        @Override protected void onDisable() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) {
                if (mc.player.input == frozen && saved != null) mc.player.input = saved;
                mc.setCameraEntity(mc.player);
            }
            cam = null;
        }

        @Override public void tick(Minecraft mc) {
            if (cam == null) { setEnabled(false); return; }
            try {
                if (mc.player == null) { setEnabled(false); return; }
                if (on("autooff") && (cam.level() != mc.level || mc.player.hurtTime > 0 || !mc.player.isAlive())) {
                    setEnabled(false);
                    return;
                }
                var o = mc.options;
                o.keyAttack.setDown(false);
                o.keyUse.setDown(false);
                if (mc.player.input != frozen) { saved = mc.player.input; mc.player.input = frozen; }
                if (mc.getCameraEntity() != cam) mc.setCameraEntity(cam);
                // Keep camera rotation independent from the frozen player, like standard detached-camera mods.
                cam.xRotO = cam.getXRot();
                cam.yRotO = cam.getYRot();
                if (mc.screen != null) return;
                Vec3 look = cam.getLookAngle();
                double yaw = Math.toRadians(cam.getYRot());
                Vec3 right = new Vec3(-Math.cos(yaw), 0, -Math.sin(yaw));
                Vec3 mv = Vec3.ZERO;
                if (o.keyUp.isDown()) mv = mv.add(look);
                if (o.keyDown.isDown()) mv = mv.subtract(look);
                if (o.keyLeft.isDown()) mv = mv.subtract(right);
                if (o.keyRight.isDown()) mv = mv.add(right);
                if (o.keyJump.isDown()) mv = mv.add(0, 1, 0);
                if (o.keyShift.isDown()) mv = mv.subtract(0, 1, 0);
                if (mv.lengthSqr() > 0) {
                    mv = mv.normalize().scale(get("speed") * (o.keySprint.isDown() ? get("sprintspeed") : 1.0));
                    cam.xo = cam.getX(); cam.yo = cam.getY(); cam.zo = cam.getZ();
                    cam.setPos(cam.getX() + mv.x, cam.getY() + mv.y, cam.getZ() + mv.z);
                }
            } catch (Exception ex) {
                CommandManager.info("Freecam stopped (error): " + ex.getMessage());
                setEnabled(false);
            }
        }
    }
}
