package com.hiro.client;

import com.hiro.client.gui.ClickGuiScreen;
import com.hiro.client.gui.Hud;
import com.hiro.client.module.ModuleManager;
import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.network.chat.Component;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import com.hiro.client.module.Module;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.Registry;

public class HiroClient implements ClientModInitializer {
    public static final String NAME = "HIRO CLIENT";
    public static final Identifier LOGO = Identifier.fromNamespaceAndPath("hiro", "textures/gui/logo.png");
    public static final int LOGO_W = 512, LOGO_H = 512; // actual size of logo.png
    public static ModuleManager modules;
    private static KeyMapping openGui, panicKey;
    private static final Map<KeyMapping, Module> moduleKeys = new LinkedHashMap<>();
    private static final Identifier OPEN_SOUND_ID = Identifier.fromNamespaceAndPath("hiro", "open");
    private static final SoundEvent OPEN_SOUND = SoundEvent.createVariableRangeEvent(OPEN_SOUND_ID);

    @Override
    public void onInitializeClient() {
        Registry.register(BuiltInRegistries.SOUND_EVENT, OPEN_SOUND_ID, OPEN_SOUND);
        modules = new ModuleManager();
        Config.load();
        KeyMapping.Category cat = KeyMapping.Category.register(Identifier.fromNamespaceAndPath("hiro", "main"));
        openGui = KeyBindingHelper.registerKeyBinding(
                new KeyMapping("key.hiro.gui", InputConstants.KEY_RSHIFT, cat));
        panicKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.hiro.panic", -1, cat)); // unbound: choose your key in Controls
        // Every module gets its own configurable toggle key. Minecraft stores these in options.txt.
        for (Module module : modules.all) {
            String id = module.name.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]+", "_");
            KeyMapping key = KeyBindingHelper.registerKeyBinding(
                    new KeyMapping("key.hiro.module." + id, -1, cat));
            moduleKeys.put(key, module);
        }
        Hud.register();
        // Touch-friendly: an "HIRO" button in the pause menu opens the ClickGUI (no keyboard needed)
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof PauseScreen)
                Screens.getButtons(screen).add(Button.builder(Component.literal("HIRO"), b -> client.setScreen(new ClickGuiScreen())).bounds(4, 4, 70, 20).build());
        });
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !CommandManager.handle(msg));
        ClientTickEvents.START_CLIENT_TICK.register(mc -> {
            var fc = modules.get(com.hiro.client.module.impl.MovementModules.Freecam.class);
            if (fc != null && fc.isEnabled() && mc.screen == null) {
                while (mc.options.keyAttack.consumeClick()) { }
                while (mc.options.keyUse.consumeClick()) { }
                while (mc.options.keyPickItem.consumeClick()) { }
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.consumeClick()) {
                if (mc.screen == null) {
                    mc.getSoundManager().play(SimpleSoundInstance.forUI(OPEN_SOUND, 1.0F));
                    mc.setScreen(new ClickGuiScreen());
                }
            }
            while (panicKey.consumeClick()) {
                for (var m : modules.all) m.setEnabled(false);
                CommandManager.info("§cAll modules disabled");
            }
            for (var entry : moduleKeys.entrySet()) {
                while (entry.getKey().consumeClick()) {
                    Module module = entry.getValue();
                    module.toggle();
                    CommandManager.info((module.isEnabled() ? "§aEnabled: " : "§cDisabled: ") + module.name);
                }
            }
            if (mc.player != null) modules.tick(mc);
        });
    }
}
