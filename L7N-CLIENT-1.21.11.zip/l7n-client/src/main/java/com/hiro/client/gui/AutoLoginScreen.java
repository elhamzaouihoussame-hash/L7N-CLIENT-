package com.hiro.client.gui;

import com.hiro.client.Config;
import com.hiro.client.HiroClient;
import com.hiro.client.module.impl.AutoLoginModule;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Server list of AutoLogin: any number of servers, each with its own login command. */
public class AutoLoginScreen extends Screen {
    private static final int W = 320, RH = 16, GAP = 2, TOP = 40, PURPLE = 0xFFA855F7;
    private final Screen parent;
    private final AutoLoginModule m;
    private EditBox ipBox, cmdBox;
    private int scroll;

    public AutoLoginScreen(Screen parent) {
        super(Component.literal("AutoLogin"));
        this.parent = parent;
        this.m = HiroClient.modules.get(AutoLoginModule.class);
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { Config.save(); }
    @Override public void onClose() { minecraft.setScreen(parent); }

    private int visibleRows() { return Math.max(1, (height - 90 - TOP) / (RH + GAP)); }
    private List<Map.Entry<String, String>> rows() { return new ArrayList<>(m.servers.entrySet()); }

    @Override
    protected void init() {
        int x = (width - W) / 2;
        ipBox = new EditBox(font, x, height - 80, W, 18, Component.literal("Server IP"));
        ipBox.setMaxLength(100);
        ipBox.setHint(Component.literal("Server IP  (example: play.server.net)"));
        cmdBox = new EditBox(font, x, height - 58, W, 18, Component.literal("Command"));
        cmdBox.setMaxLength(200);
        cmdBox.setHint(Component.literal("Login command  (example: /login 12345)"));
        addRenderableWidget(ipBox);
        addRenderableWidget(cmdBox);
        addRenderableWidget(Button.builder(Component.literal("Add / Save"), b -> save()).bounds(x, height - 34, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("-"), b -> m.adjust("delay", -1)).bounds(x + 106, height - 34, 22, 20).build());
        addRenderableWidget(Button.builder(Component.literal("+"), b -> m.adjust("delay", 1)).bounds(x + 192, height - 34, 22, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose()).bounds(x + W - 70, height - 34, 70, 20).build());
    }

    private void save() {
        String ip = AutoLoginModule.norm(ipBox.getValue());
        String cmd = cmdBox.getValue().trim();
        if (ip.isEmpty() || cmd.isEmpty()) return;
        m.servers.put(ip, cmd);
        ipBox.setValue("");
        cmdBox.setValue("");
        Config.save();
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        Background.draw(g, width, height, 1f);
        g.drawCenteredString(font, "AutoLogin  -  " + m.servers.size() + " servers  -  module " + (m.isEnabled() ? "ON" : "OFF (turn it on in the ClickGUI)"), width / 2, 12, PURPLE);
        g.drawCenteredString(font, "Click a row to edit it, X to delete it, scroll for more", width / 2, 25, 0xFFAAAAAA);
        int x = (width - W) / 2, y = TOP;
        List<Map.Entry<String, String>> list = rows();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, list.size() - visibleRows())));
        for (int i = scroll; i < list.size() && i < scroll + visibleRows(); i++) {
            var e = list.get(i);
            boolean hover = mx >= x && mx < x + W && my >= y && my < y + RH;
            g.fill(x, y, x + W, y + RH, hover ? 0xF02A1550 : 0xF0140A2A);
            g.drawString(font, font.plainSubstrByWidth(e.getKey() + "   ->   " + e.getValue(), W - 24), x + 6, y + 4, 0xFFFFFFFF);
            g.fill(x + W - 16, y + 2, x + W - 2, y + RH - 2, 0xFF7A1D1D);
            g.drawCenteredString(font, "X", x + W - 9, y + 4, 0xFFFFFFFF);
            y += RH + GAP;
        }
        if (list.isEmpty()) g.drawCenteredString(font, "No servers yet. Type the IP and the command below, then press Add / Save.", width / 2, TOP + 6, 0xFF888888);
        super.render(g, mx, my, delta);
        g.drawCenteredString(font, "Delay: " + (int) m.get("delay") + " ticks", x + 160, height - 28, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        int x = (width - W) / 2;
        if (ev.x() >= x && ev.x() < x + W && ev.y() >= TOP && ev.y() < TOP + visibleRows() * (RH + GAP)) {
            int idx = scroll + (int) ((ev.y() - TOP) / (RH + GAP));
            List<Map.Entry<String, String>> list = rows();
            if (idx >= 0 && idx < list.size()) {
                var e = list.get(idx);
                if (ev.x() >= x + W - 16) { m.servers.remove(e.getKey()); Config.save(); }
                else { ipBox.setValue(e.getKey()); cmdBox.setValue(e.getValue()); }
                return true;
            }
        }
        return super.mouseClicked(ev, dbl);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll -= (int) Math.signum(verticalAmount);
        return true;
    }
}
