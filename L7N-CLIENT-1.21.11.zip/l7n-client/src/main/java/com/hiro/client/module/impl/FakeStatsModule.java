package com.hiro.client.module.impl;

import com.hiro.client.module.Module;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.PlayerScoreEntry;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.Scoreboard;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Client-side only. Everything you SEE (chat, sidebar scoreboard, tab list) shows the fake name
 * and fake money / playtime / kills instead of the real ones. The server and other players are not affected.
 */
public class FakeStatsModule extends Module {
    public static final String FAKE_NAME = "HIRO IN TOP";
    private static final String FAKE_MONEY = "$999,999,999";
    private static final String FAKE_TIME = "999h 59m";
    private static final String FAKE_COUNT = "999";
    private static final String SEP = "(\\s*[:»>|\\-]?\\s*)";
    private static final String MONEY_K = "(money|balance|bal|coins|cash|shards|tokens|credits)";
    private static final String TIME_K = "(playtime|play time|time played|online time|played)";
    private static final String COUNT_K = "(kills|deaths|killstreak|streak)";
    private static final Pattern MONEY = Pattern.compile("(?i)" + MONEY_K + SEP + "[$€£]?\\d[\\d,.]*[kKmMbBtT]?");
    private static final Pattern TIME = Pattern.compile("(?i)" + TIME_K + SEP + "(\\d+\\s*[dhms](\\s*\\d+\\s*[dhms])*|\\d+(:\\d+)+)");
    private static final Pattern COUNT = Pattern.compile("(?i)" + COUNT_K + SEP + "\\d[\\d,.]*");
    private static final Pattern TAIL = Pattern.compile("(?i)(" + "money|balance|bal|coins|cash|shards|tokens|credits|playtime|play time|time played|online time|played|kills|deaths|killstreak|streak" + ")" + SEP + "$");

    private static FakeStatsModule self;
    private static boolean hooked;
    private String cachedName = "";
    private Pattern namePattern;

    public FakeStatsModule() {
        super("FakeStats", "Hides your name, money, playtime and stats on your screen and shows fake ones (name: HIRO IN TOP)", Category.MISC);
        addToggle("name", true); addToggle("stats", true);
        addToggle("chat", true); addToggle("scoreboard", true); addToggle("tab", true);
        self = this;
        if (!hooked) {
            hooked = true;
            ClientReceiveMessageEvents.MODIFY_GAME.register((msg, overlay) ->
                    self != null && self.isEnabled() && self.on("chat") ? self.rewrite(msg) : msg);
        }
    }

    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) return;
        PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        if (pi != null) pi.setTabListDisplayName(null);
    }

    private String mask(String s) {
        if (s == null || s.isEmpty()) return s;
        if (on("name")) {
            String n = Minecraft.getInstance().getUser().getName();
            if (n != null && !n.isEmpty()) {
                if (!n.equals(cachedName)) { cachedName = n; namePattern = Pattern.compile(Pattern.quote(n), Pattern.CASE_INSENSITIVE); }
                s = namePattern.matcher(s).replaceAll(Matcher.quoteReplacement(FAKE_NAME));
            }
        }
        if (on("stats")) {
            s = MONEY.matcher(s).replaceAll(r -> Matcher.quoteReplacement(r.group(1) + r.group(2) + FAKE_MONEY));
            s = TIME.matcher(s).replaceAll(r -> Matcher.quoteReplacement(r.group(1) + r.group(2) + FAKE_TIME));
            s = COUNT.matcher(s).replaceAll(r -> Matcher.quoteReplacement(r.group(1) + r.group(2) + FAKE_COUNT));
        }
        return s;
    }

    /** Returns the same object when nothing had to change. */
    private Component rewrite(Component c) {
        if (c == null) return null;
        String full = c.getString();
        if (mask(full).equals(full)) return c;
        MutableComponent out = Component.empty();
        c.visit((style, text) -> {
            if (!text.isEmpty()) out.append(Component.literal(mask(text)).withStyle(style));
            return Optional.empty();
        }, Style.EMPTY);
        return out;
    }

    /** Fake value for a scoreboard line whose label (team prefix) ends with a stat name, e.g. "Money: ". */
    private String fakeFor(String label) {
        Matcher m = TAIL.matcher(label);
        if (!m.find()) return null;
        String k = m.group(1).toLowerCase();
        if (k.matches(MONEY_K)) return FAKE_MONEY;
        if (k.matches(TIME_K)) return FAKE_TIME;
        return FAKE_COUNT;
    }

    @Override public void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        if (on("scoreboard")) scoreboard(mc);
        if (on("tab") && on("name")) tab(mc);
    }

    private void scoreboard(Minecraft mc) {
        Scoreboard sb = mc.level.getScoreboard();
        for (PlayerTeam t : sb.getPlayerTeams()) {
            Component p = t.getPlayerPrefix(), s = t.getPlayerSuffix();
            Component np = rewrite(p), ns = rewrite(s);
            if (on("stats")) {
                String fake = fakeFor(p.getString());
                if (fake != null && !s.getString().equals(fake)) ns = Component.literal(fake).withStyle(s.getStyle());
            }
            if (np != p) t.setPlayerPrefix(np);
            if (ns != s) t.setPlayerSuffix(ns);
        }
        Objective o = sb.getDisplayObjective(DisplaySlot.SIDEBAR);
        if (o == null) return;
        Component dn = o.getDisplayName(), nd = rewrite(dn);
        if (nd != dn) o.setDisplayName(nd);
        for (PlayerScoreEntry e : sb.listPlayerScores(o)) {
            Component cur = e.ownerName(), nw = rewrite(cur);
            if (nw != cur) sb.getOrCreatePlayerScore(ScoreHolder.forNameOnly(e.owner()), o).display(nw);
        }
    }

    private void tab(Minecraft mc) {
        if (mc.getConnection() == null) return;
        PlayerInfo pi = mc.getConnection().getPlayerInfo(mc.player.getUUID());
        if (pi == null) return;
        Component cur = pi.getTabListDisplayName();
        Component want = cur == null ? Component.literal(FAKE_NAME) : rewrite(cur);
        if (want != cur) pi.setTabListDisplayName(want);
    }
}
