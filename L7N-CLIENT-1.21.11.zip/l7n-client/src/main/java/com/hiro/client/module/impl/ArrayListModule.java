package com.hiro.client.module.impl;
import com.hiro.client.module.Module;
public class ArrayListModule extends Module {
    public ArrayListModule() { super("ArrayList", "Show enabled modules", Category.RENDER); }
}
