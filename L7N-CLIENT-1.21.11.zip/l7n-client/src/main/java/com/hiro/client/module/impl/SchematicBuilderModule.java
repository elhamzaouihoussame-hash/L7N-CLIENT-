package com.hiro.client.module.impl;

import com.hiro.client.CommandManager;
import com.hiro.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Builds a structure from a .schem (WorldEdit/Sponge) or .nbt (vanilla structure block) file placed in
 * config/hiro-client/schematics/. Pick the file from the "Build" tab in the Commands menu, stand where you
 * want its corner, then enable this module. It walks to each missing block and places it from your inventory.
 */
public class SchematicBuilderModule extends Module {
    private SchematicFile file;
    private BlockPos origin;
    private List<SchematicFile.Entry> remaining;
    private int cd;
    private String missing;

    public SchematicBuilderModule() {
        super("SchematicBuilder", "Builds a .schem/.nbt file from the schematics folder", Category.MISC);
        addSetting("reach", 4.5, 0.5); addSetting("turn", 20, 1); addToggle("skipmissing", true);
    }

    public static Path folder() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("hiro-client").resolve("schematics");
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }
    public static List<String> list() {
        List<String> l = new ArrayList<>();
        try (var s = Files.list(folder())) {
            s.forEach(p -> { String n = p.getFileName().toString().toLowerCase(); if (n.endsWith(".schem") || n.endsWith(".nbt")) l.add(p.getFileName().toString()); });
        } catch (IOException ignored) {}
        Collections.sort(l);
        return l;
    }

    /** Load a file and anchor it at the player's current feet position. Call this, then enable the module. */
    public boolean select(String fileName, Minecraft mc) {
        try {
            file = SchematicFile.load(folder().resolve(fileName));
            origin = mc.player.blockPosition();
            remaining = new ArrayList<>(file.blocks);
            missing = null;
            CommandManager.info("Loaded " + fileName + " (" + file.sx + "x" + file.sy + "x" + file.sz + ", " + remaining.size() + " blocks). Anchored at " + origin.getX() + " " + origin.getY() + " " + origin.getZ());
            return true;
        } catch (Exception e) {
            CommandManager.info("Could not read " + fileName + ": " + e.getMessage());
            file = null;
            return false;
        }
    }
    public String loadedName() { return file == null ? null : file.name; }
    public int remainingCount() { return remaining == null ? 0 : remaining.size(); }

    @Override protected void onDisable() {}

    private static BlockState applyProps(BlockState st, Map<String, String> props) {
        for (var e : props.entrySet()) {
            Property<?> p = st.getBlock().getStateDefinition().getProperty(e.getKey());
            if (p != null) st = setProp(st, p, e.getValue());
        }
        return st;
    }
    private static <T extends Comparable<T>> BlockState setProp(BlockState st, Property<T> p, String value) {
        return p.getValue(value).map(v -> st.setValue(p, v)).orElse(st);
    }

    @Override public void tick(Minecraft mc) {
        if (file == null || remaining == null) { CommandManager.info("No schematic loaded. Use the Build tab in Commands."); setEnabled(false); return; }
        if (cd > 0) { cd--; return; }
        if (mc.screen != null || mc.gameMode == null || mc.level == null) return;

        // find the nearest block that still needs placing
        SchematicFile.Entry best = null; double bd = Double.MAX_VALUE; BlockPos bestWorld = null;
        for (SchematicFile.Entry e : remaining) {
            BlockPos world = origin.offset(e.pos().getX(), e.pos().getY(), e.pos().getZ());
            if (!mc.level.getBlockState(world).canBeReplaced()) continue; // already built
            double d = mc.player.blockPosition().distSqr(world);
            if (d < bd) { bd = d; best = e; bestWorld = world; }
        }
        if (best == null) { CommandManager.info("Build finished (or everything left is missing materials)."); setEnabled(false); return; }

        Identifier id = Identifier.tryParse(best.blockId());
        Item item = id == null ? null : BuiltInRegistries.ITEM.getOptional(id).orElse(null);
        if (!(item instanceof BlockItem)) {
            remaining.remove(best);
            return;
        }
        int slot = BlockUtil.hotbar(mc, st -> st.getItem() == item);
        if (slot < 0) {
            if (on("skipmissing")) {
                if (!best.blockId().equals(missing)) { missing = best.blockId(); CommandManager.info("Missing in hotbar: " + best.blockId() + " (skipping for now)"); }
                remaining.remove(best);
            } else { CommandManager.info("Need " + best.blockId() + " in the hotbar to continue. Pausing."); setEnabled(false); }
            return;
        }

        Vec3 target = Vec3.atCenterOf(bestWorld);
        double dist = mc.player.getEyePosition().distanceTo(target);
        if (dist > get("reach")) {
            BlockUtil.face(mc, target);
            mc.options.keyUp.setDown(true);
            return;
        }
        mc.options.keyUp.setDown(false);
        BlockUtil.select(mc, slot);
        for (Direction d : Direction.values()) {
            BlockPos n = bestWorld.relative(d);
            if (mc.level.getBlockState(n).canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 hit = new Vec3(n.getX() + 0.5 + face.getStepX() * 0.5, n.getY() + 0.5 + face.getStepY() * 0.5, n.getZ() + 0.5 + face.getStepZ() * 0.5);
            BlockUtil.face(mc, hit);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            mc.player.swing(InteractionHand.MAIN_HAND);
            remaining.remove(best);
            cd = 2;
            return;
        }
        remaining.remove(best); // nothing solid to click on yet (e.g. floating block); try again later as neighbours get built
    }
}
