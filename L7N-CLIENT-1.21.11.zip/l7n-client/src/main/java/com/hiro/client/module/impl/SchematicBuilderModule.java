package com.hiro.client.module.impl;

import com.hiro.client.CommandManager;
import com.hiro.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Litematica/Sponge/vanilla schematic builder with local obstacle routing and best-effort market buying. */
public class SchematicBuilderModule extends Module {
    private enum MarketState { NONE, OPEN_SOURCE, SCAN, REOPEN, BUY, CONFIRM, WAIT_ITEM }
    private static final String[] MARKETS = {"shop", "ah"};
    private static final Pattern PRICE = Pattern.compile("(?i)(?:price|cost|buy)[^0-9$]*\\$?\\s*([0-9][0-9,.]*)\\s*([kmb])?|\\$\\s*([0-9][0-9,.]*)\\s*([kmb])?");
    private SchematicFile file;
    private BlockPos origin;
    private List<SchematicFile.Entry> remaining;
    private int cd, totalBlocks, placedBlocks, blockedTicks;
    private final Set<String> skippedTypes = new LinkedHashSet<>();
    private String missing;

    // Market scan: inspect /shop and /ah before choosing the cheapest visible listing.
    private MarketState marketState = MarketState.NONE;
    private Item wantedItem;
    private String wantedId, bestSource;
    private double bestPrice = Double.MAX_VALUE;
    private int sourceIndex, pageIndex, bestPage, bestSlot, marketTicks;

    public SchematicBuilderModule() {
        super("AutoBuilder", "Builds schematics, routes around obstacles and can buy missing blocks", Category.MISC);
        addSetting("reach", 4.5, 0.5);
        addSetting("delay", 2, 1);
        addToggle("skipmissing", true);
        addToggle("autobuy", true);
    }

    public static Path folder() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("hiro-client").resolve("schematics");
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }
    public static List<String> list() {
        List<String> l = new ArrayList<>();
        try (var s = Files.list(folder())) {
            s.forEach(p -> { String n = p.getFileName().toString().toLowerCase(); if (n.endsWith(".litematic") || n.endsWith(".schem") || n.endsWith(".nbt")) l.add(p.getFileName().toString()); });
        } catch (IOException ignored) {}
        Collections.sort(l);
        return l;
    }

    public boolean select(String fileName, Minecraft mc) {
        try {
            if (mc.player == null) { CommandManager.info("Join a world before selecting a schematic."); return false; }
            file = SchematicFile.load(folder().resolve(fileName));
            origin = mc.player.blockPosition();
            remaining = new ArrayList<>(file.blocks);
            totalBlocks = remaining.size(); placedBlocks = 0; blockedTicks = 0;
            skippedTypes.clear(); missing = null; cd = 0; resetMarket();
            CommandManager.info("Loaded " + fileName + " (" + file.sx + "x" + file.sy + "x" + file.sz + ", " + remaining.size() + " blocks). Anchored at " + origin.getX() + " " + origin.getY() + " " + origin.getZ());
            return true;
        } catch (Exception e) {
            CommandManager.info("Could not read " + fileName + ": " + e.getMessage()); file = null; return false;
        }
    }
    public String loadedName() { return file == null ? null : file.name; }
    public int remainingCount() { return remaining == null ? 0 : remaining.size(); }
    public int totalCount() { return totalBlocks; }
    public String progressText() { return remaining == null ? "not loaded" : placedBlocks + "/" + totalBlocks + " placed"; }

    @Override protected void onDisable() { release(Minecraft.getInstance()); resetMarket(); }
    private void release(Minecraft mc) {
        if (mc.options == null) return;
        mc.options.keyUp.setDown(false); mc.options.keyJump.setDown(false);
    }
    private void resetMarket() {
        marketState = MarketState.NONE; wantedItem = null; wantedId = null; bestSource = null;
        bestPrice = Double.MAX_VALUE; sourceIndex = pageIndex = bestPage = bestSlot = marketTicks = 0;
    }

    private static BlockState applyProps(BlockState st, Map<String, String> props) {
        for (var e : props.entrySet()) {
            var p = st.getBlock().getStateDefinition().getProperty(e.getKey());
            if (p != null) st = setProp(st, p, e.getValue());
        }
        return st;
    }
    private static <T extends Comparable<T>> BlockState setProp(BlockState st, net.minecraft.world.level.block.state.properties.Property<T> p, String value) {
        return p.getValue(value).map(v -> st.setValue(p, v)).orElse(st);
    }

    @Override public void tick(Minecraft mc) {
        if (file == null || remaining == null) { CommandManager.info("No schematic loaded. Use the Build tab in Commands."); setEnabled(false); return; }
        if (mc.player == null || mc.options == null || mc.level == null || mc.gameMode == null) return;
        if (marketState != MarketState.NONE) { tickMarket(mc); return; }
        if (cd > 0) { cd--; return; }
        if (mc.screen != null) { release(mc); return; }

        SchematicFile.Entry best = null, fallback = null;
        double bd = Double.MAX_VALUE, fallbackDistance = Double.MAX_VALUE;
        BlockPos bestWorld = null, fallbackWorld = null;
        Iterator<SchematicFile.Entry> it = remaining.iterator();
        while (it.hasNext()) {
            SchematicFile.Entry e = it.next();
            BlockPos world = origin.offset(e.pos().getX(), e.pos().getY(), e.pos().getZ());
            if (!mc.level.getBlockState(world).canBeReplaced()) { it.remove(); continue; }
            double d = mc.player.blockPosition().distSqr(world);
            if (d < fallbackDistance) { fallbackDistance = d; fallback = e; fallbackWorld = world; }
            boolean supported = false;
            for (Direction direction : Direction.values()) if (!mc.level.getBlockState(world.relative(direction)).canBeReplaced()) { supported = true; break; }
            if (supported && d < bd) { bd = d; best = e; bestWorld = world; }
        }
        if (best == null) { best = fallback; bestWorld = fallbackWorld; }
        if (best == null) {
            release(mc);
            String detail = skippedTypes.isEmpty() ? "" : " Skipped/missing: " + String.join(", ", skippedTypes);
            CommandManager.info("AutoBuilder finished. " + placedBlocks + "/" + totalBlocks + " placed." + detail);
            setEnabled(false); return;
        }

        Identifier id = Identifier.tryParse(best.blockId());
        Item item = id == null ? null : BuiltInRegistries.ITEM.getOptional(id).orElse(null);
        if (!(item instanceof BlockItem)) { skippedTypes.add(best.blockId()); remaining.remove(best); return; }
        int slot = BlockUtil.hotbar(mc, st -> st.getItem() == item);
        if (slot < 0) {
            if (on("autobuy") && (missing == null || !missing.equals(best.blockId()))) { beginMarket(item, best.blockId(), mc); return; }
            if (on("skipmissing")) {
                if (!best.blockId().equals(missing)) { missing = best.blockId(); CommandManager.info("Missing block: " + best.blockId() + "; skipped because AutoBuy is unavailable/disabled."); }
                skippedTypes.add(best.blockId()); remaining.remove(best); return;
            }
            CommandManager.info("Need " + best.blockId() + " in inventory. Pausing."); setEnabled(false); return;
        }
        missing = null;
        Vec3 target = Vec3.atCenterOf(bestWorld);
        double dist = mc.player.getEyePosition().distanceTo(target);
        if (dist > get("reach")) {
            if (!walkAroundObstacles(mc, bestWorld)) {
                release(mc); blockedTicks++;
                if (blockedTicks > 100) { CommandManager.info("AutoBuilder: no safe path to " + bestWorld + ". Skipping this block."); skippedTypes.add(best.blockId()); remaining.remove(best); blockedTicks = 0; }
            } else blockedTicks = 0;
            return;
        }
        blockedTicks = 0; release(mc); BlockUtil.select(mc, slot);
        for (Direction d : Direction.values()) {
            BlockPos n = bestWorld.relative(d);
            if (mc.level.getBlockState(n).canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 hit = new Vec3(n.getX() + 0.5 + face.getStepX() * 0.5, n.getY() + 0.5 + face.getStepY() * 0.5, n.getZ() + 0.5 + face.getStepZ() * 0.5);
            BlockUtil.face(mc, hit);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
            mc.player.swing(InteractionHand.MAIN_HAND); remaining.remove(best); placedBlocks++;
            cd = Math.max(1, (int) get("delay")); return;
        }
        remaining.remove(best); remaining.add(best); cd = 1;
    }

    // Breadth-first local navigation: walk around solid blocks, step up/down one block, and reject drops/lava.
    private boolean walkAroundObstacles(Minecraft mc, BlockPos target) {
        BlockPos start = mc.player.blockPosition();
        ArrayDeque<BlockPos> q = new ArrayDeque<>();
        Map<BlockPos, BlockPos> parent = new HashMap<>();
        q.add(start); parent.put(start, start);
        BlockPos goal = null; int visited = 0;
        while (!q.isEmpty() && visited++ < 1800) {
            BlockPos p = q.removeFirst();
            if (mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(target)) <= get("reach") && p.equals(start)) { goal = p; break; }
            if (Vec3.atCenterOf(p).distanceTo(Vec3.atCenterOf(target)) <= Math.max(1.0, get("reach") - 1.0)) { goal = p; break; }
            if (Math.abs(p.getX() - start.getX()) > 18 || Math.abs(p.getZ() - start.getZ()) > 18 || Math.abs(p.getY() - start.getY()) > 4) continue;
            for (Direction dir : List.of(Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST)) {
                for (int dy : new int[]{0, 1, -1}) {
                    BlockPos n = p.relative(dir).offset(0, dy, 0);
                    if (parent.containsKey(n) || !standable(mc, n)) continue;
                    parent.put(n, p); q.addLast(n);
                }
            }
        }
        if (goal == null) return false;
        if (goal.equals(start)) return true;
        BlockPos step = goal;
        while (!parent.get(step).equals(start) && !step.equals(start)) step = parent.get(step);
        Vec3 waypoint = new Vec3(step.getX() + 0.5, step.getY(), step.getZ() + 0.5);
        BlockUtil.face(mc, waypoint);
        mc.options.keyUp.setDown(true);
        mc.options.keyJump.setDown(step.getY() > start.getY() || mc.player.horizontalCollision);
        return true;
    }
    private boolean standable(Minecraft mc, BlockPos feet) {
        BlockState f = mc.level.getBlockState(feet), h = mc.level.getBlockState(feet.above()), floor = mc.level.getBlockState(feet.below());
        if (!f.getCollisionShape(mc.level, feet).isEmpty() || !h.getCollisionShape(mc.level, feet.above()).isEmpty()) return false;
        if (floor.getCollisionShape(mc.level, feet.below()).isEmpty()) return false;
        return mc.level.getFluidState(feet).isEmpty() && mc.level.getFluidState(feet.above()).isEmpty();
    }

    private void beginMarket(Item item, String id, Minecraft mc) {
        wantedItem = item; wantedId = id; sourceIndex = 0; pageIndex = 0; bestPrice = Double.MAX_VALUE; bestSource = null; bestPage = 0; bestSlot = -1;
        marketState = MarketState.OPEN_SOURCE; marketTicks = 0;
        CommandManager.info("AutoBuilder: searching cheapest " + id + " in /shop and /ah...");
        openCurrentMarket(mc);
    }
    private void openCurrentMarket(Minecraft mc) {
        if (mc.screen instanceof AbstractContainerScreen<?> && mc.player != null) mc.player.closeContainer();
        mc.player.connection.sendCommand(MARKETS[sourceIndex]); marketState = MarketState.OPEN_SOURCE; marketTicks = 0;
    }
    private static double readPrice(ItemStack stack) {
        var lore = stack.get(DataComponents.LORE); if (lore == null) return Double.MAX_VALUE;
        for (Component c : lore.lines()) {
            Matcher m = PRICE.matcher(c.getString()); if (!m.find()) continue;
            String num = m.group(1) != null ? m.group(1) : m.group(3), suf = m.group(1) != null ? m.group(2) : m.group(4);
            try { double v = Double.parseDouble(num.replace(",", "")); if (suf != null) v *= switch (suf.toLowerCase()) { case "k" -> 1e3; case "m" -> 1e6; default -> 1e9; }; return v; }
            catch (NumberFormatException ignored) {}
        }
        return Double.MAX_VALUE;
    }
    private void menuClick(Minecraft mc, Slot slot) {
        mc.gameMode.handleInventoryMouseClick(mc.player.containerMenu.containerId, slot.index, 0, ClickType.PICKUP, mc.player);
    }
    private void tickMarket(Minecraft mc) {
        marketTicks++;
        if (mc.player == null || mc.gameMode == null) { resetMarket(); return; }
        switch (marketState) {
            case OPEN_SOURCE -> {
                if (mc.screen instanceof AbstractContainerScreen<?>) { marketState = MarketState.SCAN; marketTicks = 0; }
                else if (marketTicks > 80) nextMarket(mc);
            }
            case SCAN -> {
                if (!(mc.screen instanceof AbstractContainerScreen<?> cs)) { nextMarket(mc); return; }
                if (marketTicks < 10) return;
                var menu = cs.getMenu(); Slot next = null;
                for (Slot s : menu.slots) {
                    if (s.container == mc.player.getInventory()) continue;
                    ItemStack stack = s.getItem(); if (stack.isEmpty()) continue;
                    if (stack.getItem() == wantedItem) {
                        double price = readPrice(stack);
                        if (price < bestPrice) { bestPrice = price; bestSource = MARKETS[sourceIndex]; bestPage = pageIndex; bestSlot = s.index; }
                    }
                    String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
                    if (next == null && (name.contains("next") || name.contains("»") || name.contains("→"))) next = s;
                }
                if (next != null && pageIndex < 8) { pageIndex++; menuClick(mc, next); marketTicks = 0; }
                else nextMarket(mc);
            }
            case REOPEN -> {
                if (mc.screen instanceof AbstractContainerScreen<?>) { marketState = MarketState.BUY; marketTicks = 0; }
                else if (marketTicks > 80) finishMarketSearch(mc);
            }
            case BUY -> {
                if (!(mc.screen instanceof AbstractContainerScreen<?> cs)) { finishMarketSearch(mc); return; }
                if (marketTicks < 10) return;
                var menu = cs.getMenu(); Slot offer = null;
                for (Slot s : menu.slots) {
                    if (s.container == mc.player.getInventory()) continue;
                    ItemStack stack = s.getItem(); if (stack.isEmpty()) continue;
                    if (stack.getItem() == wantedItem && readPrice(stack) == bestPrice) { offer = s; break; }
                }
                if (offer != null) { menuClick(mc, offer); marketState = MarketState.CONFIRM; marketTicks = 0; }
                else if (pageIndex < bestPage) {
                    Slot next = findNext(cs); if (next != null) { pageIndex++; menuClick(mc, next); marketTicks = 0; } else finishMarketSearch(mc);
                } else finishMarketSearch(mc);
            }
            case CONFIRM -> {
                if (!(mc.screen instanceof AbstractContainerScreen<?> cs)) { marketState = MarketState.WAIT_ITEM; marketTicks = 0; return; }
                if (marketTicks < 6) return;
                for (Slot s : cs.getMenu().slots) {
                    if (s.container == mc.player.getInventory()) continue;
                    ItemStack stack = s.getItem(); if (stack.isEmpty()) continue;
                    String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
                    if (name.contains("confirm") || name.contains("purchase") || name.contains("accept") || name.equals("buy") || name.equals("yes")) {
                        menuClick(mc, s); marketState = MarketState.WAIT_ITEM; marketTicks = 0; return;
                    }
                }
                if (marketTicks > 35) { marketState = MarketState.WAIT_ITEM; marketTicks = 0; }
            }
            case WAIT_ITEM -> {
                if (hasWantedItem(mc)) {
                    if (mc.screen instanceof AbstractContainerScreen<?>) mc.player.closeContainer();
                    CommandManager.info("AutoBuilder bought " + wantedId + " from " + bestSource + " for " + (bestPrice == Double.MAX_VALUE ? "unknown price" : bestPrice) + ". Resuming build.");
                    missing = null; resetMarket();
                } else if (marketTicks > 80) {
                    if (mc.screen instanceof AbstractContainerScreen<?>) mc.player.closeContainer();
                    CommandManager.info("AutoBuilder could not verify purchase of " + wantedId + ". Check the server shop format/balance.");
                    missing = wantedId; resetMarket();
                }
            }
            case NONE -> {}
        }
    }
    private Slot findNext(AbstractContainerScreen<?> cs) {
        for (Slot s : cs.getMenu().slots) {
            if (s.container == Minecraft.getInstance().player.getInventory()) continue;
            ItemStack stack = s.getItem(); if (stack.isEmpty()) continue;
            String n = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
            if (n.contains("next") || n.contains("»") || n.contains("→")) return s;
        }
        return null;
    }
    private boolean hasWantedItem(Minecraft mc) {
        if (wantedItem == null) return false;
        Inventory inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) if (inv.getItem(i).getItem() == wantedItem) return true;
        return false;
    }
    private void nextMarket(Minecraft mc) {
        if (mc.screen instanceof AbstractContainerScreen<?>) mc.player.closeContainer();
        if (sourceIndex + 1 < MARKETS.length) { sourceIndex++; pageIndex = 0; openCurrentMarket(mc); }
        else finishMarketSearch(mc);
    }
    private void finishMarketSearch(Minecraft mc) {
        if (bestSource == null || bestPrice == Double.MAX_VALUE) {
            if (mc.screen instanceof AbstractContainerScreen<?>) mc.player.closeContainer();
            CommandManager.info("No priced listing for " + wantedId + " found in /shop or /ah. Skipping it.");
            missing = wantedId; resetMarket(); return;
        }
        sourceIndex = bestSource.equals("ah") ? 1 : 0; pageIndex = 0;
        if (mc.screen instanceof AbstractContainerScreen<?>) mc.player.closeContainer();
        mc.player.connection.sendCommand(MARKETS[sourceIndex]); marketState = MarketState.REOPEN; marketTicks = 0;
        CommandManager.info("Cheapest visible listing: " + bestSource + " at " + bestPrice + ". Attempting purchase...");
    }
}
