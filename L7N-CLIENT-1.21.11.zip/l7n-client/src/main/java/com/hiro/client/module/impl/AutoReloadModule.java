package com.hiro.client.module.impl;

import com.hiro.client.CommandManager;
import com.hiro.client.HiroClient;
import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import net.minecraft.network.chat.Component;

/**
 * When the player reaches the configured depth (default Y -3) the client leaves the server and
 * reconnects to the same server after a short delay.
 * The trigger re-arms only after the player has been above the depth again, so rejoining at
 * Y -3 does not cause an endless reconnect loop.
 */
public class AutoReloadModule extends Module {
    private static ServerData server;
    private boolean armed = true;
    private int state; // 0 idle, 1 waiting to reconnect, 2 connecting
    private int timer, tries;

    public AutoReloadModule() {
        super("AutoReload", "Leaves the server and rejoins quickly when you reach the set depth (default Y -3)", Category.MISC);
        addSetting("depth", 3, 1);   // trigger when Y <= -depth
        addSetting("delay", 10, 1);  // ticks to wait before rejoining (20 ticks = 1 second)
        addSetting("retries", 5, 1);
    }

    @Override protected void onDisable() { state = 0; armed = true; }

    @Override public void tick(Minecraft mc) {
        if (mc.getCurrentServer() != null) server = mc.getCurrentServer();
        if (mc.player == null) return;
        if (state != 0) { if (state == 2) state = 0; return; } // joined again
        if (mc.player.getY() > -get("depth")) { armed = true; return; }
        if (!armed || server == null) return;
        var conn = mc.getConnection();
        if (conn == null) return;
        armed = false;
        state = 1;
        tries = 0;
        timer = Math.max(1, (int) get("delay"));
        CommandManager.info("AutoReload: Y " + (int) mc.player.getY() + " reached, reloading...");
        conn.getConnection().disconnect(Component.literal("AutoReload"));
    }

    /** Runs every client tick, also while disconnected (module tick() only runs in a world). */
    public static void pumpAll(Minecraft mc) {
        if (HiroClient.modules == null) return;
        AutoReloadModule m = HiroClient.modules.get(AutoReloadModule.class);
        if (m != null) m.pump(mc);
    }

    private void pump(Minecraft mc) {
        if (state == 0) return;
        if (!isEnabled() || server == null) { state = 0; return; }
        boolean inWorld = mc.level != null && mc.player != null;
        if (state == 1) {
            if (inWorld) return; // disconnect not finished yet
            if (--timer > 0) return;
            connect(mc);
            return;
        }
        if (inWorld) { state = 0; return; }
        if (--timer > 0) return;
        if (++tries > (int) get("retries")) { state = 0; return; }
        connect(mc);
    }

    private void connect(Minecraft mc) {
        state = 2;
        timer = 200; // 10 s before trying again
        ConnectScreen.startConnecting(new TitleScreen(), mc, ServerAddress.parseString(server.ip), server, false, null);
    }
}
