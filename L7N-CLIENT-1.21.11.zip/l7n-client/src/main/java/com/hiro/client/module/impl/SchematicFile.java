package com.hiro.client.module.impl;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/** A parsed build file: a palette of block states plus the position + palette index of every non-air block. */
public final class SchematicFile {
    public record Entry(BlockPos pos, String blockId, Map<String, String> props) {}
    public final int sx, sy, sz;
    public final List<Entry> blocks;
    public final String name;

    private SchematicFile(String name, int sx, int sy, int sz, List<Entry> blocks) {
        this.name = name; this.sx = sx; this.sy = sy; this.sz = sz; this.blocks = blocks;
    }

    public static SchematicFile load(Path path) throws IOException {
        String n = path.getFileName().toString().toLowerCase();
        CompoundTag root = NbtIo.readCompressed(path, NbtAccounter.unlimitedHeap());
        if (n.endsWith(".schem")) return parseSponge(path.getFileName().toString(), root);
        if (n.endsWith(".nbt")) return parseVanilla(path.getFileName().toString(), root);
        throw new IOException("Unsupported file type (use .schem or .nbt): " + n);
    }

    // ---------- vanilla structure block format (.nbt) ----------
    private static SchematicFile parseVanilla(String name, CompoundTag root) {
        ListTag size = root.getList("size");
        int sx = size.getInt(0).orElse(0), sy = size.getInt(1).orElse(0), sz = size.getInt(2).orElse(0);
        ListTag palette = root.getList("palette");
        List<String[]> pal = new ArrayList<>(); // [0]=name, props packed as "k=v,k=v"
        List<Map<String, String>> palProps = new ArrayList<>();
        for (int i = 0; i < palette.size(); i++) {
            CompoundTag e = palette.getCompound(i).orElseGet(CompoundTag::new);
            pal.add(new String[]{e.getString("Name").orElse("")});
            Map<String, String> p = new LinkedHashMap<>();
            if (e.contains("Properties")) {
                CompoundTag props = e.getCompound("Properties").orElseGet(CompoundTag::new);
                for (String k : props.keySet()) p.put(k, props.getString(k).orElse(""));
            }
            palProps.add(p);
        }
        ListTag blocksTag = root.getList("blocks");
        List<Entry> out = new ArrayList<>();
        for (int i = 0; i < blocksTag.size(); i++) {
            CompoundTag b = blocksTag.getCompound(i).orElseGet(CompoundTag::new);
            ListTag pos = b.getList("pos");
            int idx = b.getInt("state").orElse(-1);
            if (idx < 0 || idx >= pal.size()) continue;
            String id = pal.get(idx)[0];
            if (id.equals("minecraft:air") || id.equals("minecraft:structure_void")) continue;
            out.add(new Entry(new BlockPos(pos.getInt(0).orElse(0), pos.getInt(1).orElse(0), pos.getInt(2).orElse(0)), id, palProps.get(idx)));
        }
        return new SchematicFile(name, sx, sy, sz, out);
    }

    // ---------- Sponge schematic format (.schem), versions 1-3 ----------
    private static SchematicFile parseSponge(String name, CompoundTag root) throws IOException {
        CompoundTag data = root.contains("Schematic") ? root.getCompound("Schematic").orElseGet(CompoundTag::new) : root;
        int sx, sy, sz;
        CompoundTag blockContainer;
        if (data.contains("Blocks")) { // v3
            blockContainer = data.getCompound("Blocks").orElseGet(CompoundTag::new);
            sx = data.getShort("Width").orElse((short) 0) & 0xFFFF; sy = data.getShort("Height").orElse((short) 0) & 0xFFFF; sz = data.getShort("Length").orElse((short) 0) & 0xFFFF;
        } else {
            blockContainer = data; // v1/v2: palette/data at top level of this compound
            sx = data.getShort("Width").orElse((short) 0) & 0xFFFF; sy = data.getShort("Height").orElse((short) 0) & 0xFFFF; sz = data.getShort("Length").orElse((short) 0) & 0xFFFF;
        }
        CompoundTag paletteTag = blockContainer.getCompound("Palette").orElseGet(CompoundTag::new);
        int max = paletteTag.keySet().size();
        String[] idToState = new String[Math.max(max, blockContainer.getInt("PaletteMax").orElse(0))];
        for (String key : paletteTag.keySet()) {
            int id = paletteTag.getInt(key).orElse(-1);
            if (id >= idToState.length) idToState = Arrays.copyOf(idToState, id + 1);
            idToState[id] = key;
        }
        byte[] blockData = blockContainer.getByteArray("Data");
        if (blockData.length == 0) blockData = blockContainer.getByteArray("BlockData");
        List<Entry> out = new ArrayList<>();
        int[] off = {0};
        int volume = sx * sy * sz;
        for (int i = 0; i < volume && off[0] < blockData.length; i++) {
            int id = readVarInt(blockData, off);
            if (id < 0 || id >= idToState.length || idToState[id] == null) continue;
            String state = idToState[id];
            if (state.startsWith("minecraft:air") || state.startsWith("minecraft:structure_void")) continue;
            int y = i / (sx * sz), rem = i % (sx * sz), z = rem / sx, x = rem % sx;
            String blockId; Map<String, String> props = new LinkedHashMap<>();
            int br = state.indexOf('[');
            if (br < 0) blockId = state;
            else {
                blockId = state.substring(0, br);
                for (String kv : state.substring(br + 1, state.length() - 1).split(",")) {
                    int eq = kv.indexOf('=');
                    if (eq > 0) props.put(kv.substring(0, eq), kv.substring(eq + 1));
                }
            }
            out.add(new Entry(new BlockPos(x, y, z), blockId, props));
        }
        return new SchematicFile(name, sx, sy, sz, out);
    }

    private static int readVarInt(byte[] data, int[] off) {
        int value = 0, size = 0; byte b;
        do {
            b = data[off[0]++];
            value |= (b & 0x7F) << (size++ * 7);
        } while ((b & 0x80) != 0 && off[0] < data.length);
        return value;
    }
}
