package com.hiro.client.module.impl;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/** Parsed vanilla, Sponge or Litematica schematic data: block positions, IDs and block-state properties. */
public final class SchematicFile {
    public record Entry(BlockPos pos, String blockId, Map<String, String> props) {}
    public final int sx, sy, sz;
    public final List<Entry> blocks;
    public final String name;

    private SchematicFile(String name, int sx, int sy, int sz, List<Entry> blocks) {
        this.name = name; this.sx = sx; this.sy = sy; this.sz = sz; this.blocks = blocks;
    }

    public static SchematicFile load(Path path) throws IOException {
        String n = path.getFileName().toString().toLowerCase();
        CompoundTag root = NbtIo.readCompressed(path, NbtAccounter.unlimitedHeap());
        if (n.endsWith(".schem")) return parseSponge(path.getFileName().toString(), root);
        if (n.endsWith(".litematic")) return parseLitematic(path.getFileName().toString(), root);
        if (n.endsWith(".nbt")) return parseVanilla(path.getFileName().toString(), root);
        throw new IOException("Unsupported file type (use .litematic, .schem or .nbt): " + n);
    }

    // ---------- vanilla structure block format (.nbt) ----------
    private static SchematicFile parseVanilla(String name, CompoundTag root) {
        ListTag size = root.getList("size").orElseGet(ListTag::new);
        int sx = size.getInt(0).orElse(0), sy = size.getInt(1).orElse(0), sz = size.getInt(2).orElse(0);
        ListTag palette = root.getList("palette").orElseGet(ListTag::new);
        List<String[]> pal = new ArrayList<>(); // [0]=name, props packed as "k=v,k=v"
        List<Map<String, String>> palProps = new ArrayList<>();
        for (int i = 0; i < palette.size(); i++) {
            CompoundTag e = palette.getCompound(i).orElseGet(CompoundTag::new);
            pal.add(new String[]{e.getString("Name").orElse("")});
            Map<String, String> p = new LinkedHashMap<>();
            if (e.contains("Properties")) {
                CompoundTag props = e.getCompound("Properties").orElseGet(CompoundTag::new);
                for (String k : props.keySet()) p.put(k, props.getString(k).orElse(""));
            }
            palProps.add(p);
        }
        ListTag blocksTag = root.getList("blocks").orElseGet(ListTag::new);
        List<Entry> out = new ArrayList<>();
        for (int i = 0; i < blocksTag.size(); i++) {
            CompoundTag b = blocksTag.getCompound(i).orElseGet(CompoundTag::new);
            ListTag pos = b.getList("pos").orElseGet(ListTag::new);
            int idx = b.getInt("state").orElse(-1);
            if (idx < 0 || idx >= pal.size()) continue;
            String id = pal.get(idx)[0];
            if (id.equals("minecraft:air") || id.equals("minecraft:structure_void")) continue;
            out.add(new Entry(new BlockPos(pos.getInt(0).orElse(0), pos.getInt(1).orElse(0), pos.getInt(2).orElse(0)), id, palProps.get(idx)));
        }
        return new SchematicFile(name, sx, sy, sz, out);
    }

    // ---------- Sponge schematic format (.schem), versions 1-3 ----------
    private static SchematicFile parseSponge(String name, CompoundTag root) throws IOException {
        CompoundTag data = root.contains("Schematic") ? root.getCompound("Schematic").orElseGet(CompoundTag::new) : root;
        int sx, sy, sz;
        CompoundTag blockContainer;
        if (data.contains("Blocks")) { // v3
            blockContainer = data.getCompound("Blocks").orElseGet(CompoundTag::new);
            sx = data.getShort("Width").orElse((short) 0) & 0xFFFF; sy = data.getShort("Height").orElse((short) 0) & 0xFFFF; sz = data.getShort("Length").orElse((short) 0) & 0xFFFF;
        } else {
            blockContainer = data; // v1/v2: palette/data at top level of this compound
            sx = data.getShort("Width").orElse((short) 0) & 0xFFFF; sy = data.getShort("Height").orElse((short) 0) & 0xFFFF; sz = data.getShort("Length").orElse((short) 0) & 0xFFFF;
        }
        CompoundTag paletteTag = blockContainer.getCompound("Palette").orElseGet(CompoundTag::new);
        int max = paletteTag.keySet().size();
        String[] idToState = new String[Math.max(max, blockContainer.getInt("PaletteMax").orElse(0))];
        for (String key : paletteTag.keySet()) {
            int id = paletteTag.getInt(key).orElse(-1);
            if (id >= idToState.length) idToState = Arrays.copyOf(idToState, id + 1);
            idToState[id] = key;
        }
        byte[] blockData = blockContainer.getByteArray("Data").orElseGet(() -> new byte[0]);
        if (blockData.length == 0) blockData = blockContainer.getByteArray("BlockData").orElseGet(() -> new byte[0]);
        List<Entry> out = new ArrayList<>();
        int[] off = {0};
        int volume = sx * sy * sz;
        for (int i = 0; i < volume && off[0] < blockData.length; i++) {
            int id = readVarInt(blockData, off);
            if (id < 0 || id >= idToState.length || idToState[id] == null) continue;
            String state = idToState[id];
            if (state.startsWith("minecraft:air") || state.startsWith("minecraft:structure_void")) continue;
            int y = i / (sx * sz), rem = i % (sx * sz), z = rem / sx, x = rem % sx;
            String blockId; Map<String, String> props = new LinkedHashMap<>();
            int br = state.indexOf('[');
            if (br < 0) blockId = state;
            else {
                blockId = state.substring(0, br);
                for (String kv : state.substring(br + 1, state.length() - 1).split(",")) {
                    int eq = kv.indexOf('=');
                    if (eq > 0) props.put(kv.substring(0, eq), kv.substring(eq + 1));
                }
            }
            out.add(new Entry(new BlockPos(x, y, z), blockId, props));
        }
        return new SchematicFile(name, sx, sy, sz, out);
    }


    // ---------- Litematica format (.litematic) ----------
    private record RawBlock(BlockPos absolute, String id, Map<String, String> props) {}

    private static SchematicFile parseLitematic(String name, CompoundTag root) throws IOException {
        CompoundTag regions = root.getCompound("Regions").orElseGet(CompoundTag::new);
        if (regions.isEmpty()) throw new IOException("Litematic file has no regions");
        List<RawBlock> raw = new ArrayList<>();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;

        for (String regionName : regions.keySet()) {
            CompoundTag region = regions.getCompound(regionName).orElseGet(CompoundTag::new);
            CompoundTag pos = region.getCompound("Position").orElseGet(CompoundTag::new);
            CompoundTag size = region.getCompound("Size").orElseGet(CompoundTag::new);
            int ox = pos.getInt("x").orElse(0), oy = pos.getInt("y").orElse(0), oz = pos.getInt("z").orElse(0);
            int sxSigned = size.getInt("x").orElse(0), sySigned = size.getInt("y").orElse(0), szSigned = size.getInt("z").orElse(0);
            int sx = Math.abs(sxSigned), sy = Math.abs(sySigned), sz = Math.abs(szSigned);
            if (sx == 0 || sy == 0 || sz == 0) continue;
            long volumeLong = (long) sx * sy * sz;
            if (volumeLong > 8_000_000L) throw new IOException("Litematic region is too large: " + regionName);

            ListTag palette = region.getList("BlockStatePalette").orElseGet(ListTag::new);
            if (palette.isEmpty()) continue;
            String[] ids = new String[palette.size()];
            @SuppressWarnings("unchecked") Map<String, String>[] props = new Map[palette.size()];
            for (int i = 0; i < palette.size(); i++) {
                CompoundTag entry = palette.getCompound(i).orElseGet(CompoundTag::new);
                ids[i] = entry.getString("Name").orElse("minecraft:air");
                Map<String, String> stateProps = new LinkedHashMap<>();
                CompoundTag propTag = entry.getCompound("Properties").orElseGet(CompoundTag::new);
                for (String key : propTag.keySet()) stateProps.put(key, propTag.getString(key).orElse(""));
                props[i] = stateProps;
            }
            long[] states = region.getLongArray("BlockStates").orElseGet(() -> new long[0]);
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(palette.size() - 1));
            int perLong = 64 / bits;
            long mask = (1L << bits) - 1L;
            int volume = (int) volumeLong;
            for (int index = 0; index < volume; index++) {
                int word = index / perLong;
                if (word >= states.length) break;
                int shift = (index % perLong) * bits;
                int paletteIndex = (int) ((states[word] >>> shift) & mask);
                if (paletteIndex < 0 || paletteIndex >= ids.length) continue;
                String blockId = ids[paletteIndex];
                if (blockId == null || blockId.equals("minecraft:air") || blockId.equals("minecraft:cave_air") || blockId.equals("minecraft:void_air") || blockId.equals("minecraft:structure_void")) continue;
                int y = index / (sx * sz);
                int rem = index % (sx * sz);
                int z = rem / sx;
                int x = rem % sx;
                int ax = ox + (sxSigned < 0 ? -x : x);
                int ay = oy + (sySigned < 0 ? -y : y);
                int az = oz + (szSigned < 0 ? -z : z);
                raw.add(new RawBlock(new BlockPos(ax, ay, az), blockId, props[paletteIndex]));
                minX = Math.min(minX, ax); minY = Math.min(minY, ay); minZ = Math.min(minZ, az);
                maxX = Math.max(maxX, ax); maxY = Math.max(maxY, ay); maxZ = Math.max(maxZ, az);
            }
        }
        if (raw.isEmpty()) throw new IOException("Litematic contains no placeable blocks");
        List<Entry> out = new ArrayList<>(raw.size());
        for (RawBlock b : raw) out.add(new Entry(new BlockPos(b.absolute().getX() - minX, b.absolute().getY() - minY, b.absolute().getZ() - minZ), b.id(), b.props()));
        return new SchematicFile(name, maxX - minX + 1, maxY - minY + 1, maxZ - minZ + 1, out);
    }

    private static int readVarInt(byte[] data, int[] off) {
        int value = 0, size = 0; byte b;
        do {
            b = data[off[0]++];
            value |= (b & 0x7F) << (size++ * 7);
        } while ((b & 0x80) != 0 && off[0] < data.length);
        return value;
    }
}
