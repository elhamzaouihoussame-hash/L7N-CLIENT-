package com.hiro.client.module.impl;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.*;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/** A parsed build file: a palette of block states plus the position + palette index of every non-air block. */
public final class SchematicFile {
    public record Entry(BlockPos pos, String blockId, Map<String, String> props) {}
    public final int sx, sy, sz;
    public final List<Entry> blocks;
    public final String name;

    private SchematicFile(String name, int sx, int sy, int sz, List<Entry> blocks) {
        this.name = name; this.sx = sx; this.sy = sy; this.sz = sz; this.blocks = blocks;
    }

    public static SchematicFile load(Path path) throws IOException {
        String n = path.getFileName().toString().toLowerCase();
        CompoundTag root = NbtIo.readCompressed(path, NbtAccounter.unlimitedHeap());
        if (n.endsWith(".schem")) return parseSponge(path.getFileName().toString(), root);
        if (n.endsWith(".nbt")) return parseVanilla(path.getFileName().toString(), root);
        throw new IOException("Unsupported file type (use .schem or .nbt): " + n);
    }

    // ---------- vanilla structure block format (.nbt) ----------
    private static SchematicFile parseVanilla(String name, CompoundTag root) {
        ListTag size = root.getListOrEmpty("size");
        int sx = size.getIntOr(0, 0), sy = size.getIntOr(1, 0), sz = size.getIntOr(2, 0);
        ListTag palette = root.getListOrEmpty("palette");
        List<String> pal = new ArrayList<>();
        List<Map<String, String>> palProps = new ArrayList<>();
        for (int i = 0; i < palette.size(); i++) {
            CompoundTag e = palette.getCompoundOrEmpty(i);
            pal.add(e.getStringOr("Name", "minecraft:air"));
            Map<String, String> p = new LinkedHashMap<>();
            CompoundTag props = e.getCompoundOrEmpty("Properties");
            for (String k : props.keySet()) p.put(k, props.getStringOr(k, ""));
            palProps.add(p);
        }
        ListTag blocksTag = root.getListOrEmpty("blocks");
        List<Entry> out = new ArrayList<>();
        for (int i = 0; i < blocksTag.size(); i++) {
            CompoundTag b = blocksTag.getCompoundOrEmpty(i);
            ListTag pos = b.getListOrEmpty("pos");
            int idx = b.getIntOr("state", -1);
            if (idx < 0 || idx >= pal.size()) continue;
            String id = pal.get(idx);
            if (id.equals("minecraft:air") || id.equals("minecraft:structure_void")) continue;
            out.add(new Entry(new BlockPos(pos.getIntOr(0, 0), pos.getIntOr(1, 0), pos.getIntOr(2, 0)), id, palProps.get(idx)));
        }
        return new SchematicFile(name, sx, sy, sz, out);
    }

    // ---------- Sponge schematic format (.schem), versions 1-3 ----------
    private static SchematicFile parseSponge(String name, CompoundTag root) {
        CompoundTag data = root.getCompoundOrEmpty("Schematic");
        if (data.isEmpty()) data = root;
        int sx = data.getShortOr("Width", (short) 0) & 0xFFFF;
        int sy = data.getShortOr("Height", (short) 0) & 0xFFFF;
        int sz = data.getShortOr("Length", (short) 0) & 0xFFFF;
        CompoundTag blockContainer = data.getCompoundOrEmpty("Blocks");
        if (blockContainer.isEmpty()) blockContainer = data; // v1/v2: palette/data at the top level

        CompoundTag paletteTag = blockContainer.getCompoundOrEmpty("Palette");
        int max = Math.max(paletteTag.keySet().size(), blockContainer.getIntOr("PaletteMax", 0));
        String[] idToState = new String[Math.max(max, 1)];
        for (String key : paletteTag.keySet()) {
            int id = paletteTag.getIntOr(key, -1);
            if (id < 0) continue;
            if (id >= idToState.length) idToState = Arrays.copyOf(idToState, id + 1);
            idToState[id] = key;
        }
        byte[] blockData = blockContainer.getByteArray("Data").orElse(null);
        if (blockData == null) blockData = blockContainer.getByteArray("BlockData").orElse(new byte[0]);

        List<Entry> out = new ArrayList<>();
        int[] off = {0};
        int volume = sx * sy * sz;
        for (int i = 0; i < volume && off[0] < blockData.length; i++) {
            int id = readVarInt(blockData, off);
            if (id < 0 || id >= idToState.length || idToState[id] == null) continue;
            String state = idToState[id];
            if (state.startsWith("minecraft:air") || state.startsWith("minecraft:structure_void")) continue;
            int y = i / (sx * sz), rem = i % (sx * sz), z = rem / sx, x = rem % sx;
            String blockId; Map<String, String> props = new LinkedHashMap<>();
            int br = state.indexOf('[');
            if (br < 0) blockId = state;
            else {
                blockId = state.substring(0, br);
                for (String kv : state.substring(br + 1, state.length() - 1).split(",")) {
                    int eq = kv.indexOf('=');
                    if (eq > 0) props.put(kv.substring(0, eq), kv.substring(eq + 1));
                }
            }
            out.add(new Entry(new BlockPos(x, y, z), blockId, props));
        }
        return new SchematicFile(name, sx, sy, sz, out);
    }

    private static int readVarInt(byte[] data, int[] off) {
        int value = 0, size = 0; byte b;
        do {
            b = data[off[0]++];
            value |= (b & 0x7F) << (size++ * 7);
        } while ((b & 0x80) != 0 && off[0] < data.length);
        return value;
    }
}
