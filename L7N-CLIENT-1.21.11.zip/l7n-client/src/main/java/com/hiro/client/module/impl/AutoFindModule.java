package com.hiro.client.module.impl;

import com.hiro.client.CommandManager;
import com.hiro.client.HiroClient;
import com.hiro.client.gui.Notifier;
import com.hiro.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Base hunting on autopilot:
 *  1) no pickaxe? it opens /shop then /ah, looks for the cheapest pickaxe, buys it (best effort, servers differ)
 *  2) tunnels straight ahead with the pickaxe while BaseFinder / ChestFinder / BaseBlocks scan the chunks
 *  3) when a base that is still intact is found it saves the coordinates and kicks you with "You find a base"
 */
public class AutoFindModule extends Module {
    private enum St { CHECK, OPEN, SCAN, CONFIRM, WAIT, SEARCH }
    private static final String[] CMDS = {"shop", "ah"};
    private static final Pattern PRICE = Pattern.compile(
            "(?i)(?:price|cost|buy)[^0-9$]*\\$?\\s*([0-9][0-9,.]*)\\s*([kmb])?|\\$\\s*([0-9][0-9,.]*)\\s*([kmb])?");
    private St st = St.CHECK;
    private int t, attempt, pages, navs;
    private float lockYaw;

    public AutoFindModule() {
        super("AutoFind", "Buys a pickaxe if needed, tunnels to find bases, kicks you when it finds one", Category.MISC);
        addSetting("minhealth", 10, 1);
        addToggle("buy", true); addToggle("intact", true); addToggle("kick", true);
    }

    static boolean isPickaxe(ItemStack s) {
        return !s.isEmpty() && BuiltInRegistries.ITEM.getKey(s.getItem()).getPath().endsWith("_pickaxe");
    }
    private boolean hasPickaxe(Minecraft mc) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) if (isPickaxe(inv.getItem(i))) return true;
        return isPickaxe(mc.player.getOffhandItem());
    }

    private void release(Minecraft mc) {
        mc.options.keyAttack.setDown(false);
        mc.options.keyUp.setDown(false);
    }
    private void stop(Minecraft mc, String why) {
        release(mc);
        CommandManager.info("§cAutoFind stopped: " + why);
        Notifier.push("AUTOFIND STOPPED", why);
        setEnabled(false);
    }

    @Override protected void onEnable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        lockYaw = Math.round(mc.player.getYRot() / 90f) * 90f;
        st = St.CHECK; t = 0; attempt = 0; pages = 0; navs = 0;
        for (var c : List.of(WorldModules.BaseFinder.class, WorldModules.ChestFinder.class, WorldModules.BaseBlocks.class)) {
            FinderModule fm = HiroClient.modules.get(c);
            if (fm != null) fm.setEnabled(true);
        }
        CommandManager.info("AutoFind started, digging toward " + (int) lockYaw + "° (stop with .autofind off or .panic)");
    }
    @Override protected void onDisable() { Minecraft mc = Minecraft.getInstance(); if (mc.player != null) release(mc); }

    @Override public void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.gameMode == null) return;
        t++;
        if (mc.player.getHealth() < get("minhealth")) { stop(mc, "low health"); return; }
        switch (st) {
            case CHECK -> {
                if (hasPickaxe(mc)) { st = St.SEARCH; return; }
                if (!on("buy")) { stop(mc, "you need a pickaxe"); return; }
                if (attempt >= CMDS.length * 2) { stop(mc, "could not buy a pickaxe from /shop or /ah, buy one and start again"); return; }
                if (mc.screen instanceof AbstractContainerScreen<?>) mc.player.closeContainer();
                mc.player.connection.sendCommand(CMDS[attempt % CMDS.length]);
                attempt++; st = St.OPEN; t = 0;
            }
            case OPEN -> {
                if (mc.screen instanceof AbstractContainerScreen<?>) { st = St.SCAN; t = 0; pages = 0; navs = 0; }
                else if (t > 60) st = St.CHECK;
            }
            case SCAN -> scan(mc);
            case CONFIRM -> confirm(mc);
            case WAIT -> {
                if (hasPickaxe(mc)) { if (mc.screen instanceof AbstractContainerScreen<?>) mc.player.closeContainer(); st = St.SEARCH; }
                else if (t > 60) st = St.CHECK;
            }
            case SEARCH -> search(mc);
        }
    }

    private static double price(ItemStack stack) {
        var lore = stack.get(DataComponents.LORE);
        if (lore == null) return Double.MAX_VALUE;
        for (Component c : lore.lines()) {
            Matcher m = PRICE.matcher(c.getString());
            if (!m.find()) continue;
            String num = m.group(1) != null ? m.group(1) : m.group(3), suf = m.group(1) != null ? m.group(2) : m.group(4);
            try {
                double v = Double.parseDouble(num.replace(",", ""));
                if (suf != null) v *= switch (suf.toLowerCase()) { case "k" -> 1e3; case "m" -> 1e6; default -> 1e9; };
                return v;
            } catch (NumberFormatException ignored) {}
        }
        return Double.MAX_VALUE;
    }

    private void click(Minecraft mc, net.minecraft.world.inventory.AbstractContainerMenu menu, Slot s) {
        mc.gameMode.handleInventoryMouseClick(menu.containerId, s.index, 0, ClickType.PICKUP, mc.player);
    }

    private void scan(Minecraft mc) {
        if (!(mc.screen instanceof AbstractContainerScreen<?> cs)) { st = St.CHECK; return; }
        if (t < 8) return; // let the items load
        var menu = cs.getMenu();
        Slot bestSlot = null, nav = null, next = null;
        double bestPrice = Double.MAX_VALUE;
        for (Slot s : menu.slots) {
            if (s.container == mc.player.getInventory()) continue;
            ItemStack it = s.getItem();
            if (it.isEmpty()) continue;
            String nm = it.getHoverName().getString().toLowerCase();
            if (isPickaxe(it)) {
                double p = price(it);
                if (p < bestPrice) { bestPrice = p; bestSlot = s; }
            }
            if (nav == null && (nm.contains("pickaxe") || nm.contains("tool"))) nav = s;
            if (next == null && (nm.contains("next") || nm.contains("»") || nm.contains("→"))) next = s;
        }
        if (bestSlot != null) { click(mc, menu, bestSlot); st = St.CONFIRM; t = 0; return; }
        if (nav != null && navs < 2) { navs++; click(mc, menu, nav); t = 0; return; }
        if (next != null && pages < 4) { pages++; click(mc, menu, next); t = 0; return; }
        if (t > 40) { mc.player.closeContainer(); st = St.CHECK; }
    }

    private void confirm(Minecraft mc) {
        if (!(mc.screen instanceof AbstractContainerScreen<?> cs)) { st = St.WAIT; t = 0; return; }
        if (t < 5) return;
        var menu = cs.getMenu();
        for (Slot s : menu.slots) {
            if (s.container == mc.player.getInventory()) continue;
            ItemStack it = s.getItem();
            if (it.isEmpty()) continue;
            String nm = it.getHoverName().getString().toLowerCase();
            boolean yes = nm.contains("confirm") || nm.contains("accept") || nm.contains("purchase") || nm.equals("buy") || nm.contains("yes")
                    || it.is(Items.LIME_STAINED_GLASS_PANE) || it.is(Items.GREEN_STAINED_GLASS_PANE) || it.is(Items.LIME_WOOL) || it.is(Items.EMERALD_BLOCK);
            if (yes) { click(mc, menu, s); st = St.WAIT; t = 0; return; }
        }
        if (t > 30) { st = St.WAIT; t = 0; }
    }

    private boolean intact(Minecraft mc, FinderModule.Found f) {
        AABB a = f.area();
        if (a == null) return true;
        int y = (int) Math.floor(a.minY) - 1, solid = 0, total = 0;
        for (double x = a.minX; x < a.maxX; x += 2)
            for (double z = a.minZ; z < a.maxZ; z += 2) {
                total++;
                if (!mc.level.isEmptyBlock(BlockPos.containing(x, y, z))) solid++;
            }
        return total == 0 || solid >= total * 0.6;
    }

    private void search(Minecraft mc) {
        if (mc.screen != null) return;
        var me = mc.player; var o = mc.options;
        if (!hasPickaxe(mc)) { release(mc); st = St.CHECK; attempt = 0; return; }

        for (var c : List.of(WorldModules.BaseFinder.class, WorldModules.ChestFinder.class, WorldModules.BaseBlocks.class)) {
            FinderModule fm = HiroClient.modules.get(c);
            if (fm == null) continue;
            for (FinderModule.Found f : fm.results())
                if (!on("intact") || intact(mc, f)) { found(mc, f); return; }
        }

        if (!isPickaxe(me.getMainHandItem())) {
            int slot = BlockUtil.hotbar(mc, AutoFindModule::isPickaxe);
            if (slot >= 0) BlockUtil.select(mc, slot);
            else {
                var inv = me.getInventory();
                for (int i = 9; i < 36; i++)
                    if (isPickaxe(inv.getItem(i))) { mc.gameMode.handleInventoryMouseClick(me.inventoryMenu.containerId, i, inv.getSelectedSlot(), ClickType.SWAP, me); break; }
            }
        }

        int dx = (int) -Math.round(Math.sin(Math.toRadians(lockYaw))), dz = (int) Math.round(Math.cos(Math.toRadians(lockYaw)));
        BlockPos feet = me.blockPosition();
        for (int i = 1; i <= 3; i++)
            for (int dy = -1; dy <= 2; dy++)
                if (mc.level.getFluidState(feet.offset(dx * i, dy, dz * i)).is(FluidTags.LAVA)) { stop(mc, "lava ahead"); return; }

        me.setYRot(lockYaw);
        me.setXRot((t / 14) % 2 == 0 ? 0f : 55f);
        o.keyAttack.setDown(true);
        o.keyUp.setDown(true);
    }

    private void found(Minecraft mc, FinderModule.Found f) {
        BlockPos p = f.pos();
        String c = p.getX() + " " + p.getY() + " " + p.getZ();
        release(mc);
        CommandManager.info("§aYou find a base §f" + c);
        Notifier.push("YOU FIND A BASE", c);
        try {
            Files.writeString(FabricLoader.getInstance().getConfigDir().resolve("hiro-bases.txt"), f.label() + " @ " + c + System.lineSeparator(),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (Exception ignored) {}
        setEnabled(false);
        if (on("kick")) {
            var conn = mc.getConnection();
            if (conn != null) conn.getConnection().disconnect(Component.literal("You find a base\n" + c));
        }
    }
}
