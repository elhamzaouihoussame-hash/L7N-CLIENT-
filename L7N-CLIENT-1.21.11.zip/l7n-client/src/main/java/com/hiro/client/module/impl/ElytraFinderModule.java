package com.hiro.client.module.impl;

import com.hiro.client.CommandManager;
import com.hiro.client.gui.Notifier;
import com.hiro.client.gui.Projector;
import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.Items;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Finds elytra sitting in item frames (the kind found on end ships) and draws a line + box through walls. */
public class ElytraFinderModule extends Module {
    private final List<ItemFrame> found = new ArrayList<>();
    private final Set<Integer> announced = new HashSet<>();
    private int cd;

    public ElytraFinderModule() {
        super("ElytraFinder", "Finds elytra in item frames (end ships) through walls", Category.MISC);
        addSetting("range", 150, 10); addToggle("tracers", true); addToggle("boxes", true); addToggle("chat", true);
    }
    @Override public boolean hasHud() { return true; }
    @Override public List<String> hudLines() {
        if (found.isEmpty()) return List.of();
        List<String> l = new ArrayList<>();
        l.add("Elytra (" + found.size() + ")");
        Minecraft mc = Minecraft.getInstance();
        for (ItemFrame f : found) l.add(" " + (int) f.position().x + " " + (int) f.position().y + " " + (int) f.position().z
                + " (" + (mc.player == null ? "?" : (int) mc.player.distanceTo(f)) + "m)");
        return l;
    }
    @Override protected void onDisable() { found.clear(); announced.clear(); }

    @Override public void tick(Minecraft mc) {
        if (cd-- > 0 || mc.level == null) return;
        cd = 20;
        found.clear();
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof ItemFrame f) || !f.getItem().is(Items.ELYTRA)) continue;
            if (mc.player != null && mc.player.distanceTo(f) > get("range")) continue;
            found.add(f);
            if (on("chat") && announced.add(f.getId())) {
                String msg = (int) f.getX() + " " + (int) f.getY() + " " + (int) f.getZ();
                CommandManager.info("§bElytra found: §f" + msg);
                Notifier.push("ELYTRA FOUND", msg);
            }
        }
    }

    @Override public void renderOverlay(GuiGraphics g, Minecraft mc, Projector p, float pt) {
        int col = 0xFF38BDF8;
        for (ItemFrame f : found) {
            var bb = f.getBoundingBox().inflate(0.3);
            if (on("boxes")) p.box(g, bb, col);
            if (on("tracers")) p.tracer(g, bb.getCenter(), col, true);
        }
    }
}
