package com.hiro.client.module.impl;

import com.hiro.client.Data;
import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Standalone AutoPvP controller. It does not enable or call CrystalAura/AnchorAura.
 * It independently handles nearby crystal placement/breaking and anchor placement,
 * charging and detonation. Server rules and available blocks/items still apply.
 */
public final class AutoPvPModule extends Module {
    private int cooldown;
    private String mode = "SEARCHING";
    private int originalSlot = -1;

    public AutoPvPModule() {
        super("AutoPvP", "Standalone Crystal + Anchor combat", Category.COMBAT);
        addSetting("targetrange", 8.0, 0.5);
        addSetting("range", 4.5, 0.25);
        addSetting("maxself", 7.0, 0.5);
        addSetting("mindamage", 3.0, 0.5);
        addSetting("delay", 5.0, 1.0); // 5 ticks between actions: deliberate, ordinary pacing
        addToggle("crystal", true);
        addToggle("anchor", true);
        addToggle("rotate", true);
    }

    @Override protected void onEnable() {
        cooldown = 0;
        originalSlot = -1;
        mode = "SEARCHING";
    }

    @Override protected void onDisable() {
        mode = "OFF";
        // Do not force a slot change on disable; the player may have selected another item.
        originalSlot = -1;
    }

    @Override public List<String> hudLines() { return List.of("Mode: " + mode); }

    @Override public void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        Player target = findTarget(mc);
        if (target == null) { mode = "NO TARGET"; return; }
        if (mc.player.getHealth() < 5.0f) { mode = "LOW HEALTH"; return; }

        // Use only an anchor that the player has already placed. Never place one automatically.
        if (on("anchor") && mc.player.distanceTo(target) <= 6.0 && runAnchor(mc, target)) return;

        // Crystal sequence: break a useful crystal, use an existing obsidian base,
        // or place an obsidian base first and place the crystal on a later tick.
        if (on("crystal") && breakTargetCrystal(mc, target)) return;
        if (on("crystal") && placeCrystal(mc, target)) return;
        if (on("crystal") && placeObsidianBase(mc, target)) return;
        mode = "WAITING FOR POSITION / ITEMS";
    }

    private Player findTarget(Minecraft mc) {
        Player best = null;
        double bestDistance = get("targetrange");
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator() || Data.isFriend(p.getName().getString())) continue;
            Vec3 toTarget = p.position().subtract(mc.player.position()).normalize();
            if (mc.player.getLookAngle().normalize().dot(toTarget) < 0.15) continue; // target must be in front
            double d = mc.player.distanceTo(p);
            if (d < bestDistance) { bestDistance = d; best = p; }
        }
        return best;
    }

    private boolean breakTargetCrystal(Minecraft mc, Player target) {
        EndCrystal best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof EndCrystal crystal) || !crystal.isAlive()) continue;
            if (crystal.position().distanceTo(target.position()) > 8.0) continue;
            double d = mc.player.getEyePosition().distanceTo(crystal.getBoundingBox().getCenter());
            if (d > get("range") || selfDamage(mc, crystal.position(), 6.0) > get("maxself")) continue;
            if (d < bestDistance) { bestDistance = d; best = crystal; }
        }
        if (best == null) return false;
        if (on("rotate")) face(mc, best.getBoundingBox().getCenter());
        mc.gameMode.attack(mc.player, best);
        mc.player.swing(InteractionHand.MAIN_HAND);
        mode = "CRYSTAL: BREAK";
        cooldown = Math.max(1, (int) get("delay"));
        return true;
    }

    private boolean placeCrystal(Minecraft mc, Player target) {
        int crystalSlot = hotbar(mc, Items.END_CRYSTAL);
        if (crystalSlot < 0) return false;
        BlockPos targetPos = target.blockPosition();
        BlockPos best = null;
        double bestScore = -Double.MAX_VALUE;
        for (int x = -5; x <= 5; x++) for (int y = -2; y <= 1; y++) for (int z = -5; z <= 5; z++) {
            BlockPos base = targetPos.offset(x, y, z);
            if (!mc.level.getBlockState(base).is(Blocks.OBSIDIAN) && !mc.level.getBlockState(base).is(Blocks.BEDROCK)) continue;
            if (!mc.level.isEmptyBlock(base.above()) || !mc.level.isEmptyBlock(base.above(2))) continue;
            if (!mc.level.getEntities((Entity) null, new AABB(base.above()).expandTowards(0, 1, 0), e -> true).isEmpty()) continue;
            Vec3 hit = Vec3.atCenterOf(base.above());
            if (mc.player.getEyePosition().distanceTo(hit) > get("range")) continue;
            double enemy = damageEstimate(target.position().distanceTo(hit), 6.0);
            double self = selfDamage(mc, hit, 6.0);
            if (enemy < get("mindamage") || self > get("maxself") || self >= mc.player.getHealth() - 2) continue;
            double score = enemy - self * 0.65;
            if (score > bestScore) { bestScore = score; best = base; }
        }
        if (best == null) return false;
        select(mc, crystalSlot);
        Vec3 hit = new Vec3(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5);
        if (on("rotate")) face(mc, hit);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, best, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
        mode = "CRYSTAL: PLACE";
        cooldown = Math.max(1, (int) get("delay"));
        return true;
    }

    private boolean runAnchor(Minecraft mc, Player target) {
        BlockPos anchorPos = findNearbyAnchor(mc, target);
        if (anchorPos == null) return false; // player must place the anchor manually

        int charge = mc.level.getBlockState(anchorPos).getValue(RespawnAnchorBlock.CHARGE);
        if (charge < 1) {
            int glow = nearestHotbar(mc, Items.GLOWSTONE);
            if (glow < 0) { mode = "ANCHOR: NEED GLOWSTONE"; return false; }
            select(mc, glow);
            if (on("rotate")) face(mc, Vec3.atCenterOf(anchorPos));
            interact(mc, anchorPos);
            mode = "ANCHOR: CHARGE 1/1";
        } else {
            // Prefer a totem in the hotbar for the detonation click, as requested.
            int totem = nearestHotbar(mc, Items.TOTEM_OF_UNDYING);
            int handSlot = totem >= 0 ? totem : firstNonGlowstoneHotbar(mc);
            if (handSlot < 0) { mode = "ANCHOR: NEED NON-GLOWSTONE ITEM"; return false; }
            double self = selfDamage(mc, Vec3.atCenterOf(anchorPos), 5.0);
            if (self > get("maxself") || self >= mc.player.getHealth() - 2) {
                mode = "ANCHOR: SELF-DAMAGE BLOCK";
                return false;
            }
            select(mc, handSlot);
            if (on("rotate")) face(mc, Vec3.atCenterOf(anchorPos));
            interact(mc, anchorPos); // right-click with the totem selected detonates the charged anchor
            mode = totem >= 0 ? "ANCHOR: DETONATE (TOTEM)" : "ANCHOR: DETONATE";
        }
        cooldown = Math.max(1, (int) get("delay"));
        return true;
    }

    private int nearestHotbar(Minecraft mc, net.minecraft.world.item.Item item) {
        int selected = mc.player.getInventory().getSelectedSlot();
        int best = -1, bestDistance = Integer.MAX_VALUE;
        for (int i = 0; i < 9; i++) {
            if (!mc.player.getInventory().getItem(i).is(item)) continue;
            int d = Math.abs(i - selected);
            d = Math.min(d, 9 - d);
            if (d < bestDistance) { bestDistance = d; best = i; }
        }
        return best;
    }

    private boolean placeObsidianBase(Minecraft mc, Player target) {
        int obsidianSlot = nearestHotbar(mc, Items.OBSIDIAN);
        if (obsidianSlot < 0) return false;
        BlockPos center = target.blockPosition();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        for (int x = -3; x <= 3; x++) for (int y = -1; y <= 1; y++) for (int z = -3; z <= 3; z++) {
            BlockPos pos = center.offset(x, y, z);
            if (!mc.level.getBlockState(pos).canBeReplaced()) continue;
            if (!mc.level.isEmptyBlock(pos.above()) || !mc.level.isEmptyBlock(pos.above(2))) continue;
            if (mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(pos)) > get("range")) continue;
            if (mc.level.getBlockState(pos.below()).canBeReplaced()) continue;
            if (!mc.level.getEntities((Entity) null, new AABB(pos).expandTowards(0, 2, 0), e -> true).isEmpty()) continue;
            double enemyDistance = target.position().distanceTo(Vec3.atCenterOf(pos.above()));
            double selfDistance = mc.player.position().distanceTo(Vec3.atCenterOf(pos.above()));
            double estimatedSelf = damageEstimate(selfDistance, 6.0);
            if (damageEstimate(enemyDistance, 6.0) < get("mindamage") || estimatedSelf > get("maxself") || estimatedSelf >= mc.player.getHealth() - 2) continue;
            double score = enemyDistance + selfDistance * 0.2;
            if (score < bestScore) { bestScore = score; best = pos; }
        }
        if (best == null) return false;
        select(mc, obsidianSlot);
        BlockPos support = best.below();
        Vec3 hit = new Vec3(support.getX() + 0.5, support.getY() + 1.0, support.getZ() + 0.5);
        if (on("rotate")) face(mc, hit);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, support, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
        mode = "CRYSTAL: PLACE OBSIDIAN";
        cooldown = Math.max(1, (int) get("delay"));
        return true;
    }

    private BlockPos findNearbyAnchor(Minecraft mc, Player target) {
        BlockPos origin = mc.player.blockPosition();
        BlockPos best = null;
        double score = Double.MAX_VALUE;
        for (int x = -5; x <= 5; x++) for (int y = -4; y <= 4; y++) for (int z = -5; z <= 5; z++) {
            BlockPos p = origin.offset(x, y, z);
            if (!mc.level.getBlockState(p).is(Blocks.RESPAWN_ANCHOR)) continue;
            double d = mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(p));
            if (d > get("range") || target.position().distanceTo(Vec3.atCenterOf(p)) > 6.0) continue;
            if (d < score) { score = d; best = p; }
        }
        return best;
    }

    private boolean placeAgainst(Minecraft mc, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos neighbour = pos.relative(d);
            if (mc.level.getBlockState(neighbour).canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 hit = new Vec3(neighbour.getX() + 0.5 + face.getStepX() * 0.5,
                    neighbour.getY() + 0.5 + face.getStepY() * 0.5,
                    neighbour.getZ() + 0.5 + face.getStepZ() * 0.5);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                    new BlockHitResult(hit, face, neighbour, false));
            mc.player.swing(InteractionHand.MAIN_HAND);
            return true;
        }
        return false;
    }

    private void interact(Minecraft mc, BlockPos pos) {
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private int hotbar(Minecraft mc, net.minecraft.world.item.Item item) {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).is(item)) return i;
        return -1;
    }

    private int firstNonGlowstoneHotbar(Minecraft mc) {
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getItem(i);
            if (!stack.isEmpty() && !stack.is(Items.GLOWSTONE)) return i;
        }
        return -1;
    }

    private void select(Minecraft mc, int slot) { mc.player.getInventory().setSelectedSlot(slot); }
    private void face(Minecraft mc, Vec3 pos) {
        Vec3 d = pos.subtract(mc.player.getEyePosition());
        mc.player.setYRot((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0));
        mc.player.setXRot((float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z))));
    }
    private double selfDamage(Minecraft mc, Vec3 pos, double power) {
        return damageEstimate(mc.player.position().distanceTo(pos), power);
    }
    private double damageEstimate(double distance, double power) {
        double impact = 1.0 - distance / (power * 2.0);
        if (impact <= 0) return 0;
        return (impact * impact + impact) * 0.5 * 7.0 * power * 2.0 + 1.0;
    }
}
