package com.hiro.client.module.impl;

import com.hiro.client.Data;
import com.hiro.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Standalone AutoPvP controller. It does not enable or call CrystalAura/AnchorAura.
 * It independently handles nearby crystal placement/breaking and anchor placement,
 * charging and detonation. Server rules and available blocks/items still apply.
 */
public final class AutoPvPModule extends Module {
    private int cooldown;
    private String mode = "SEARCHING";
    private int originalSlot = -1;

    public AutoPvPModule() {
        super("AutoPvP", "Standalone Crystal + Anchor combat", Category.COMBAT);
        addSetting("targetrange", 8.0, 0.5);
        addSetting("range", 4.5, 0.25);
        addSetting("maxself", 7.0, 0.5);
        addSetting("mindamage", 3.0, 0.5);
        addSetting("delay", 5.0, 1.0); // 5 ticks between actions: deliberate, ordinary pacing
        addToggle("crystal", true);
        addToggle("anchor", true);
        addToggle("rotate", true);
    }

    @Override protected void onEnable() {
        cooldown = 0;
        originalSlot = -1;
        mode = "SEARCHING";
    }

    @Override protected void onDisable() {
        mode = "OFF";
        // Do not force a slot change on disable; the player may have selected another item.
        originalSlot = -1;
    }

    @Override public List<String> hudLines() { return List.of("Mode: " + mode); }

    @Override public void tick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (cooldown > 0) { cooldown--; return; }
        Player target = findTarget(mc);
        if (target == null) { mode = "NO TARGET"; return; }
        if (mc.player.getHealth() < 5.0f) { mode = "LOW HEALTH"; return; }

        // Break an existing crystal only when it is close to the selected target and
        // the estimated self-damage is below the configured safety limit.
        if (on("crystal") && breakTargetCrystal(mc, target)) return;

        // At close range, independently run the anchor sequence: place -> charge -> detonate.
        if (on("anchor") && mc.player.distanceTo(target) <= 5.0 && runAnchor(mc, target)) return;

        if (on("crystal") && placeCrystal(mc, target)) return;
        mode = "WAITING FOR POSITION / ITEMS";
    }

    private Player findTarget(Minecraft mc) {
        Player best = null;
        double bestDistance = get("targetrange");
        for (Player p : mc.level.players()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator() || Data.isFriend(p.getName().getString())) continue;
            double d = mc.player.distanceTo(p);
            if (d < bestDistance) { bestDistance = d; best = p; }
        }
        return best;
    }

    private boolean breakTargetCrystal(Minecraft mc, Player target) {
        EndCrystal best = null;
        double bestDistance = Double.MAX_VALUE;
        for (Entity e : mc.level.entitiesForRendering()) {
            if (!(e instanceof EndCrystal crystal) || !crystal.isAlive()) continue;
            if (crystal.position().distanceTo(target.position()) > 8.0) continue;
            double d = mc.player.getEyePosition().distanceTo(crystal.getBoundingBox().getCenter());
            if (d > get("range") || selfDamage(mc, crystal.position(), 6.0) > get("maxself")) continue;
            if (d < bestDistance) { bestDistance = d; best = crystal; }
        }
        if (best == null) return false;
        if (on("rotate")) face(mc, best.getBoundingBox().getCenter());
        mc.gameMode.attack(mc.player, best);
        mc.player.swing(InteractionHand.MAIN_HAND);
        mode = "CRYSTAL: BREAK";
        cooldown = Math.max(1, (int) get("delay"));
        return true;
    }

    private boolean placeCrystal(Minecraft mc, Player target) {
        int crystalSlot = hotbar(mc, Items.END_CRYSTAL);
        if (crystalSlot < 0) return false;
        BlockPos targetPos = target.blockPosition();
        BlockPos best = null;
        double bestScore = -Double.MAX_VALUE;
        for (int x = -5; x <= 5; x++) for (int y = -2; y <= 1; y++) for (int z = -5; z <= 5; z++) {
            BlockPos base = targetPos.offset(x, y, z);
            if (!mc.level.getBlockState(base).is(Blocks.OBSIDIAN) && !mc.level.getBlockState(base).is(Blocks.BEDROCK)) continue;
            if (!mc.level.isEmptyBlock(base.above()) || !mc.level.isEmptyBlock(base.above(2))) continue;
            if (!mc.level.getEntities((Entity) null, new AABB(base.above()).expandTowards(0, 1, 0), e -> true).isEmpty()) continue;
            Vec3 hit = Vec3.atCenterOf(base.above());
            if (mc.player.getEyePosition().distanceTo(hit) > get("range")) continue;
            double enemy = damageEstimate(target.position().distanceTo(hit), 6.0);
            double self = selfDamage(mc, hit, 6.0);
            if (enemy < get("mindamage") || self > get("maxself") || self >= mc.player.getHealth() - 2) continue;
            double score = enemy - self * 0.65;
            if (score > bestScore) { bestScore = score; best = base; }
        }
        if (best == null) return false;
        select(mc, crystalSlot);
        Vec3 hit = new Vec3(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5);
        if (on("rotate")) face(mc, hit);
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new BlockHitResult(hit, Direction.UP, best, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
        mode = "CRYSTAL: PLACE";
        cooldown = Math.max(1, (int) get("delay"));
        return true;
    }

    private boolean runAnchor(Minecraft mc, Player target) {
        BlockPos anchorPos = findNearbyAnchor(mc, target);
        if (anchorPos == null) {
            int anchorSlot = hotbar(mc, Items.RESPAWN_ANCHOR);
            if (anchorSlot < 0) return false;
            BlockPos placePos = findAnchorPlacement(mc, target);
            if (placePos == null) return false;
            select(mc, anchorSlot);
            if (on("rotate")) face(mc, Vec3.atCenterOf(placePos));
            if (placeAgainst(mc, placePos)) {
                mode = "ANCHOR: PLACE";
                cooldown = Math.max(1, (int) get("delay"));
                return true;
            }
            return false;
        }

        int charge = mc.level.getBlockState(anchorPos).getValue(RespawnAnchorBlock.CHARGE);
        if (charge == 0) {
            int glow = hotbar(mc, Items.GLOWSTONE);
            if (glow < 0) return false;
            select(mc, glow);
            interact(mc, anchorPos);
            mode = "ANCHOR: CHARGE";
        } else {
            double self = selfDamage(mc, Vec3.atCenterOf(anchorPos), 5.0);
            if (self > get("maxself") || self >= mc.player.getHealth() - 2) return false;
            // Select a non-glowstone item so the charged anchor interaction detonates it.
            int other = firstNonGlowstoneHotbar(mc);
            if (other < 0) return false;
            select(mc, other);
            if (on("rotate")) face(mc, Vec3.atCenterOf(anchorPos));
            interact(mc, anchorPos);
            mode = "ANCHOR: DETONATE";
        }
        cooldown = Math.max(1, (int) get("delay"));
        return true;
    }

    private BlockPos findNearbyAnchor(Minecraft mc, Player target) {
        BlockPos origin = mc.player.blockPosition();
        BlockPos best = null;
        double score = Double.MAX_VALUE;
        for (int x = -5; x <= 5; x++) for (int y = -4; y <= 4; y++) for (int z = -5; z <= 5; z++) {
            BlockPos p = origin.offset(x, y, z);
            if (!mc.level.getBlockState(p).is(Blocks.RESPAWN_ANCHOR)) continue;
            double d = mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(p));
            if (d > get("range") || target.position().distanceTo(Vec3.atCenterOf(p)) > 6.0) continue;
            if (d < score) { score = d; best = p; }
        }
        return best;
    }

    private BlockPos findAnchorPlacement(Minecraft mc, Player target) {
        BlockPos base = target.blockPosition();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        for (int x = -2; x <= 2; x++) for (int y = -1; y <= 1; y++) for (int z = -2; z <= 2; z++) {
            BlockPos p = base.offset(x, y, z);
            if (!mc.level.getBlockState(p).canBeReplaced()) continue;
            if (mc.player.getEyePosition().distanceTo(Vec3.atCenterOf(p)) > get("range")) continue;
            boolean hasFace = false;
            for (Direction d : Direction.values()) if (!mc.level.getBlockState(p.relative(d)).canBeReplaced()) { hasFace = true; break; }
            if (!hasFace) continue;
            double score = target.position().distanceTo(Vec3.atCenterOf(p)) + mc.player.position().distanceTo(Vec3.atCenterOf(p)) * 0.15;
            if (score < bestScore) { bestScore = score; best = p; }
        }
        return best;
    }

    private boolean placeAgainst(Minecraft mc, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockPos neighbour = pos.relative(d);
            if (mc.level.getBlockState(neighbour).canBeReplaced()) continue;
            Direction face = d.getOpposite();
            Vec3 hit = new Vec3(neighbour.getX() + 0.5 + face.getStepX() * 0.5,
                    neighbour.getY() + 0.5 + face.getStepY() * 0.5,
                    neighbour.getZ() + 0.5 + face.getStepZ() * 0.5);
            mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                    new BlockHitResult(hit, face, neighbour, false));
            mc.player.swing(InteractionHand.MAIN_HAND);
            return true;
        }
        return false;
    }

    private void interact(Minecraft mc, BlockPos pos) {
        mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND,
                new BlockHitResult(Vec3.atCenterOf(pos), Direction.UP, pos, false));
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    private int hotbar(Minecraft mc, net.minecraft.world.item.Item item) {
        for (int i = 0; i < 9; i++) if (mc.player.getInventory().getItem(i).is(item)) return i;
        return -1;
    }

    private int firstNonGlowstoneHotbar(Minecraft mc) {
        for (int i = 0; i < 9; i++) {
            var stack = mc.player.getInventory().getItem(i);
            if (!stack.isEmpty() && !stack.is(Items.GLOWSTONE)) return i;
        }
        return -1;
    }

    private void select(Minecraft mc, int slot) { mc.player.getInventory().setSelectedSlot(slot); }
    private void face(Minecraft mc, Vec3 pos) {
        Vec3 d = pos.subtract(mc.player.getEyePosition());
        mc.player.setYRot((float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0));
        mc.player.setXRot((float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z))));
    }
    private double selfDamage(Minecraft mc, Vec3 pos, double power) {
        return damageEstimate(mc.player.position().distanceTo(pos), power);
    }
    private double damageEstimate(double distance, double power) {
        double impact = 1.0 - distance / (power * 2.0);
        if (impact <= 0) return 0;
        return (impact * impact + impact) * 0.5 * 7.0 * power * 2.0 + 1.0;
    }
}
