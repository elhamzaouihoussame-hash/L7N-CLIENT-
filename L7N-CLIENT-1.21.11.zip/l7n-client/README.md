# HIRO CLIENT (Fabric, Minecraft 1.21.11)
Build: install JDK 21, then `gradle wrapper` (or copy a Gradle 9.4+ wrapper) and run `./gradlew build`.
Jar: build/libs/hiro-client-1.0.0.jar  ->  put in .minecraft/mods with Fabric Loader + Fabric API.
Open the ClickGUI with Right Shift.

AutoBuilder supports Litematica `.litematic`, Sponge/WorldEdit `.schem`, and vanilla structure `.nbt` files. Put files in `config/hiro-client/schematics/`, select one in Commands > Build, stand at the schematic origin, then toggle AutoBuilder. It places blocks from your hotbar; it does not bypass server protections or obtain missing materials.
Written from scratch; ideas inspired by Meteor (GPLv3) - keep GPL + credit if you copy any real Meteor code.
