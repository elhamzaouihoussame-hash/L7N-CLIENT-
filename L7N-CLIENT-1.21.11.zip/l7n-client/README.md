# L7N CLIENT (Fabric, Minecraft 1.21.11)
Build: install JDK 21, then `gradle wrapper` (or copy a Gradle 9.4+ wrapper) and run `./gradlew build`.
Jar: build/libs/l7n-client-1.0.0.jar  ->  put in .minecraft/mods with Fabric Loader + Fabric API.
Open the ClickGUI with Right Shift.
Written from scratch; ideas inspired by Meteor (GPLv3) - keep GPL + credit if you copy any real Meteor code.
