# HIRO CLIENT (Fabric, Minecraft 1.21.11)
Build: install JDK 21, then `gradle wrapper` (or copy a Gradle 9.4+ wrapper) and run `./gradlew build`.
Jar: build/libs/hiro-client-1.0.0.jar  ->  put in .minecraft/mods with Fabric Loader + Fabric API.
Open the ClickGUI with Right Shift.

AutoBuilder supports Litematica `.litematic`, Sponge/WorldEdit `.schem`, and vanilla structure `.nbt` files. Put files in `config/hiro-client/schematics/`, select one in Commands > Build, stand at the schematic origin, then toggle AutoBuilder. It places blocks from your hotbar; it does not bypass server protections or obtain missing materials.
Written from scratch; ideas inspired by Meteor (GPLv3) - keep GPL + credit if you copy any real Meteor code.

## Added
- `AutoReload` (Misc): leaves the server and rejoins when Y <= -depth (default 3 = Y -3). ClickGUI only, settings: depth, delay (ticks), retries.
- `AutoElytraMace` (Combat): bot. ClickGUI only. Pearl (look up) + wind charge (look down) launch, elytra glide, never chases, chestplate + mace on anyone in reach (360 degrees).
- `FakeStats` (Misc): client-side only. Shows fake name (HIRO IN TOP), money, playtime and kills/deaths in chat, sidebar scoreboard and tab list.
- `CrystalSpeed` (Combat): fast crystal place + auto break. `speed` = cycles per second (adjustable in settings).
