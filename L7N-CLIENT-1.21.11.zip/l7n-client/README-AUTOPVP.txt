L7N / HIRO CLIENT - AutoPvP update (Minecraft Java Fabric 1.21.11)

AutoPvP behaviour in this revision:
- Respawn Anchors are NOT placed automatically. The player must place an anchor.
- When a suitable player-placed anchor is nearby and a target is in front, AutoPvP charges it with Glowstone up to 4 charges.
- For detonation it selects the nearest hotbar Totem of Undying (relative to the currently selected slot) and right-clicks the charged anchor.
- If no totem is in the hotbar, it uses another non-Glowstone hotbar item for the detonation click.
- Crystal mode can use an existing Obsidian/Bedrock base. If none is suitable, it attempts to place an Obsidian base first, then places the End Crystal on a later action.
- Target selection ignores friends and targets behind the player's view.
- Default delay remains 5 ticks between actions to avoid overly fast, rejected interactions.

Notes:
- Requires the relevant items in the hotbar and a server/world that permits the actions.
- Self-damage estimates are approximate; they are not a guarantee of safety.
- This source revision was ZIP-validated, but a Gradle build was not run in this environment because Gradle is not installed.
