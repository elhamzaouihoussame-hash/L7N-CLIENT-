L7N CLIENT - Standalone AutoPvP update

AutoPvP is now implemented as its own module and does not enable or call the
legacy CrystalAura or AnchorAura modules.

Current behavior:
- Selects the nearest non-friend player inside targetrange.
- Breaks nearby end crystals when the estimated self-damage is within maxself.
- Places end crystals on existing obsidian/bedrock when a suitable position is
  in range and the estimated damage checks pass.
- At close range, independently places a respawn anchor, charges it with
  glowstone, then interacts with it to detonate it when the self-damage check
  allows.
- Offers range, targetrange, maxself, mindamage, delay and mode toggles.

Important limits:
- This is an initial standalone implementation, not a verified recreation of
  every movement, timing, aim and inventory action visible in the reference video.
- Crystal placement requires an existing obsidian or bedrock base.
- Server-side anti-cheat, protection plugins, interaction limits and latency
  can prevent or delay actions.
- Build verification was not possible in this environment because Gradle and
  a Gradle wrapper are not present. Build the project with the matching Gradle
  setup before installing it.


Update: AutoPvP default action delay is 5 ticks (about 4 actions/second at 20 TPS), adjustable through the module delay setting. A separate AutoPvP keybind is registered as "Toggle AutoPvP" under Options > Controls > Key Binds; it is unbound by default so you can choose a key.
