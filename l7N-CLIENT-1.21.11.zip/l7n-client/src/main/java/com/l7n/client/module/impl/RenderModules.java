package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;
import java.util.ArrayList;
import java.util.List;

public final class RenderModules {
    private RenderModules() {}

    public static class Radar extends Module {
        public Radar() { super("Radar", "List nearby players", Category.RENDER); addSetting("max", 5, 1); }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() {
            Minecraft mc = Minecraft.getInstance();
            List<String> l = new ArrayList<>();
            if (mc.level == null || mc.player == null) return l;
            for (var p : mc.level.players()) {
                if (p == mc.player) continue;
                l.add(p.getName().getString() + " " + (int) mc.player.distanceTo(p) + "m");
                if (l.size() >= (int) get("max")) break;
            }
            return l;
        }
    }

    public static class Speedometer extends Module {
        public Speedometer() { super("Speedometer", "Show your speed in blocks/second", Category.RENDER); }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null) return List.of();
            Vec3 v = mc.player.getDeltaMovement();
            return List.of(String.format("Speed: %.1f b/s", Math.sqrt(v.x * v.x + v.z * v.z) * 20));
        }
    }

    public static class Keystrokes extends Module {
        public Keystrokes() { super("Keystrokes", "Show WASD keys", Category.RENDER); }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() {
            var o = Minecraft.getInstance().options;
            return List.of((o.keyUp.isDown() ? "W" : "-") + " " + (o.keyLeft.isDown() ? "A" : "-") + " "
                    + (o.keyDown.isDown() ? "S" : "-") + " " + (o.keyRight.isDown() ? "D" : "-") + (o.keyJump.isDown() ? "  SPACE" : ""));
        }
    }
}
