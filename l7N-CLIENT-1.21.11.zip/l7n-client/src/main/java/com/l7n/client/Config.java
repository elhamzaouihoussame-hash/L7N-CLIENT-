package com.l7n.client;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.l7n.client.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
    private Config() {}
    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("l7n-client.json"); }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            for (Module m : L7NClient.modules.all) {
                JsonObject o = new JsonObject(), s = new JsonObject();
                o.addProperty("hudX", m.hudX); o.addProperty("hudY", m.hudY);
                for (var e : m.settings.entrySet()) s.addProperty(e.getKey(), e.getValue());
                o.add("settings", s);
                m.saveExtra(o);
                root.add(m.name, o);
            }
            Files.writeString(file(), new GsonBuilder().setPrettyPrinting().create().toJson(root));
        } catch (Exception ignored) {}
    }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            JsonObject root = JsonParser.parseString(Files.readString(file())).getAsJsonObject();
            for (Module m : L7NClient.modules.all) {
                if (!root.has(m.name)) continue;
                JsonObject o = root.getAsJsonObject(m.name);
                if (o.has("hudX")) m.hudX = o.get("hudX").getAsInt();
                if (o.has("hudY")) m.hudY = o.get("hudY").getAsInt();
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (String k : m.settings.keySet()) if (s.has(k)) m.settings.put(k, s.get(k).getAsDouble());
                }
                m.loadExtra(o);
            }
        } catch (Exception ignored) {}
    }
}
