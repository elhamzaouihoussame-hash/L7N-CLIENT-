package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class EspModule extends Module {
    public EspModule() { super("ESP", "Outline entities through walls", Category.RENDER); }
    @Override public void tick(Minecraft mc) {
        for (Entity e : mc.level.entitiesForRendering()) if (e instanceof LivingEntity && e != mc.player) e.setGlowingTag(true);
    }
    @Override protected void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level != null) for (Entity e : mc.level.entitiesForRendering()) e.setGlowingTag(false);
    }
}
