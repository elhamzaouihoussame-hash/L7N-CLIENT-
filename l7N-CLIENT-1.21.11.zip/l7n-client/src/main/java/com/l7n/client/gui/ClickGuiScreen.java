package com.l7n.client.gui;

import com.l7n.client.Config;
import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int HEAD = 18, ROW = 14, GAP = 8;
    private static final int PURPLE = 0xFFA855F7;
    private long openedAt;
    private final Module.Category[] cats = Module.Category.values();

    public ClickGuiScreen() { super(Component.literal("L7N CLIENT")); }
    @Override protected void init() { openedAt = System.currentTimeMillis(); }
    @Override public boolean isPauseScreen() { return false; }
    @Override public void removed() { Config.save(); }

    private int pw() { return Math.clamp((long) ((width - 8 - (cats.length - 1) * GAP) / cats.length), 70, 110); }
    private int x0() { return (width - (cats.length * pw() + (cats.length - 1) * GAP)) / 2; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float delta) {
        long now = System.currentTimeMillis();
        float open = Anim.easeOutCubic((now - openedAt) / 350f);
        g.fill(0, 0, width, height, Anim.alpha(0x05020D, 0.75f * open));

        int lw = 200, lh = lw * L7NClient.LOGO_H / L7NClient.LOGO_W;
        g.blit(RenderPipelines.GUI_TEXTURED, L7NClient.LOGO, (width - lw) / 2, height - lh - 4, 0, 0, lw, lh,
                L7NClient.LOGO_W, L7NClient.LOGO_H, L7NClient.LOGO_W, L7NClient.LOGO_H);

        int pw = pw(), x0 = x0();
        for (int i = 0; i < cats.length; i++) {
            float p = Anim.easeOutBack((now - openedAt - i * 70L) / 450f);
            float a = Math.clamp(p, 0f, 1f);
            int x = x0 + i * (pw + GAP), y = (int) (14 - (1 - p) * 40);
            g.fill(x, y, x + pw, y + HEAD, Anim.alpha(PURPLE, a));
            g.drawString(font, cats[i].name(), x + 6, y + 5, Anim.alpha(0xFFFFFF, a));
            int ry = y + HEAD;
            for (Module m : L7NClient.modules.in(cats[i])) {
                m.anim = Anim.approach(m.anim, m.isEnabled() ? 1f : 0f, 0.18f);
                boolean hover = mx >= x && mx < x + pw && my >= ry && my < ry + ROW;
                g.fill(x, ry, x + pw, ry + ROW, Anim.alpha(hover ? 0x2A1550 : 0x140A2A, 0.85f * a));
                g.fill(x, ry, x + 2 + (int) (m.anim * (pw - 2)), ry + ROW, Anim.alpha(PURPLE, 0.35f * m.anim * a));
                g.drawString(font, font.plainSubstrByWidth(m.name, pw - 8), x + 6, ry + 3, Anim.lerpColor(0xFFAAAAAA, 0xFFFFFFFF, m.anim));
                ry += ROW;
            }
        }
        g.drawCenteredString(font, "L7N CLIENT  -  Left click: toggle  |  Right click: settings", width / 2, height - 12, PURPLE);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent ev, boolean dbl) {
        int pw = pw(), x0 = x0();
        for (int i = 0; i < cats.length; i++) {
            int x = x0 + i * (pw + GAP), ry = 14 + HEAD;
            List<Module> mods = L7NClient.modules.in(cats[i]);
            for (Module m : mods) {
                if (ev.x() >= x && ev.x() < x + pw && ev.y() >= ry && ev.y() < ry + ROW) {
                    if (ev.button() == 1) minecraft.setScreen(new ModuleSettingsScreen(m, this));
                    else if (ev.button() == 0) m.toggle();
                    return true;
                }
                ry += ROW;
            }
        }
        return super.mouseClicked(ev, dbl);
    }
}
