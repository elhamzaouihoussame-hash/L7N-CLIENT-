package com.l7n.client.module.impl;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.l7n.client.CommandManager;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.GameType;
import net.minecraft.world.scores.PlayerTeam;
import java.util.*;
import java.util.regex.Pattern;

public final class StaffModules {
    private StaffModules() {}

    /** Staff members online. Detected from the rank text in the tab list / team prefix, plus names you add with .staff name <player>. */
    public static class StaffList extends Module {
        public final Set<String> keywords = new LinkedHashSet<>(List.of("owner", "admin", "mod", "helper", "staff", "dev", "manager", "support", "trial", "operator"));
        public final Set<String> names = new LinkedHashSet<>();
        private final List<String> lines = new ArrayList<>();
        private final Set<String> seen = new HashSet<>();
        private final List<PlayerInfo> icons = new ArrayList<>();
        private int cd; private boolean first = true;

        public StaffList() {
            super("StaffList", "Staff online (move it with .hud)", Category.RENDER);
            addToggle("alert", true); addToggle("spectators", false);
        }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() { return lines; }
        @Override public List<PlayerInfo> lineIcons() { return icons; }
        @Override protected void onEnable() { first = true; seen.clear(); cd = 0; }
        @Override protected void onDisable() { lines.clear(); icons.clear(); }

        @Override public void saveExtra(JsonObject o) {
            JsonArray k = new JsonArray(), n = new JsonArray();
            keywords.forEach(k::add); names.forEach(n::add);
            o.add("keywords", k); o.add("names", n);
        }
        @Override public void loadExtra(JsonObject o) {
            if (o.has("keywords")) { keywords.clear(); o.getAsJsonArray("keywords").forEach(e -> keywords.add(e.getAsString())); }
            if (o.has("names")) { names.clear(); o.getAsJsonArray("names").forEach(e -> names.add(e.getAsString())); }
        }

        @Override public void tick(Minecraft mc) {
            if (cd-- > 0) return;
            cd = 20;
            var conn = mc.getConnection();
            if (conn == null) return;
            List<String> found = new ArrayList<>();
            List<PlayerInfo> foundInfo = new ArrayList<>();
            Set<String> now = new HashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) {
                String name = pi.getProfile().name();
                Component shown = pi.getTabListDisplayName();
                String full = shown != null ? shown.getString() : PlayerTeam.formatNameForTeam(pi.getTeam(), Component.literal(name)).getString();
                String rest = full.replaceAll("(?i)" + Pattern.quote(name), "").toLowerCase();
                boolean spec = pi.getGameMode() == GameType.SPECTATOR;
                boolean staff = names.contains(name.toLowerCase()) || (spec && on("spectators"));
                if (!staff) for (String k : keywords) if (rest.contains(k.toLowerCase())) { staff = true; break; }
                if (staff) { found.add((full.isBlank() ? name : full.trim()) + (spec ? " [SPEC]" : "")); foundInfo.add(pi); now.add(name); }
            }
            lines.clear(); icons.clear();
            if (!found.isEmpty()) {
                lines.add("Staff (" + found.size() + ")"); icons.add(null);
                for (int i = 0; i < found.size() && i < 12; i++) { lines.add(found.get(i)); icons.add(foundInfo.get(i)); }
            }
            if (on("alert") && !first) for (String n : now) if (!seen.contains(n)) CommandManager.info("§cStaff online: §f" + n);
            seen.clear(); seen.addAll(now); first = false;
        }
    }

    /** Heuristic vanish detection: players that exist (nearby or in a scoreboard team) but are missing from the tab list. */
    public static class AntiVanish extends Module {
        private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
        private final List<String> lines = new ArrayList<>();
        private final Set<String> announced = new HashSet<>();
        private int cd;

        public AntiVanish() { super("AntiVanish", "Detects possibly vanished players", Category.MISC); addToggle("chat", true); }
        @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() { return lines; }
        @Override protected void onDisable() { lines.clear(); announced.clear(); }

        @Override public void tick(Minecraft mc) {
            if (cd-- > 0) return;
            cd = 40;
            var conn = mc.getConnection();
            if (conn == null || mc.level == null) return;
            Set<String> tab = new HashSet<>();
            for (PlayerInfo pi : conn.getOnlinePlayers()) tab.add(pi.getProfile().name().toLowerCase());
            Set<String> flagged = new LinkedHashSet<>();
            for (var p : mc.level.players()) {
                if (p == mc.player) continue;
                if (conn.getPlayerInfo(p.getUUID()) == null && p.getUUID().version() != 2) flagged.add(p.getName().getString() + " (near, not in tab)");
            }
            for (PlayerTeam t : mc.level.getScoreboard().getPlayerTeams())
                for (String n : t.getPlayers())
                    if (NAME.matcher(n).matches() && !tab.contains(n.toLowerCase())) flagged.add(n + " (team, not in tab)");
            lines.clear();
            if (!flagged.isEmpty()) {
                lines.add("Vanished? (" + flagged.size() + ")");
                int i = 0;
                for (String f : flagged) { if (i++ < 8) lines.add(" " + f); }
            }
            if (on("chat")) for (String f : flagged) if (announced.add(f)) CommandManager.info("§eVanished? §f" + f);
        }
    }

    /** Toggles CoreProtect inspect mode so clicking a block shows who placed/broke it. Needs CoreProtect + permission on the server. */
    public static class Inspector extends Module {
        public Inspector() { super("Inspector", "Click a block to see who placed it (CoreProtect)", Category.MISC); }
        private void send() {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) mc.player.connection.sendCommand("co inspect");
        }
        @Override protected void onEnable() { send(); }
        @Override protected void onDisable() { send(); }
    }
}
