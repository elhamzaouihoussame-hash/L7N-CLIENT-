package com.l7n.client.module.impl;

import com.l7n.client.CommandManager;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.status.ChunkStatus;
import java.util.*;

/** Scans loaded chunks every 2 seconds and lists what it finds on the HUD (and in chat). */
public abstract class FinderModule extends Module {
    public record Found(BlockPos pos, String label) {}
    private final List<String> lines = new ArrayList<>();
    private final Set<Long> announced = new HashSet<>();
    private int cd;

    protected FinderModule(String n, String d) {
        super(n, d, Category.MISC);
        addSetting("radius", 5, 1);
        addToggle("chat", true);
    }
    protected abstract void scan(ChunkAccess chunk, List<Found> out);

    @Override public boolean hasHud() { return true; }
        @Override public List<String> hudLines() { return lines; }
    @Override protected void onDisable() { lines.clear(); announced.clear(); }

    @Override public void tick(Minecraft mc) {
        if (cd-- > 0 || mc.level == null) return;
        cd = 40;
        List<Found> found = new ArrayList<>();
        BlockPos me = mc.player.blockPosition();
        int r = (int) get("radius"), pcx = me.getX() >> 4, pcz = me.getZ() >> 4;
        for (int dx = -r; dx <= r; dx++)
            for (int dz = -r; dz <= r; dz++) {
                ChunkAccess c = mc.level.getChunkSource().getChunk(pcx + dx, pcz + dz, ChunkStatus.FULL, false);
                if (c != null) scan(c, found);
            }
        found.sort(Comparator.comparingDouble((Found f) -> f.pos().distSqr(me)));
        lines.clear();
        int said = 0;
        for (Found f : found) {
            BlockPos p = f.pos();
            String t = f.label() + " " + p.getX() + " " + p.getY() + " " + p.getZ() + " (" + (int) Math.sqrt(p.distSqr(me)) + "m)";
            if (lines.size() < 6) lines.add(t);
            if (on("chat") && said < 3 && announced.add(p.asLong())) { said++; CommandManager.info("Found: " + t); }
        }
    }
}
