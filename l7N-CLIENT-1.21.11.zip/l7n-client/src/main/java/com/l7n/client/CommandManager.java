package com.l7n.client;

import com.l7n.client.gui.ClickGuiScreen;
import com.l7n.client.gui.HudEditorScreen;
import com.l7n.client.gui.ModuleSettingsScreen;
import com.l7n.client.module.Module;
import com.l7n.client.module.impl.StaffModules;
import com.l7n.client.module.impl.WorldModules;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.block.Block;
import java.util.Optional;

/** Chat commands. Type them in chat starting with a dot, e.g. .toggle killaura */
public class CommandManager {
    public static void info(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("§d[L7N] §f" + s), false);
    }

    /** @return true if the message was a client command (and must not be sent to the server) */
    public static boolean handle(String msg) {
        if (!msg.startsWith(".") || msg.startsWith("..")) return false;
        String[] a = msg.substring(1).trim().split("\\s+");
        Minecraft mc = Minecraft.getInstance();
        var mm = L7NClient.modules;
        switch (a[0].toLowerCase()) {
            case "help" -> {
                info(".help | .modules | .toggle <module> | .set <module> <setting> <value>");
                info(".settings [module] (opens settings screen) | .hud (move HUD elements) | .gui");
                info(".staff add|remove <word> | .staff name|unname <player> | .staff list");
                info(".blockesp add|remove|list <block> | .vclip <blocks> | .say <text> | .pos | .panic");
            }
            case "modules" -> {
                StringBuilder sb = new StringBuilder();
                for (Module m : mm.all) sb.append(m.isEnabled() ? "§a" : "§7").append(m.name).append(" ");
                info(sb.toString());
            }
            case "toggle", "t" -> {
                if (a.length < 2) { info("Usage: .toggle <module>"); break; }
                mm.byName(a[1]).ifPresentOrElse(m -> { m.toggle(); info(m.name + (m.isEnabled() ? " §aON" : " §cOFF")); },
                        () -> info("Unknown module: " + a[1]));
            }
            case "settings" -> {
                if (a.length < 2) mc.execute(() -> mc.setScreen(new ClickGuiScreen()));
                else mm.byName(a[1]).ifPresentOrElse(m -> mc.execute(() -> mc.setScreen(new ModuleSettingsScreen(m, null))),
                        () -> info("Unknown module: " + a[1]));
            }
            case "hud" -> mc.execute(() -> mc.setScreen(new HudEditorScreen(null)));
            case "set" -> {
                if (a.length < 4) { info("Usage: .set <module> <setting> <value>"); break; }
                mm.byName(a[1]).ifPresentOrElse(m -> {
                    if (!m.settings.containsKey(a[2].toLowerCase())) { info("Unknown setting. Use .settings " + m.name); return; }
                    try {
                        double v = switch (a[3].toLowerCase()) { case "on", "true" -> 1; case "off", "false" -> 0; default -> Double.parseDouble(a[3]); };
                        m.settings.put(a[2].toLowerCase(), v);
                        Config.save();
                        info(m.name + "." + a[2] + " = " + v);
                    } catch (NumberFormatException e) { info("Value must be a number or on/off"); }
                }, () -> info("Unknown module: " + a[1]));
            }
            case "staff" -> staff(a);
            case "vclip" -> {
                if (a.length < 2 || mc.player == null) { info("Usage: .vclip <blocks>"); break; }
                try { double d = Double.parseDouble(a[1]); mc.player.setPos(mc.player.getX(), mc.player.getY() + d, mc.player.getZ()); info("Teleported " + d + " blocks"); }
                catch (NumberFormatException e) { info("Value must be a number"); }
            }
            case "say" -> { if (a.length > 1 && mc.player != null) mc.player.connection.sendChat(msg.substring(5).trim()); }
            case "panic" -> { for (Module m : mm.all) m.setEnabled(false); info("All modules disabled"); }
            case "pos" -> { if (mc.player != null) info(String.format("XYZ %.1f %.1f %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ())); }
            case "blockesp" -> blockEsp(a);
            case "gui" -> mc.execute(() -> mc.setScreen(new ClickGuiScreen()));
            default -> info("Unknown command. Type .help");
        }
        return true;
    }

    private static void staff(String[] a) {
        StaffModules.StaffList sl = L7NClient.modules.get(StaffModules.StaffList.class);
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) { info("Words: " + sl.keywords + "  Names: " + sl.names); return; }
        if (a.length < 3) { info("Usage: .staff add|remove <word> | name|unname <player>"); return; }
        String v = a[2].toLowerCase();
        switch (a[1].toLowerCase()) {
            case "add" -> { sl.keywords.add(v); info("Added word " + v); }
            case "remove" -> { sl.keywords.remove(v); info("Removed word " + v); }
            case "name" -> { sl.names.add(v); info("Added staff name " + v); }
            case "unname" -> { sl.names.remove(v); info("Removed staff name " + v); }
            default -> { info("Usage: .staff add|remove <word> | name|unname <player>"); return; }
        }
        Config.save();
    }

    private static void blockEsp(String[] a) {
        WorldModules.BlockEsp be = L7NClient.modules.get(WorldModules.BlockEsp.class);
        if (a.length < 2 || a[1].equalsIgnoreCase("list")) {
            StringBuilder sb = new StringBuilder();
            for (Block b : be.blocks) sb.append(BuiltInRegistries.BLOCK.getKey(b).getPath()).append(" ");
            info("BlockESP: " + (sb.length() == 0 ? "(empty)" : sb));
            return;
        }
        if (a.length < 3) { info("Usage: .blockesp add|remove <block> | list"); return; }
        Identifier id = Identifier.tryParse(a[2]);
        Optional<Block> b = id == null ? Optional.empty() : BuiltInRegistries.BLOCK.getOptional(id);
        if (b.isEmpty()) { info("Unknown block: " + a[2]); return; }
        switch (a[1].toLowerCase()) {
            case "add" -> { be.blocks.add(b.get()); info("Added " + a[2]); }
            case "remove" -> { be.blocks.remove(b.get()); info("Removed " + a[2]); }
            default -> { info("Usage: .blockesp add|remove <block> | list"); return; }
        }
        Config.save();
    }
}
