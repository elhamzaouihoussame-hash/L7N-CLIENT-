package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

public final class MovementModules {
    private MovementModules() {}

    public static class Spider extends Module {
        public Spider() { super("Spider", "Climb walls", Category.MOVEMENT); addSetting("speed", 0.2, 0.05); }
        @Override public void tick(Minecraft mc) {
            if (mc.player.horizontalCollision) { Vec3 v = mc.player.getDeltaMovement(); mc.player.setDeltaMovement(v.x, get("speed"), v.z); }
        }
    }

    public static class Glide extends Module {
        public Glide() { super("Glide", "Fall slowly", Category.MOVEMENT); addSetting("fall", 0.05, 0.01); }
        @Override public void tick(Minecraft mc) {
            Vec3 v = mc.player.getDeltaMovement();
            if (!mc.player.onGround() && !mc.player.isInWater() && !mc.player.isFallFlying() && v.y < -get("fall"))
                mc.player.setDeltaMovement(v.x, -get("fall"), v.z);
        }
    }
}
