package com.l7n.client.module.impl;

import com.l7n.client.L7NClient;
import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;

public final class CombatModules {
    private CombatModules() {}

    public static class Criticals extends Module {
        public Criticals() { super("Criticals", "Critical hits (used by KillAura/TriggerBot/Mace)", Category.COMBAT); }
        public static void apply(Minecraft mc) {
            Criticals c = L7NClient.modules.get(Criticals.class);
            if (c == null || !c.isEnabled() || !mc.player.onGround()) return;
            double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + 0.0625, z, false, false));
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
        }
    }

    public static class TriggerBot extends Module {
        public TriggerBot() { super("TriggerBot", "Attacks what your crosshair is on", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null) return;
            if (!(mc.hitResult instanceof EntityHitResult r)) return;
            Entity e = r.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (mc.player.getAttackStrengthScale(0f) < 1f) return;
            Criticals.apply(mc);
            mc.gameMode.attack(mc.player, e);
            mc.player.swing(InteractionHand.MAIN_HAND);
        }
    }

    public static class Mace extends Module {
        private int cd;
        public Mace() { super("Mace", "Smash attack with a mace on the entity you look at", Category.COMBAT); addSetting("height", 10, 1); }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null) return;
            if (!mc.player.getMainHandItem().is(Items.MACE)) return;
            if (!(mc.hitResult instanceof EntityHitResult r)) return;
            Entity e = r.getEntity();
            if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
            if (mc.player.getAttackStrengthScale(0f) < 1f) return;
            double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ(), h = get("height");
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y + h, z, false, false));
            mc.player.connection.send(new ServerboundMovePlayerPacket.Pos(x, y, z, false, false));
            mc.gameMode.attack(mc.player, e);
            mc.player.swing(InteractionHand.MAIN_HAND);
            cd = 10;
        }
    }

    public static class AutoTotem extends Module {
        private int cd;
        public AutoTotem() { super("AutoTotem", "Keeps a totem in your offhand", Category.COMBAT); }
        @Override public void tick(Minecraft mc) {
            if (cd > 0) { cd--; return; }
            if (mc.screen != null || mc.gameMode == null) return;
            if (mc.player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
            var inv = mc.player.getInventory();
            for (int i = 0; i < 36; i++) {
                if (inv.getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                    int slot = i < 9 ? 36 + i : i;
                    mc.gameMode.handleInventoryMouseClick(mc.player.inventoryMenu.containerId, slot, 40, ClickType.SWAP, mc.player);
                    cd = 5;
                    return;
                }
            }
        }
    }
}
