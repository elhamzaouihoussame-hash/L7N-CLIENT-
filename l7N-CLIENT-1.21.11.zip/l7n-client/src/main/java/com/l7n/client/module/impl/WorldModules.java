package com.l7n.client.module.impl;

import com.l7n.client.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class WorldModules {
    private WorldModules() {}

    public static class AutoMine extends Module {
        public AutoMine() { super("AutoMine", "Holds left click to mine continuously", Category.MISC); }
        @Override public void tick(Minecraft mc) { if (mc.screen == null) mc.options.keyAttack.setDown(true); }
        @Override protected void onDisable() { Minecraft.getInstance().options.keyAttack.setDown(false); }
    }

    /** Places the block you hold under your feet. */
    public static class Scaffold extends Module {
        public Scaffold() { super("Scaffold", "Places held blocks under you", Category.MISC); }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (!(mc.player.getMainHandItem().getItem() instanceof BlockItem)) return;
            BlockPos below = mc.player.blockPosition().below();
            if (!mc.level.getBlockState(below).canBeReplaced()) return;
            for (Direction d : Direction.values()) {
                BlockPos n = below.relative(d);
                if (mc.level.getBlockState(n).canBeReplaced()) continue;
                Direction face = d.getOpposite();
                Vec3 hit = new Vec3(n.getX() + 0.5 + face.getStepX() * 0.5, n.getY() + 0.5 + face.getStepY() * 0.5, n.getZ() + 0.5 + face.getStepZ() * 0.5);
                mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
                mc.player.swing(InteractionHand.MAIN_HAND);
                return;
            }
        }
    }

    /** Builds under and around you automatically: bridging, filling holes, with hotbar auto-switch. */
    public static class LimitlessBuilder extends Module {
        private int cd;
        public LimitlessBuilder() {
            super("LimitlessBuilder", "Auto-places blocks under/around you (bridge, tower, fill)", Category.MISC);
            addSetting("radius", 1, 1); addSetting("delay", 0, 1); addToggle("autoswitch", true);
        }
        private boolean ensureBlock(Minecraft mc) {
            if (mc.player.getMainHandItem().getItem() instanceof BlockItem) return true;
            if (!on("autoswitch")) return false;
            var inv = mc.player.getInventory();
            for (int i = 0; i < 9; i++) {
                if (inv.getItem(i).getItem() instanceof BlockItem) { inv.setSelectedSlot(i); return true; }
            }
            return false;
        }
        private boolean placeAt(Minecraft mc, BlockPos pos) {
            if (!mc.level.getBlockState(pos).canBeReplaced()) return false;
            for (Direction d : Direction.values()) {
                BlockPos n = pos.relative(d);
                if (mc.level.getBlockState(n).canBeReplaced()) continue;
                Direction face = d.getOpposite();
                Vec3 hit = new Vec3(n.getX() + 0.5 + face.getStepX() * 0.5, n.getY() + 0.5 + face.getStepY() * 0.5, n.getZ() + 0.5 + face.getStepZ() * 0.5);
                mc.gameMode.useItemOn(mc.player, InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, n, false));
                mc.player.swing(InteractionHand.MAIN_HAND);
                return true;
            }
            return false;
        }
        @Override public void tick(Minecraft mc) {
            if (mc.screen != null || mc.gameMode == null || mc.level == null) return;
            if (cd > 0) { cd--; return; }
            if (!ensureBlock(mc)) return;
            BlockPos feet = mc.player.blockPosition().below();
            int r = (int) get("radius");
            for (int dx = -r; dx <= r; dx++)
                for (int dz = -r; dz <= r; dz++)
                    if (placeAt(mc, feet.offset(dx, 0, dz))) { cd = (int) get("delay"); return; }
        }
    }

    private static boolean storage(BlockEntity be) {
        return be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity
                || be instanceof AbstractFurnaceBlockEntity || be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                || be instanceof BrewingStandBlockEntity || be instanceof EnderChestBlockEntity || be instanceof BedBlockEntity;
    }

    public static class BaseFinder extends FinderModule {
        public BaseFinder() { super("BaseFinder", "Finds chunks with many containers (bases)"); addSetting("minimum", 5, 1); }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            int n = 0; BlockPos first = null;
            for (BlockPos pos : c.getBlockEntitiesPos()) {
                BlockEntity be = c.getBlockEntity(pos);
                if (be != null && storage(be)) { n++; if (first == null) first = be.getBlockPos(); }
            }
            if (first != null && n >= (int) get("minimum")) out.add(new Found(first, "Base? " + n + " containers"));
        }
    }

    public static class ChestFinder extends FinderModule {
        public ChestFinder() { super("ChestFinder", "Finds stashes (many chests/barrels/shulkers)"); addSetting("minimum", 8, 1); }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            int n = 0; BlockPos first = null;
            for (BlockPos pos : c.getBlockEntitiesPos()) {
                BlockEntity be = c.getBlockEntity(pos);
                if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity) { n++; if (first == null) first = be.getBlockPos(); }
            }
            if (first != null && n >= (int) get("minimum")) out.add(new Found(first, "Stash " + n));
        }
    }

    public static class ShulkerFinder extends FinderModule {
        public ShulkerFinder() { super("ShulkerFinder", "Finds shulker boxes"); }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            for (BlockPos pos : c.getBlockEntitiesPos()) {
                BlockEntity be = c.getBlockEntity(pos);
                if (be instanceof ShulkerBoxBlockEntity) out.add(new Found(be.getBlockPos(), "Shulker"));
            }
        }
    }

    public static class BlockEsp extends FinderModule {
        public final Set<Block> blocks = new LinkedHashSet<>();
        public BlockEsp() {
            super("BlockESP", "Finds chosen blocks (.blockesp add <id>)");
            blocks.add(Blocks.ANCIENT_DEBRIS); blocks.add(Blocks.DIAMOND_ORE); blocks.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        }
        @Override public void saveExtra(com.google.gson.JsonObject o) {
            com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
            for (Block b : blocks) arr.add(BuiltInRegistries.BLOCK.getKey(b).toString());
            o.add("blocks", arr);
        }
        @Override public void loadExtra(com.google.gson.JsonObject o) {
            if (!o.has("blocks")) return;
            blocks.clear();
            for (var e : o.getAsJsonArray("blocks")) {
                var id = net.minecraft.resources.Identifier.tryParse(e.getAsString());
                if (id != null) BuiltInRegistries.BLOCK.getOptional(id).ifPresent(blocks::add);
            }
        }
        @Override protected void scan(ChunkAccess c, List<Found> out) {
            if (blocks.isEmpty()) return;
            int minX = c.getPos().getMinBlockX(), minZ = c.getPos().getMinBlockZ();
            LevelChunkSection[] secs = c.getSections();
            for (int i = 0; i < secs.length; i++) {
                LevelChunkSection s = secs[i];
                if (s == null || s.hasOnlyAir() || !s.maybeHas(st -> blocks.contains(st.getBlock()))) continue;
                int baseY = (c.getMinSectionY() + i) << 4;
                for (int x = 0; x < 16; x++) for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) {
                    BlockState st = s.getBlockState(x, y, z);
                    if (blocks.contains(st.getBlock())) {
                        out.add(new Found(new BlockPos(minX + x, baseY + y, minZ + z), BuiltInRegistries.BLOCK.getKey(st.getBlock()).getPath()));
                        if (out.size() > 400) return;
                    }
                }
            }
        }
    }
}
